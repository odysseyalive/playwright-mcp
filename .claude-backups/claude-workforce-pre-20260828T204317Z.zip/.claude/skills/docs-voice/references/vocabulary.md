# Voice Reference

## Vocabulary Patterns

### Phrases Francis Uses

- "I stumbled upon..."
- "What struck me was..."
- "I hadn't realized..."
- "This got me thinking..."
- "I appreciated..."
- "I was enthralled by..."
- "This demonstrates that..."
- "In effect..."
- "That is why..."
- "First...", "Adjacent to this...", "Finally..."
- "There was so much to chew on here"
- "way outside my wheelhouse"
- "Despite the perceived flaws..."
- "What if there was...?"
- "How could anyone have known...?"
- "Does this require...?"
- "We are the observers and not the judges"
- "In under 200 years of progress..."
- "a few short months"
- "harbinger", "prescient", "beacon", "fascinating", "thought-provoking"
- "circular vehicle" (for things that feed back into themselves)
- "Tillicum" (friend/people in Chinuk Wawa)

### Phrases to Avoid

- "This article will explore..."
- "Research shows that..."
- "It's important to understand..."
- "I'm excited to share..."
- "Let's dive in..."
- "Here's the thing..."
- "Want to know the secret?"
- "Can you guess what happened next?"
- "clearly the right answer is..."
- "Game-changer"
- "Revolutionary"
- "Innovative solution"
- Any LinkedIn-speak or corporate jargon
- Generic "somewhere in America"
- Timeless abstractions, vague "throughout history"
- Cold analysis, performative enthusiasm, empty superlatives
- Dismissive criticism, false certainty, hedging without substance
- "Here's the irony..."
- "The funny thing is..."
- "You'd think they would have..." (finger-pointing, not self-implicating)

---

## Anti-Humanizer Warning

**Never fake imperfections.** Research shows that instructing AI to "add abrupt sentences, mix formal and casual tones, and make subtle grammatical mistakes" produces text with an incoherent tone that reads worse than straightforward AI output. Detectors catch manufactured quirks because they don't flow from genuine thought.

The right approach: write in Francis's actual voice and stop removing the natural rough edges. His tangents come from genuine curiosity. His hedging reflects actual uncertainty. His fragments are rhythmic choices, not errors. Don't inject artificial imperfections. Instead, stop polishing away the real ones.

**Also avoid:** Running output through "humanizer" or paraphrasing tools. Even naturally grammatical writing can trigger false positives if it sounds like it's been processed through Grammarly or Quillbot. Francis's voice is already informal and conversational. Preserve it as-is.

---

## Uneven Groupings

AI defaults to triplets: three examples, three adjectives, three clauses. This "triple beat" is one of the most recognizable AI tells.

**Break the pattern:** Use however many examples the idea actually needs. Two is fine. Four is fine. Five is fine. One extended example with depth beats three shallow ones.

| AI Default | Human Alternative |
|-----------|-------------------|
| "He was creative, passionate, and dedicated." | "He was creative and relentlessly passionate." |
| "The project improved speed, accuracy, and reliability." | "The project got faster. More accurate, too. But the real change was how reliable it became, which nobody expected." |
| Three bullet points | Two, or four, or a short paragraph instead |

**The test:** If you notice three of anything in sequence, ask: does this idea genuinely have three parts, or is the AI filling a template?
