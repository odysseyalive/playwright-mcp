# Content-Type Constraints — Documentation

<!-- origin: skill-builder | created: 2026-06-07 (docs-voice port from claude-enforcer; retargeted from marketing/blog content types to technical documentation) | modifiable: true -->
<!-- Derived from the ported kernel: references/kernel.md, references/directives.md, references/profile.md. When a constraint below conflicts with its source, the source wins. The marketing content types (focus-article / social-post / newsletter-teaser / presentation-slide) were intentionally dropped — playwright-mcp produces technical docs, not marketing content. -->

Per-type constraints applied on top of the writing kernel (the voice references + kernel + directives). This file is the application layer — it names its canonical source for every rule.

## The two-zone rule (applies to EVERY documentation type — read first)

Technical documentation splits into two zones, and the voice rules apply to **only one** of them:

- **Prose zone** — positioning, intros, the sentence before and after a command, "why you'd want this", section framing, troubleshooting explanation. **Full voice applies here:** discovery language, burstiness, texture words, write-for-the-curious, they/them, no em-dashes, no rhetorical colons. *(Source: references/kernel.md, references/characteristics.md, references/sentence-structure.md.)*

- **Literal zone** — fenced code blocks, inline commands, file paths, flags (`--headless`), env vars, `key: value` config lines, tool output, URLs. **Voice rules are SUSPENDED here.** A command is reproduced exactly as it must be typed. The no-em-dash rule does NOT touch a `--flag`; the no-colon rule does NOT touch a `key: value` line or a colon introducing a code block; "invite, don't explain" does NOT vague-up an exact step. *(This carve-out is the load-bearing adaptation — see § Biggest risk below.)*

**Enforcement is prompt-level here.** claude-enforcer backed the no-em-dash / no-colon rules with host-local hooks; those hooks are NOT ported (playwright-mcp doesn't distribute hooks). The carve-out above plus the `docs-voice-validator` agent are the only thing standing between the voice rules and a corrupted install command. Treat the literal zone as sacred.

## `documentation` (the general type — README, guides, docs/*.md)

- **Invitation lives in the prose, completeness lives in the steps.** The "Summaries and Descriptions Should Invite, Not Explain" rule (kernel § 6) applies to the intro and positioning — *not* to install steps. A README's steps are SUPPOSED to explain fully and literally; that is the contract. The intro invites ("here's what this gets you"); the steps are flat, exact, and complete. *(Source: references/kernel.md § 6, bounded for docs.)*
- **Every documented command must be verified before it ships.** Do not write an install command, flag, or path you have not confirmed runs / exists. *(Source: references/directives.md — Citation Verification Gate, mapped to docs: "cite-before-use" = "verify-before-document".)*
- **Never fabricate a step, flag, or behavior.** If a command is untested or a flag is unconfirmed, say so or leave it out — never present an unverified step as working. *(Source: references/directives.md — Anti-Fabrication Gate.)*
- **One step, one job.** A numbered install step does exactly one thing; "install deps and build and register" is three steps. *(Source: references/directives.md "One sentence, one job", applied to steps.)*
- **Client language.** Describe the project as "established / mature / battle-tested", never "legacy / outdated". *(Source: references/kernel.md § Client Language.)*

## `readme` (the first instance of `documentation` — `README.md`)

- Inherits all `documentation` constraints.
- **BARE BONES.** Easy for anyone to understand and use — shortest useful README: a one-or-two-sentence "what it is + why", then Install, then a short "use it", then License. NO philosophy essays, NO long narrative sections, images optional. *(The claude-enforcer README is the FORMAT model, NOT the length model — it runs long with essays; this one stays minimal.)*
- **Built LAST.** The README is written at the **final step of the build**, after every phase is built and verified — so every documented command is real and confirmed (verify-before-document). Do not draft it ahead of the installers it documents.
- **Format model — `~/lab/claude-enforcer/README.md`** (mirror its *format*, not its length):
  - **Install section:** state requirements/version up front (here: Node ≥18, the ~170 MB one-time Chromium download, and the Linux system-libs/sudo caveat — per the Playwright sourcing decision). Then platform-split with **bold labels**: `**Linux / macOS**` → a ```` ```bash ```` block, `**Windows PowerShell**` → a ```` ```powershell ```` block. Never describe one platform and leave the other to inference.
  - **Code presentation:** fenced blocks with language tags (` ```bash `, ` ```powershell `); Claude-Code slash-commands in a bare ` ``` ` block; one command or one idea per block; every block copy-pasteable end to end.
- **Two clearly separated install paths.** The single-project option and the all-projects (user-scope) option are self-contained — never interleave their commands. Each shows its per-platform block.
- **Lead with what it gets the reader, not a feature list.** Open in voice (engagement, not a spec dump); then the install options as exact, literal steps. *(Source: references/kernel.md § 1 "Lead with Engagement".)*

## All documentation types

- Pronouns: they/them default; names over pronouns when a person matters. *(Source: references/profile.md, references/directives.md.)*
- Texture words ("too", "other", "also", "actually") are preserved through every edit of the prose zone. *(Source: references/directives.md "Don't strip the texture words".)*
- **No calibration anchor is available in this project** (the claude-enforcer anchor texts live in odyssey-alive). The Calibration Read Gate cannot fire here; the voice references are the calibration. A ratified README MAY become the first local anchor for future docs — a forward decision, not assumed.
<!-- /origin -->
