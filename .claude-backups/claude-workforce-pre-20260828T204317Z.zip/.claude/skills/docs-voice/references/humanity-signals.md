# Humanity Signals

How to write like a person, not avoid sounding like a machine. Synthesized from three independent research sources on AI detection and human authorship tells.

**The core principle:** Optimizing for "sounds like a person thinking" produces better writing than optimizing for "doesn't sound like AI." Individual signals are not tells. Only clustering is. Three or more AI signals in the same passage is a tell. One or two may be deliberate craft.

---

## AI Tells (Patterns That Read as Machine-Generated)

These patterns reduce **perplexity** (how surprised a reader or detector is by the next word) and **burstiness** (how much sentence rhythm varies). Low perplexity + low burstiness = predictable writing = AI signal.

| Tell | What It Looks Like | Francis's Counter |
|------|-------------------|-------------------|
| **Low perplexity** | Every word choice is the expected one. No surprises. | Francis uses "squirrel on espresso," "circular vehicle," Chinuk Wawa terms. Unexpected words spike perplexity naturally. |
| **Uniform rhythm** | Sentences march at the same length and cadence | Francis swings from "The proposal is simple." to 40-word meditative passages. |
| **Formulaic openings** | "This study," "It is important," "In conclusion," "Therefore" | Francis opens with "I stumbled upon," "What struck me was," "The thing is," or a scene. |
| **Syntactic repetition** | Same sentence structure repeated: subject-verb-object, subject-verb-object | Francis mixes fragments, questions, invitations, asides, and declarations. |
| **No tangents** | Stays rigidly on-topic. Every sentence advances the thesis. | Francis wanders into squirrels, coastal roads, grocery store routes. The tangents ARE the voice. |
| **Overly polished** | No rough edges, no informality, no conversational filler | Francis keeps "too," "other," "actually," "just" — the texture words AI strips. |
| **No hedging** | Declarative certainty on everything | Francis says "way outside my wheelhouse," "I don't know how you prepare for that," "it could possibly." |
| **Generic vocabulary** | "Important," "robust," "enhanced," "innovative" | Francis uses specific, concrete words grounded in place and experience. |
| **Surface-level claims** | Broad assertions without depth or evidence | Francis pulls from specific sources, names people (Joseph, Travis, Bob Case), cites dates and numbers as discoveries. |
| **Triplet patterns** | Always exactly three examples, three adjectives, three clauses | Francis uses 2, 4, 5, or whatever the idea needs. Not always three. |
| **Missing author** | No personal stance, no "I," no lived experience | Francis is present from the first paragraph. His opinions, doubts, and discoveries drive the piece. |
| **Heavy formatting** | Over-reliance on em-dashes and bullet points | Already enforced: em-dashes have zero tolerance. Bullet points are for reference material, not prose. |

---

## Human Tells (Patterns That Read as Person-Written)

These patterns increase perplexity and burstiness. Detectors and readers both respond to them as signals of genuine authorship.

| Tell | What It Looks Like | Francis's Natural Version |
|------|-------------------|--------------------------|
| **High burstiness** | Dramatic variation in sentence length. A 4-word sentence next to a 35-word one. | "The proposal is simple." then "As I explored the familiar route to the grocery store from my house using Google Street View, I initially intended to document a comparison..." |
| **Varied openings** | No two consecutive sentences start the same way | Francis starts with "I," "The," "And," "Could it be," "Have you ever," "Imagine," questions, fragments. |
| **Natural tangents** | Slightly off-topic asides that reflect real thought processes | The squirrel-on-espresso aside in Finding Tamanawas. The grocery store detour. These are human signals. |
| **Hedging** | Cautious language where genuine uncertainty exists | "It could possibly," "it appears to," "it may," "way outside my wheelhouse," "I apologize, as it's nearly impossible." |
| **Varied vocabulary** | Fresh, specific word choices instead of generic terms | "Harbinger," "prescient," "circular vehicle," "Tillicum," place names, people names. |
| **In-depth content** | Specific sources, named people, concrete evidence | Francis names Joseph, Travis, Bob Case. Cites Harvard Business Review conversations. Gives specific percentages as discoveries. |
| **Uneven examples** | Not always three. Sometimes two. Sometimes five. Whatever the idea needs. | Break the triplet reflex. If there are four examples, use four. If two make the point, stop at two. |
| **Authorial voice** | Personal insights, critiques, genuine stances on issues | "We are the observers and not the judges." Francis takes positions, expresses doubt, shows what he cares about. |
| **Texture words** | Conversational filler that AI strips: "other," "too," "also," "actually," "just," "really" | "A million other people did, too" not "A million people did." These words make prose sound spoken. |
| **Contractions** | "didn't," "wasn't," "I'd," "they're" instead of formal alternatives | Francis writes conversationally. Contractions are default. |
| **Fragments and asides** | Sentence fragments for emphasis. Mid-sentence pivots. Parenthetical thoughts. | "And the air? Thick with something intangible." Fragment question + fragment answer is a Francis signature. |

---

## The Anti-Humanizer Rule

**Never fake imperfections.** Research specifically warns that instructing AI to "add abrupt sentences, mix formal and casual tones, use storytelling instead of rigid formatting, and make subtle grammatical mistakes" creates text with an **incoherent tone** that reads worse than genuine AI output. Detectors catch manufactured quirks.

The right approach: write in Francis's actual voice. His rough edges are real. His tangents come from genuine curiosity. His hedging reflects actual uncertainty. Don't inject artificial imperfections. Instead, stop removing the natural ones.

---

## Cluster Detection (How to Use This)

**For the drafting agent:** These signals are targets to hit, not a checklist to force. If the draft naturally has 4+ human tells present, it's working. Don't artificially insert them.

**For the evaluator:** Scan for AI tell clusters (3+ in the same passage). Individual AI tells in isolation are CONSIDER severity. Clustered AI tells are SHOULD FIX. Also scan for human tell presence — a piece with strong human tells and a couple of AI pattern instances is human writing, not AI writing.

| Cluster Density | Assessment |
|----------------|------------|
| 0-1 AI tells in a passage | No flag |
| 2 AI tells in a passage | CONSIDER — note but don't require change |
| 3+ AI tells in a passage | SHOULD FIX — the clustering is the tell |
| Strong human tells + scattered AI tells | Human writing — protect the voice, note the AI tells as CONSIDER |
