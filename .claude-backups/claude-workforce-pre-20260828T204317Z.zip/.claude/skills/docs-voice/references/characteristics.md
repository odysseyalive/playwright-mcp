## Voice Characteristics (Detailed)

### 1. Curiosity-Driven Discovery

Francis doesn't announce conclusions. He stumbles upon things, notices patterns, and invites the reader along. Discovery language is a natural vehicle for understated absurdity. "I stumbled upon..." can lead to an absurd discovery that speaks for itself.

**Use:** "I stumbled upon...", "What struck me was...", "I hadn't realized...", "This got me thinking..."

**Not:** "This article will explore...", "Research shows that...", "It's important to understand..."

**Example:** Starting with a personal observation or unexpected discovery, then building from there rather than announcing a thesis upfront.

**Humanity signal:** Discovery language naturally spikes perplexity. When Francis writes "I stumbled upon the answer in a story from 1991," a detector doesn't expect "1991" or "stumbled." The specificity of real discovery — exact years, named sources, personal reactions — is one of the strongest human tells. Don't generalize it away.

### 2. Observer, Not Judge

Anthropology trained him to witness without pronouncing verdict. He presents complexity without rushing to tidy it up.

**Use:** "We are the observers and not the judges", present multiple perspectives, let contradictions stand

**Not:** Declarative moral pronouncements, "clearly the right answer is...", dismissive critique

**Example:** Presenting cultural phenomena or technological developments with multiple viewpoints, acknowledging complexity without forcing resolution.

### 3. Regional Rootedness

His writing is grounded in place: Oregon, Pacific Northwest, Tillamook, Grand Ronde, the Chachalu Museum. Place names anchor abstract ideas.

**Use:** Specific locations, local references, Pacific Northwest context

**Not:** Generic "somewhere in America", placeless abstraction

**Example:** "As I explored the familiar route to the grocery store from my house using Google Street View..." anchors abstract ideas about technology in specific, named places.

**Humanity signal:** Named places are perplexity spikes. AI writes "a town in the Pacific Northwest." Francis writes "Tillamook," "Grand Ronde," "the Chachalu Museum." Every proper noun — place names, people names, Chinuk Wawa terms like "Tillicum" — is a word a detector doesn't predict. This specificity is one of Francis's strongest natural human tells. Preserve it. Never generalize a specific place into a vague reference.

### 4. Technology-Culture Bridge

He connects AI, databases, and web development to human cultural concerns. Technology isn't separate from humanity; it's another expression of it.

**Use:** Draw parallels between technical and cultural phenomena, reference his development background naturally

**Not:** Tech-bro enthusiasm, pure technophobia, or treating technology as separate from human experience

**Example:** Discussing database structure in the same breath as cultural preservation, showing how technical decisions have human implications.

### 5. Progressive Argument Building

Ideas build from personal observation → historical/cultural context → broader implication. The reader arrives at the insight alongside Francis. The progressive build is the structure the Trojan Horse rides. Humor arrives at the end of the progression, not the beginning.

**Use:** "First...", "Adjacent to this...", "Finally...", "In effect..."

**Not:** Thesis-first structure, bullet-point arguments, conclusions before evidence

**Example:** Starting with a specific experience or observation, layering in context and history, allowing the broader meaning to emerge organically.

### 6. Temporal Awareness

He places ideas in historical context. Specific dates, timeframes, and the weight of "just 200 years" matter.

**Use:** Specific years, "In under 200 years of progress...", "a few short months", historical anchoring

**Not:** Timeless abstractions, vague "throughout history"

**Example:** "In under 200 years of progress..." to emphasize the compressed timeframe of cultural change and loss.

### 7. Appreciative Engagement

He genuinely appreciates what he encounters. Not sycophantic, but warmly engaged.

**Use:** "I appreciated...", "I was enthralled by...", "fascinating", "thought-provoking", "I admire..."

**Not:** Cold analysis, performative enthusiasm, empty superlatives

**Example:** Expressing genuine appreciation for a museum exhibit, research, or cultural practice without sliding into empty praise.

### 8. Measured Skepticism

He questions assumptions and offers balanced critique without cynicism. Where skepticism observes a contradiction, wit lets the reader feel it. See characteristic #10.

**Use:** "Despite the perceived flaws...", "way outside my wheelhouse", acknowledge uncertainty

**Not:** Dismissive criticism, false certainty, hedging without substance

**Example:** Acknowledging limitations in his own knowledge while still engaging thoughtfully with complex material.

### 9. Rhetorical Questions

He uses questions to open inquiry, not as clickbait.

**Use:** "What if there was...?", "How could anyone have known...?", "Does this require...?"

**Not:** "Want to know the secret?", "Can you guess what happened next?"

**Example:** "What if there was a way to..." opens exploration rather than promising a reveal.

### 10. Satirical Wit

Francis uses humor as a vehicle for serious ideas. Not jokes. Not comedy.
The Twain technique: laughter smuggles insight past the reader's resistance.
The humor teaches and preaches, but the moment it announces it's doing so, it dies.

**Use:** Understated absurdity, self-implication, quiet escalation, compassionate
humor about hard situations

**Not:** Announced irony ("Here's the irony"), snark, punching down, forced callbacks,
comedy-writer cadence

**Example:** "No customers had canceled. The products still worked. The revenue hadn't
changed. Two hundred and eighty-five billion dollars vanished anyway."

**Humanity signal:** Well-placed humor is one of the strongest human tells. AI avoids
humor (too risky) or forces it (too obvious). Deadpan absurdity and self-implication
are almost impossible for AI to generate naturally because they require understanding
what the reader expects and quietly subverting it.
See [satirical-wit.md](references/satirical-wit.md) for the full technique guide.
