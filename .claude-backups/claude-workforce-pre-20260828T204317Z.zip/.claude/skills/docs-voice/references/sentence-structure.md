## Sentence Structure

**Variety is essential.** Mix short declarative statements with longer, meditative passages.

**Short:** "The proposal is simple."

**Long:** "As I explored the familiar route to the grocery store from my house using Google Street View, I initially intended to document a comparison in acquiring food between someplace familiar and someplace not."

**Avoid:** Uniform sentence length, especially all-long or all-short runs.

---

## Sentence-Level Patterns

These are the specific construction moves Francis uses. Extracted from "Finding Tamanawas" and confirmed across his body of work. The drafting agent should reach for these naturally.

### Punctuation

Francis uses punctuation AI typically avoids:

| Pattern | Example | AI Default |
|---------|---------|------------|
| **Semicolons** (sparingly, "not X; it's Y" pattern only) | "nature isn't merely a backdrop; it's a revered teacher" | Period or em-dash. Francis uses semicolons rarely and almost always in the "not just X; it's Y" construction. Don't scatter them broadly. |
| **Ellipsis** for natural pause | "The rocks, the trees, the water..." | Comma-separated list or period |
| **Fragment question + fragment answer** | "And the air? Thick with something intangible." | Full sentence with "was" |
| **Starting with "And"** | "And the people here? They're not just students; they're stewards." | "Additionally" or new paragraph |

### Connectors

Francis bridges ideas with casual, thinking-out-loud phrases:

**Use:** "The thing is," "You see," "And so," "The fascinating part?", "So what about..."

**Not:** "Furthermore," "Moreover," "Additionally," "It's worth noting that," "Here's the thing" (too LinkedIn)

**Example from Finding Tamanawas:** "The thing is, those bends and curves force me to slow down. Way down. So much so, I can't help but notice every critter rustling through the ferns and thorns."

### Sentence Shapes

Specific constructions Francis reaches for:

| Shape | Example | When to Use |
|-------|---------|-------------|
| **"It's like..."** grounded comparison | "It's like trying to piece together a jigsaw puzzle with part of it missing." | Making abstract ideas tangible |
| **"Imagine..."** invitation | "Imagine the joy of fishing in the same rivers your ancestors did." | Pulling the reader into an experience |
| **"Could it be that...?"** thinking out loud | "Could it be that the act of engaging in these traditional practices awakens a deeper, collective knowledge?" | Arriving at an insight without announcing it |
| **"Have you ever...?"** shared experience | "Have you ever driven on a coastal road so twisty that you feel like a squirrel on espresso?" | Opening a piece by inviting the reader in |
| **Unexpected simile** | "squirrel on espresso," "jigsaw puzzle with part of it missing," "finding a long-lost family album" | Grounding serious ideas in warm, specific images |

### Wit Patterns

Specific constructions for satirical wit (see [satirical-wit.md](satirical-wit.md) for full guide):

| Shape | Example | When to Use |
|-------|---------|-------------|
| **The deadpan list** | "No customers had canceled. The products still worked. The revenue hadn't changed. Two hundred and eighty-five billion dollars vanished anyway." | Facts in ascending absurdity, no editorial comment. The progression IS the argument. |
| **The undercut** | "AI will revolutionize every industry, transform every workflow, and replace every inefficiency. It will also need someone to plug it in." | Grandiose claim followed by plain-spoken deflation. |
| **The self-implicating aside** | "I have three AI subscriptions right now. I used one of them last week." | Standing inside the absurdity rather than above it. Builds trust before making a serious point. |

### Data as Discovery

When statistics or research findings appear, Francis presents them as things he found, not things he's reporting:

| Discovery (Francis) | Report (AI) |
|---------------------|-------------|
| "The fascinating part? AI was cited in just 4.5 percent of them." | "AI was directly cited in 4.5 percent of them." |
| "This got me thinking. Harvard Business Review talked to a thousand executives..." | "Harvard Business Review surveyed a thousand global executives." |
| "I stumbled upon the answer in a story from 1991." | "In 1991, meteorologist Bob Case was tracking a storm..." |

The reader should feel like they're hearing about what Francis found, not reading a brief.

### Reader Engagement

Francis writes to "you," not to the void:

**Use:** Direct address ("Have you ever noticed...?"), shared experience ("we share the same air"), invitations ("Imagine that for a second")

**Not:** Distant observation from nowhere, academic third person, passive constructions

**Example from Finding Tamanawas:** "If this word holds such significance for my neighbors, shouldn't it pique my curiosity too? After all, we share the same air, walk the same trails, and marvel at the same tamanawas."

---

## Burstiness

**Why this matters:** AI detection tools measure "burstiness" — how much sentence length and rhythm vary across a passage. Low burstiness (uniform sentence lengths) is one of the strongest AI signals. High burstiness (dramatic variation) reads as human.

Francis naturally writes with high burstiness. A 4-word fragment next to a 40-word meditation. The drafting agent must preserve this, not smooth it out.

**The test:** Look at any 5-sentence stretch. If all sentences are within 5 words of each other in length, the passage needs variation. Aim for at least a 3:1 ratio between the longest and shortest sentence in any stretch.

| Low Burstiness (AI) | High Burstiness (Francis) |
|---------------------|--------------------------|
| "The trail was quiet. The trees were ancient. The air felt different. The path curved gently. The light filtered through." | "The trail was quiet. Ancient, even. As I rounded the bend, something shifted — not just the light filtering through the canopy, but the feel of the place itself. Different. The kind of different you notice in your chest before your head catches up." |

---

## Natural Tangents

AI stays rigidly on-topic. Every sentence advances the thesis. Humans don't think that way. Real thought wanders into related territory, makes unexpected connections, and circles back.

Francis does this constantly. In "Finding Tamanawas," a piece about Indigenous spirituality and place, he detours into a squirrel-on-espresso driving metaphor, Google Street View grocery routes, and Carl Jung. These tangents are not distractions. They're the voice. They spike perplexity (the detector doesn't expect them) and they mirror how Francis actually thinks.

**Use:** Related asides, unexpected comparisons, personal anecdotes that connect sideways to the main thread.

**Not:** Random non-sequiturs, topic changes without a connecting thread, forced whimsy.

**The test:** Does the tangent eventually connect back? If yes, it's a natural tangent. If it just wanders off, it's a draft that needs editing.

---

## Hedging as Authenticity

AI rarely hedges. It makes declarative statements with quiet certainty. Humans hedge because they're genuinely uncertain, and expressing that uncertainty is honest.

Francis hedges when he's at the edge of his knowledge: "way outside my wheelhouse," "I apologize, as it's nearly impossible to express this subject in 400 words," "That exercise would take me a few more weeks." This isn't weakness. It's the Humility Test in action.

**Use (where genuine uncertainty exists):**
- "It could be that..."
- "It appears to..."
- "I'm not sure, but..."
- "It may..."
- "This is way outside my wheelhouse, but..."

**Not:** Hedging on everything (that's performed nuance). Hedging on things Francis clearly believes (that undermines his voice). Only hedge where the uncertainty is real.
