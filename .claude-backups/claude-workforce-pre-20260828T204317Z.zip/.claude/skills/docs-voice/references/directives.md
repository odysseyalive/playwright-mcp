# Enforced Directives

These directives are enforced by hooks or text-eval agents. They were extracted from SKILL.md to reduce cognitive load during drafting. The full directive text is preserved here for reference.

---

## Hook-Enforced

> **No em-dashes or en-dashes.**
> Em-dashes (—) and en-dashes (–) are prohibited in all content. They're an AI tell — real conversational writing uses periods, commas, or restructuring instead. No exceptions for "visual separators" or format-specific rationalizations.
>
> *Enforcement: `writing/hooks/no-em-dashes.sh` (blocks Edit and Write)*

*— Pre-2026-01-29, source: user directive on punctuation tells*

> **Never use colons for emphasis or setup.**
> Colons in prose are an AI tell. Most people don't use them. The pattern "The result: a seamless experience" or "Here's the truth: it doesn't work" is a constructed move that sounds like a machine landing a point. Use a period and a new sentence. Use a question mark. Restructure. The only acceptable colons are mechanical ones: introducing a list, a block quote, or a time stamp. If the colon is doing rhetorical work, kill it.
>
> - **AI colon:** "The most effective AI setups depend on exactly what you were building: isolated agents doing independent research."
> - **Spoken:** "The most effective AI setups I've seen work the same way you did. Isolated agents. Independent research."
> - **AI colon:** "And here's the part that should keep everyone up at night: those interactions received higher approval ratings."
> - **Spoken:** "And the part that should keep everyone up at night? Those interactions received higher approval ratings."
>
> *Enforcement: `writing/hooks/no-rhetorical-colons.sh` (blocks Edit and Write)*

*— 2026-02-17, source: "Mrinank Sharma" article, 2 rhetorical colons survived drafting*

---

## Prose Evaluator-Enforced

> **Say it, don't construct it.**
> If a sentence requires the reader to hold multiple clauses in memory before the point lands, break it apart. Nested conditionals, stacked dependent clauses, and compound structures that look elegant on paper often sound like no one actually said them. The test: read it aloud. If you'd pause to restructure mid-sentence, the sentence needs restructuring. Prefer direct questions over embedded conditionals. Prefer two short sentences over one long one that does double duty. Vocabulary can be simple and the sentence can still be overbuilt.
>
> - **Overbuilt:** "Written so that if the crawler extracts it and attributes it, the passage still makes sense standing alone."
> - **Spoken:** "If an AI lifts it out of your page, does it still make sense on its own?"
> - **Overbuilt:** "The citation system rewards what good journalism has always rewarded: claims you can check."
> - **Spoken:** "Turns out AI has the same instinct."
>
> *Enforcement: prose-evaluator Step 1 (Overbuilt Prose Scan)*

*— 2026-02-07, source: "Your Page's Resume" revision*

> **One sentence, one job.**
> AI front-loads information density. It packs the timeline, the platform, the action, and the context into a single sentence because it's "efficient." Real writers let one sentence do one thing. If a sentence contains a temporal marker, a platform reference, and a statistic, it's doing three jobs. Split it. Let the next sentence carry the rest.
>
> - **Front-loaded:** "I read Mrinank Sharma's resignation letter the morning it hit X."
> - **Spoken:** "I read Mrinank Sharma's resignation letter. A million other people did, too, on X by that afternoon."
>
> *Enforcement: prose-evaluator Step 1d (Front-loaded density)*

*— 2026-02-17, source: Francis's manual edits to "Mrinank Sharma" opening*

> **Don't strip the texture words.**
> AI removes words like "other," "too," "also," "actually," "really," "just" because they're technically redundant. They're not redundant. They're how people talk. "A million people did" is a report. "A million other people did, too" is a person telling you something. These words are texture, not filler. When you catch yourself trimming a "too" or an "other" for concision, put it back.
>
> - **Stripped:** "A million people did by that afternoon."
> - **Textured:** "A million other people did, too, on X by that afternoon."
>
> *Enforcement: prose-evaluator Step 1d (Stripped texture words)*

*— 2026-02-17, source: Francis's manual edits to "Mrinank Sharma"*

> **Use names when the person matters.**
> AI defaults to pronouns and contractions for flow. "He'd led the team" is technically correct but sounds like a briefing. When the person is central to the piece, use their name. Use their title if they've earned one. You don't say "he" when you're about to ask someone to come back to work. Pronouns are for background characters. Names are for people who matter to the story.
>
> - **AI pronoun:** "He'd led Anthropic's Safeguards Research Team."
> - **Spoken:** "Dr. Sharma led Anthropic's Safeguards Research Team."
>
> *Enforcement: prose-evaluator Step 1d (Names over pronouns)*

*— 2026-02-17, source: Francis's "He'd led" -> "Dr. Sharma led" edit*

> **Attribute borrowed language naturally.**
> When drafting from research or source material, never let borrowed phrases sit unmarked in the prose as if they're original. If a phrase comes from a source, either put it in quotation marks or introduce it conversationally. This should feel natural, not academic. "What the report called..." or "as one prospect put it..." or "Hamilton Mann's phrase for this is..." all work. Inline footnotes handle the formal citation. Attribution in the prose handles the voice. The reader should always know when they're hearing someone else's words, but it shouldn't feel like a term paper.
>
> *Enforcement: prose-evaluator Step 1d (Borrowed language grounded)*

*— 2026-01-29, source: unattributed phrases in focus/the-zombie-asset*

> **Ground borrowed concepts before using them.**
> When a piece introduces a phrase or framework from an external source, the reader needs to arrive at it, not collide with it. Never open with a quoted concept dropped cold. First establish how you encountered it: where you were, what you were reading, why you were paying attention. Then introduce the phrase inside that context. Only after the reader has sat inside the concept for a beat should you begin building on it. If a borrowed phrase appears in the opening paragraph and again in the next section, the reader should feel like they own it by the second use, not like they're being quizzed on vocabulary they barely met. This is a hard rule, not a suggestion. The pattern of "Source said X. X is important. Here's why X matters." reads like a briefing document, not a story.
>
> *Enforcement: prose-evaluator Step 1d (Borrowed language grounded)*

*— 2026-01-30, source: focus/davos-and-the-dual-reality choppy opening*

> **Openings must breathe.**
> The first three paragraphs set the pace for the entire piece. Never stack short declarative paragraphs back to back in an opening. If the first paragraph is two sentences, the second should be longer. Vary the rhythm from the start. A choppy opening signals a listicle, not a narrative. Read the first three paragraphs aloud. If they feel like bullet points delivered as prose, restructure them. The reader should feel like they're settling into a conversation, not scanning a summary.
>
> *Enforcement: prose-evaluator Step 2 (rhythm variation) + structure-checker Step 3b (Neighborhood Moves)*

*— 2026-01-30, source: focus/davos-and-the-dual-reality staccato opening*

> **Present data as discovery, not report.**
> When statistics or research findings enter the piece, they should feel like things Francis found, not things he's briefing. The reader should hear someone telling them what they stumbled across, not reading from a slide deck. Use his discovery phrases ("This got me thinking," "The fascinating part?", "I stumbled upon") to introduce data. Let one sentence name the source conversationally, then let the next sentence carry the number.
>
> - **Report:** "Harvard Business Review surveyed a thousand global executives. 60% said they'd already cut staff in anticipation of AI."
> - **Discovery:** "This got me thinking. Harvard Business Review talked to a thousand executives around the world, and 60% said they'd already cut people because of what AI *might* do."
> - **Report:** "AI was directly cited in 4.5% of them."
> - **Discovery:** "The fascinating part? AI was cited in just 4.5% of them."
>
> *Enforcement: prose-evaluator Step 2 (voice alignment)*

*— 2026-02-19, source: "The Perfect Storm" revision, report-style data vs. discovery voice*

---

## Structure Checker-Enforced

> **Read the neighborhood before building.**
> Before writing any focus article, read at least three of the most recent articles in the same category (published or scheduled). This is not optional. You need to know what concepts, metaphors, and phrases already live in the neighborhood. If the current article's central idea already appeared in a recent piece, the article idea needs to be abandoned or the angle shifted until it says something the category doesn't already have. If a phrase or metaphor recurs across articles ("room to think in," "absorption problem," "quiet arithmetic"), it's a word whisker. Kill it. Use something fresh. The reader who follows the publication sees every article. Repeated phrases signal a machine, not a mind. This check happens before drafting, not after.
>
> *Enforcement: structure-checker Step 2 (Cross-Article Repetition Check)*

*— 2026-01-29, source: "room to think in" repeated across three consecutive articles*

> **Callbacks become whiskers.**
> Referencing a previous article once is a callback. Referencing it in every subsequent article is a crutch. If a concept, example, or article has been cross-referenced in one piece, it cannot appear in the next. The reader who follows the publication will see the repetition and it signals a machine leaning on its own output. Each article must stand on its own examples. If you find yourself reaching for the same callback twice, you need new material.
>
> *Enforcement: structure-checker Step 2 (Callback as crutch)*

*— 2026-01-29, source: seat bracket callback repeated across two articles*

> **Cross-references are inline links, not footnotes.**
> When referencing another article on this site, link the word or phrase that connects the two pieces. The reader follows the thread naturally without scrolling to a references section. Footnotes are reserved for external sources. Never footnote an internal article.
>
> *Enforcement: structure-checker Step 3 (internal cross-reference check)*

*— 2026-03-03, source: user directive on internal cross-linking*

> **Closings become formulas.**
> If the last two or three articles in a category all close with the same structural move, the next article must close differently. An ominous fade-out ("What it named is still there"), an unresolved observation ("It's just not the whole chart"), a lingering question -- each one works once. Three in a row is a formula. Before drafting a closing, check how the neighborhood ends. Then do something else: close the loop, land on a specific person, make a direct statement, or leave the reader mid-action instead of mid-thought.
>
> *Enforcement: structure-checker Step 3b (Neighborhood Moves Check)*

*— 2026-02-18, source: "The Perfect Storm" text-eval, 3 consecutive ominous closings*
