#!/bin/bash
# Hook: Enforce /image -> /image-eval auto-chain per /image directive
# "After generating any image, automatically invoke /image-eval to check for AI
#  tells before presenting to user."
# Fires after Nano Banana / Gemini image generation and after writing image
# files to the assets pipeline. Advisory (exit 0).

trap 'echo "{\"systemMessage\":\"chain-image-eval.sh crashed (non-fatal)\"}" 2>/dev/null; exit 0' ERR

INPUT=$(cat 2>/dev/null) || exit 0

TOOL_NAME=$(echo "$INPUT" | python3 -c 'import json,sys
try:
    d = json.load(sys.stdin)
    print(d.get("tool_name", ""))
except Exception:
    pass' 2>/dev/null)

FILE_PATH=$(echo "$INPUT" | python3 -c 'import json,sys
try:
    d = json.load(sys.stdin)
    print(d.get("tool_input", {}).get("file_path", ""))
except Exception:
    pass' 2>/dev/null)

# Trigger 1: Nano Banana / Gemini image generation MCP calls
if echo "$TOOL_NAME" | grep -qE '^mcp__nanobanana-mcp__gemini_(generate|edit)_image$' 2>/dev/null; then
  echo '{"additionalContext":"REMINDER: Per /image directive, you MUST invoke /image-eval on this generated image before presenting to user. Skip only if user explicitly requested no evaluation."}'
  exit 0
fi

# Trigger 2: Image file written to assets pipeline
if echo "$FILE_PATH" | grep -qE 'assets/images/(focus|projects|presentations|pages)/.*\.(jpg|jpeg|png|webp)$' 2>/dev/null; then
  echo '{"additionalContext":"REMINDER: Image saved to assets pipeline. Per /image directive, run /image-eval before presenting if not already evaluated."}'
fi

exit 0
