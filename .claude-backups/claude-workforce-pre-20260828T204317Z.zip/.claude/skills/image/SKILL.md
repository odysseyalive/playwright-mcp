---
name: image
description: Generate watercolor-style illustrations for this project's documentation using Nano Banana (Gemini 2.5 Flash) via the nanobanana-mcp server. Auto-chains to /image-eval after generation. Requires the nanobanana-mcp server + a Gemini API key to generate. Creative lane.
allowed-tools: Read, Glob, Grep, Bash, ToolSearch, Skill, Task
lane: creative
minimum-effort-level: xhigh
strictness: standard
---

# AI Image Generation

The site uses **watercolor-style imagery** generated via Nano Banana (Gemini 2.5 Flash).

---

<!-- origin: user | added: 2026-02-12 | immutable: true -->
## Directives

> **"After generating any image, automatically invoke /image-eval to check for AI tells before presenting to user."**

*— Added 2026-02-12, source: skill-builder audit (extracted from IMPORTANT note)*

> **"Always include watercolor base style: wet-on-wet technique, diffused edges, transparent layered washes, medium-rough cold-press paper texture."**

*— Added 2026-02-12, source: skill-builder audit (extracted from Base Style section)*

> **"Every image must be immediately understandable. If a viewer has to ask 'what is this?' the image has failed."**

*— Added 2026-02-12, source: skill-builder audit (extracted from Visual Clarity section)*

> **"Each image in a set should use a different palette variant. Same palette across all images = AI monotony."**

*— Added 2026-02-12, source: skill-builder audit (extracted from Article Image Workflow)*
<!-- /origin -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "Every image must be immediately understandable. If a viewer has to ask 'what is this?' the image has failed." -->
CHECKPOINT — Visual Clarity Gate:
1. Before presenting any generated image to the user, write a one-sentence description of what the image depicts — use only nouns for identifiable objects/scenes (e.g., "a watercolor of a boat on a dock at sunset"). Do NOT include abstract interpretations or metaphors.
2. IF the description cannot be written without abstract concepts, emotional labels, or "representing X" language → the image depicts an abstraction, not a concrete subject → STOP. Flag as unclear. Regenerate with more concrete scene direction.
3. IF the image contains ≥ 2 unrelated objects/subjects fighting for focus with no single anchor → STOP. Regenerate with a single concept anchored in the scene.
4. READ the planned caption (if any). IF the caption is required to make the image intelligible (e.g., the viewer would not know the image's subject from sight alone) → STOP. The image fails the caption test. Regenerate with a clearer concrete anchor.
5. IF a named subject/scene is present, a single concept is anchored, and the caption test passes → CONTINUE (next gate: /image-eval).
<!-- END ENFORCEMENT ANNOTATION -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "After generating any image, automatically invoke /image-eval to check for AI tells before presenting to user." -->
CHECKPOINT — Auto-Eval Chain Gate:
1. After every successful image generation (single image or batch), record the generated file path(s).
2. Before presenting any generated image to the user, invoke /image-eval on each generated image. The image-eval invocation is NOT optional and is NOT batched per-user-request — it runs on every generation.
3. IF /image-eval returns flags → present the flags to the user alongside the image, with regeneration as the recommended action.
4. IF /image-eval returns no flags → present the image with the eval result noted ("image-eval: clean").
5. IF /image-eval is skipped or its result is omitted from presentation → STOP. Re-run /image-eval before presenting. The PostToolUse hook (`image/hooks/chain-image-eval.sh`) is a backstop, not a substitute — the workflow itself must invoke /image-eval explicitly.
<!-- END ENFORCEMENT ANNOTATION -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "Always include watercolor base style: wet-on-wet technique, diffused edges, transparent layered washes, medium-rough cold-press paper texture." -->
CHECKPOINT — Base Style Mandatory Inclusion Gate:
1. Before submitting any prompt to the image generator, inspect the prompt text for the base-style phrases: "wet-on-wet", "diffused edges", "transparent layered washes", "cold-press paper" (or close paraphrases).
2. Count phrases present. The base style requires ALL FOUR distinct concepts in some form: technique (wet-on-wet), edge quality (diffused), layering (transparent washes), and paper texture (cold-press).
3. IF count < 4 → STOP. Append the missing phrases to the prompt using the base-style template from this skill's "Base Style (Always Include)" section.
4. IF count == 4 → CONTINUE to generation.
5. The Base Style block applies to every generation — no exceptions for "stylized variants", "abstract pieces", or "test runs". The watercolor signature must be present every time.
<!-- END ENFORCEMENT ANNOTATION -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "Each image in a set should use a different palette variant. Same palette across all images = AI monotony." -->
CHECKPOINT — Palette Variation Gate:
1. Detect set context: an image is part of a "set" when (a) the user requests multiple images in one invocation, (b) the workflow is generating hero + inline images for a single article, or (c) more than 1 image is queued for the same content slug.
2. IF set context detected → assemble a palette plan BEFORE the first generation: assign a distinct palette variant to each image in the set. Read `references/palettes.md` for the full palette table.
3. For EACH image in the set, the prompt must include the assigned palette variant verbatim.
4. IF two images in the same set share a palette variant → STOP. Reassign one before generation. The set must demonstrate palette variation by design, not by accident.
5. Single-image generations (no set context) → CONTINUE without palette planning. The default palette + base style is sufficient.
<!-- END ENFORCEMENT ANNOTATION -->

---

<!-- MODEL-LANE-GATE START — auto-generated by /skill-builder route embed; safe to replace -->
<!-- origin: skill-builder | modifiable: true -->
## Model-Lane Preflight

<!-- ENFORCEMENT ANNOTATION — Opus 4.7+ literal-execution gate -->
<!-- Source: /skill-builder route embed (model-lane gate, slim form per the 2026-06-06 2-Brain Harness directive: gates are slimmed, never stripped — this block is the lane checkpoint that travels with the skill through EVERY entry path, including hand-run invocations, which are always permitted. It goes silent when /route already covered the endeavor. The gate CANNOT switch the model; it only prompts the user to run /model. -->
CHECKPOINT — Model-Lane Preflight Gate (slim; fires at the TOP of this skill's workflow, before any generative step):
1. SKIP silently IF ANY of: `/route` dispatched this invocation after running its own lane preflight (a model-lane prompt already fired or was deliberately suppressed this user turn — route's coverage extends to the whole endeavor, including skills this one chains); this skill's frontmatter sets `model-lane-gate: off`; the session is headless / non-interactive; this gate is executing inside a subagent (a subagent cannot prompt the user and is already model-pinned via its own frontmatter); OR a prior "skip once"/"continue anyway" for this LANE is still standing AND the active model is unchanged since that choice (the opt-out is keyed to the (lane, active-model) pair — it self-expires the moment the user runs `/model`).
2. Resolve this skill's lane (own `lane:` frontmatter → the Skill→Lane table in `.claude/skills/skill-builder/references/model-lanes.md` → NO LANE) and the lane's Preferred Model. IF no lane resolves OR the preferred-model cell is empty → silent no-op (correctly absent, not a gap). IF this skill declares per-function lanes AND the invocation's resolved mode has its own row → that function's lane governs; otherwise the skill-level lane covers all modes.
3. Read ACTIVE_MODEL from the session system-context line "The exact model ID is …" (strip `[1m]`/`[200k]`, lowercase — model-lanes.md § Active-Model Detection; never an env var or Bash probe). IF the Preferred Model is malformed or names a clearly superseded family → emit the one-line stale-mapping advisory and proceed; never prompt from a stale mapping, never validate against a hardcoded list.
4. Compare. Match → silent no-op. Mismatch → STOP before any generative step and prompt ONCE via AskUserQuestion (plain text fallback): "This work is in the `<lane>` lane (preferred `<preferred>`); the active model is `<active>`. Run `/model` to switch?" — options EXACTLY **switched** / **skip once** / **continue anyway**. A skill can NEVER switch the session model. After "switched": re-read the model line exactly once and proceed either way without looping. After an opt-out: record it keyed to (lane, active-model) per clause 1 and proceed.
5. Primary-lane scope. This gate fires ONCE per invocation, for the resolved PRIMARY lane. Cross-lane mid-workflow steps never re-prompt — they delegate via this skill's LANE-AGENT-EMBED Delegation Map when present (see .claude/skills/skill-builder/references/lane-delegation.md). Delegation is never a substitute for THIS gate: analytical primary work runs on the analytical main model — never a creative main session orchestrating analytical-pinned agents to avoid a switch.
<!-- END ENFORCEMENT ANNOTATION -->
<!-- /origin -->
<!-- MODEL-LANE-GATE END -->

---

## Base Style (Always Include)

```
A watercolor painting of [SCENE]. [SCENE DETAILS]. Wet-on-wet technique with diffused edges and seamless color blending. Transparent layered washes. Medium-rough cold-press paper texture. Painting fades softly into white paper at the edges, unfinished border with visible raw paper showing through. Aspect ratio [RATIO].
```

---

## Aspect Ratios

See [references/aspect-ratios.md](references/aspect-ratios.md) for the full table and common use cases.

**Common:**
- Full-width hero banners: 21:9
- Standard hero images: 16:9
- Article headers/cards: 4:3

---

## Palette Selection

See [references/palettes.md](references/palettes.md) for the full palette table.

**IMPORTANT:** Always include "rich and vibrant, not pale or faded" in non-default palettes. Don't default to Warm Earth for everything. See also `palettes.md` in this skill folder for full palette reference.

---

## Visual Clarity Over Abstraction

**Every image must be immediately understandable.** If a viewer has to ask "what is this?" the image has failed.

See [references/visual-clarity.md](references/visual-clarity.md) for detailed criteria.

**Quick Rules:**
- Concrete over abstract
- One concept per image
- Grounded in the article's world
- Pass the caption test (if the caption needs explanation, the concept is too abstract)

---

## Article Image Workflow

**Grounding:** Read [references/workflow.md](references/workflow.md) for the full 6-step workflow (palette planning → generation → validation → evaluation → regeneration → presentation).

**Key rule:** Each image uses a different palette variant. Same palette across all = AI monotony. Run image-validator agent AND `/image-eval` before presenting. Do not skip evaluation.

---

## Saving Generated Images

See [references/saving.md](references/saving.md) for detailed paths and examples.

**Quick Reference:**
- Hero images: `assets/images/focus/hero/[article-slug]-hero.jpg`
- Inline images: `assets/images/focus/inline/[article-slug]/[image-name].jpg`
- Project heroes: `assets/images/projects/hero/[project-slug]-hero.jpg`

Run `pnpm dev` or `pnpm build` to process through Velite.

---

## Image Maintenance

See [references/maintenance.md](references/maintenance.md) for:
- Converting PNG to JPG (with site background color)
- Removing AI signatures without regeneration

---

