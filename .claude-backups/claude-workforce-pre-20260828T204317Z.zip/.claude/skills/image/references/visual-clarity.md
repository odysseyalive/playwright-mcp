## Visual Clarity Rules

**Every image must be immediately understandable.** If a viewer has to ask "what is this?" the image has failed.

### Rules for Clear Visual Metaphors

1. **Concrete over abstract.** Show recognizable objects and scenes, not symbolic shapes or vague concepts.

2. **One concept per image.** Don't try to visualize multiple metaphors simultaneously.

3. **Grounded in the article's world.** If the article discusses manufacturing, show manufacturing.

4. **The caption test.** Before generating, write the caption. If it requires explanation, the concept is too abstract.

5. **Avoid:**
   - Symbolic abstractions (glowing orbs, floating shapes, light beams)
   - Split-screen contrasts that require interpretation
   - Metaphors layered on metaphors
   - Anything that looks like stock illustration AI art

### Good Examples

- Supply chain constraints → A warehouse with boxes stacked against a closed loading dock
- Organizational resistance → An empty conference room with chairs pushed back
- AI and manufacturing → A factory floor with a single intricate part on a workbench

### Bad Examples

- Supply chain constraints → Gears and flowing rivers (too abstract)
- Organizational resistance → A wall of ice melting (too symbolic)
- Innovation → Light bulbs and brain imagery (cliché)
