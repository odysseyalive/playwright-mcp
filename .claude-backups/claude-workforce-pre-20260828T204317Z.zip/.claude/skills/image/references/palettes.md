## Palette Variants

**IMPORTANT:** Always include "rich and vibrant, not pale or faded" in non-default palettes to prevent washed-out results. Avoid "dreamy, luminous, gentle" except for Warm Earth.

| Variant | Use For | Key Colors |
|---------|---------|------------|
| **Warm Earth** (default) | Cozy, reflective, human-centered | Sienna, ochre, burnt orange, blue-grey shadows |
| **Cool Industrial** | Technology, machinery, corporate | Steel blues, slate greys, cool teals, amber accents |
| **Verdant** | Nature, growth, organic | Sage greens, moss, olive, warm gold accents |
| **Saturated Pop** | Energy, contrast, key moments | Full saturation focal areas, softer edges |
| **Night/Moody** | Evening, rain, contemplative | Deep indigo, midnight blue, orange-amber glow |

Don't default to Warm Earth for everything. Let the scene determine the palette.
