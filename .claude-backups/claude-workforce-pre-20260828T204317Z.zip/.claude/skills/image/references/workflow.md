# Article Image Workflow

When generating images for an article (hero + 2 inline):

## 1. Plan Palettes First

Before generating any images, assign a different palette variant to each:

```
Hero:     [palette] — [why it fits the scene]
Inline 1: [palette] — [why it fits the scene]
Inline 2: [palette] — [why it fits the scene]
```

**Rule:** Each image should use a different palette variant. Same palette across all images = AI monotony.

## 2. Generate All Images

Generate hero and both inline images with their assigned palettes.

## 3. Run Image Validator (Required)

Spawn the image-validator agent with all three image paths. If INVALID, fix before proceeding. See [../agents/image-validator/AGENT.md](../agents/image-validator/AGENT.md) for invocation template.

## 4. Run Image Set Evaluation (Required)

After validation passes, invoke `/image-eval` with all three image paths for AI tell and palette variation checks.

## 5. Regenerate If Flagged

If evaluation flags palette monotony or other issues:
- Regenerate the flagged image(s) with a different palette
- Re-run evaluation to confirm the fix

## 6. Present to User

Only after the image set passes evaluation, present the article with images.

**Do not skip the evaluation step.**
