## Image Maintenance

### Converting PNG to JPG

When Nano Banana generates PNG files that need to be JPG, use ImageMagick's `magick` command. Always flatten with the site's background color (`#FDF8F0`) to avoid black borders from transparency:

```bash
magick input.png -background '#FDF8F0' -flatten output.jpg
```

To convert and remove the original PNG in one step:
```bash
magick input.png -background '#FDF8F0' -flatten output.jpg && rm input.png
```

### Removing AI Signatures

Generated images sometimes include unwanted signatures or watermarks in corners. **Do not regenerate the entire image.** Use Nano Banana's edit function to surgically remove the signature while preserving everything else.

#### Scrubbing Process

1. **Identify the signature location** (usually bottom right corner)

2. **Use the edit tool with the original image:**
```
mcp__nanobanana-mcp__gemini_edit_image
- image_path: [path to image with signature]
- edit_prompt: "Remove the signature in the bottom right corner. Keep everything else exactly the same. The area should blend naturally with the surrounding watercolor paper texture and painting."
- aspect_ratio: [same as original, e.g., "4:3"]
- output_path: [path for edited version]
```

3. **Convert to JPG** (if output is PNG):
```bash
magick edited.png -background '#FDF8F0' -flatten final.jpg
```

4. **Replace the original** with the cleaned version

#### Why Edit Instead of Regenerate

- Preserves the composition, colors, and details you already approved
- Faster than regenerating and re-evaluating
- Avoids the risk of getting a worse image on regeneration
- The edit tool is precise enough to remove small artifacts without affecting the rest
