---
name: image-eval
description: Evaluate generated images for AI generation tells and watercolor authenticity. Run as Task agent for unbiased assessment. Creative lane.
allowed-tools: Read, Glob, Grep, Task
lane: creative
minimum-effort-level: high
strictness: standard
---

# Image Evaluation Protocol

**IMPORTANT:** Run this evaluation as a **Task agent** to ensure context isolation. The agent evaluates without being influenced by the conversation that created the content.

---

<!-- origin: user | added: 2026-06-06 | immutable: true -->
## Directives

> **"Required checks come first. Always perform signature, symmetry, and palette checks before subjective evaluation. Report findings explicitly. Do not assume or skip."**

*— Added 2026-06-06, source: Hand-Written Skill Intake (audit) — pre-existing rule ratified verbatim from Important Notes*

> **"Advisory, not prescriptive. Flags prompt human judgment, not automatic regeneration."**

*— Added 2026-06-06, source: Hand-Written Skill Intake (audit) — pre-existing rule ratified verbatim from Important Notes*

> **"One pass, then stop. Present evaluation once. Human decides whether to regenerate."**

*— Added 2026-06-06, source: Hand-Written Skill Intake (audit) — pre-existing rule ratified verbatim from Important Notes*

> **"Be selective. 3-5 substantive flags maximum. Don't nitpick every detail."**

*— Added 2026-06-06, source: Hand-Written Skill Intake (audit) — pre-existing rule ratified verbatim from Important Notes*
<!-- /origin -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "Required checks come first. Always perform signature, symmetry, and palette checks before subjective evaluation. Report findings explicitly. Do not assume or skip." -->
CHECKPOINT — Required-Checks Ordering Gate:
1. Before any subjective evaluation (AI patterns, watercolor authenticity, style consistency) runs, perform the three required checks per references/invocation.md: signature/watermark scan, symmetry check, palette check.
2. Record each check's result explicitly in a Verification Preamble at the top of the output. Format: "Signature: [finding/none] | Symmetry: [finding/none] | Palette: [variant identified]".
3. IF the preamble is missing from the output → STOP. The evaluation is invalid; rerun starting from step 1.
4. IF any required check was skipped or assumed-clean without being performed → STOP. Run the check. Do not assume images are clean.
5. IF all three checks ran and the preamble is present → CONTINUE to subjective evaluation.
<!-- END ENFORCEMENT ANNOTATION -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "Advisory, not prescriptive. Flags prompt human judgment, not automatic regeneration." -->
CHECKPOINT — Advisory-Verdict Gate:
1. After the evaluation completes, inspect every flag and the closing recommendation.
2. IF any output line instructs automatic regeneration, auto-invokes /image, or treats a flag as a blocking gate the human cannot override → STOP. Rewrite the verdict as advisory: flag + reasoning + "regeneration recommended" at most.
3. The evaluator NEVER triggers regeneration itself. Presenting flags alongside the image with a recommended action is the ceiling of its authority.
4. IF all flags read as input to human judgment → CONTINUE.
<!-- END ENFORCEMENT ANNOTATION -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "One pass, then stop. Present evaluation once. Human decides whether to regenerate." -->
CHECKPOINT — Single-Pass Gate:
1. Track invocation count per image (or image set) in this evaluation cycle. The first invocation is pass 1.
2. Pass 1 → run the full evaluation, present it once, then HALT. Do not auto-rerun, refine, or second-guess the presented evaluation.
3. IF a further pass is requested without explicit user instruction (or without a fresh regeneration of the image, which starts a new cycle) → STOP. Report: "Single-pass rule: evaluation already presented. Awaiting human decision."
4. A regenerated image is new content → its evaluation is pass 1 of a new cycle, not a violation.
<!-- END ENFORCEMENT ANNOTATION -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "Be selective. 3-5 substantive flags maximum. Don't nitpick every detail." -->
CHECKPOINT — Flag Selectivity Gate:
1. After collecting all candidate flags, count them.
2. IF count > 5 → keep the 5 most substantive (highest impact on whether the image works) and discard the rest. Add a one-line trailer: "Elided [N] lower-priority observations to stay within the 5-flag cap."
3. Required-check findings (signature, symmetry, palette — per the Required-Checks Ordering Gate) are verification results, not subjective flags; they are always reported in the preamble and do NOT count against the cap.
4. IF count ≤ 5 → report all. Never pad to reach a minimum.
<!-- END ENFORCEMENT ANNOTATION -->

---

<!-- MODEL-LANE-GATE START — auto-generated by /skill-builder route embed; safe to replace -->
<!-- origin: skill-builder | modifiable: true -->
## Model-Lane Preflight

<!-- ENFORCEMENT ANNOTATION — Opus 4.7+ literal-execution gate -->
<!-- Source: /skill-builder route embed (model-lane gate, slim form per the 2026-06-06 2-Brain Harness directive: gates are slimmed, never stripped — this block is the lane checkpoint that travels with the skill through EVERY entry path, including hand-run invocations, which are always permitted. It goes silent when /route already covered the endeavor. The gate CANNOT switch the model; it only prompts the user to run /model. -->
CHECKPOINT — Model-Lane Preflight Gate (slim; fires at the TOP of this skill's workflow, before any generative step):
1. SKIP silently IF ANY of: `/route` dispatched this invocation after running its own lane preflight (a model-lane prompt already fired or was deliberately suppressed this user turn — route's coverage extends to the whole endeavor, including skills this one chains); this skill's frontmatter sets `model-lane-gate: off`; the session is headless / non-interactive; this gate is executing inside a subagent (a subagent cannot prompt the user and is already model-pinned via its own frontmatter); OR a prior "skip once"/"continue anyway" for this LANE is still standing AND the active model is unchanged since that choice (the opt-out is keyed to the (lane, active-model) pair — it self-expires the moment the user runs `/model`).
2. Resolve this skill's lane (own `lane:` frontmatter → the Skill→Lane table in `.claude/skills/skill-builder/references/model-lanes.md` → NO LANE) and the lane's Preferred Model. IF no lane resolves OR the preferred-model cell is empty → silent no-op (correctly absent, not a gap). IF this skill declares per-function lanes AND the invocation's resolved mode has its own row → that function's lane governs; otherwise the skill-level lane covers all modes.
3. Read ACTIVE_MODEL from the session system-context line "The exact model ID is …" (strip `[1m]`/`[200k]`, lowercase — model-lanes.md § Active-Model Detection; never an env var or Bash probe). IF the Preferred Model is malformed or names a clearly superseded family → emit the one-line stale-mapping advisory and proceed; never prompt from a stale mapping, never validate against a hardcoded list.
4. Compare. Match → silent no-op. Mismatch → STOP before any generative step and prompt ONCE via AskUserQuestion (plain text fallback): "This work is in the `<lane>` lane (preferred `<preferred>`); the active model is `<active>`. Run `/model` to switch?" — options EXACTLY **switched** / **skip once** / **continue anyway**. A skill can NEVER switch the session model. After "switched": re-read the model line exactly once and proceed either way without looping. After an opt-out: record it keyed to (lane, active-model) per clause 1 and proceed.
5. Primary-lane scope. This gate fires ONCE per invocation, for the resolved PRIMARY lane. Cross-lane mid-workflow steps never re-prompt — they delegate via this skill's LANE-AGENT-EMBED Delegation Map when present (see .claude/skills/skill-builder/references/lane-delegation.md). Delegation is never a substitute for THIS gate: analytical primary work runs on the analytical main model — never a creative main session orchestrating analytical-pinned agents to avoid a switch.
<!-- END ENFORCEMENT ANNOTATION -->
<!-- /origin -->
<!-- MODEL-LANE-GATE END -->

## How to Invoke

Launch the watercolor-evaluator agent via Task tool with `context: none`. See [references/invocation.md](references/invocation.md) for single-image and article-set templates, and [agents/watercolor-evaluator/AGENT.md](agents/watercolor-evaluator/AGENT.md) for evaluation criteria.

---

## When to Run

Execute this evaluation after:
- Generating images via Nano Banana
- Creating hero images for articles
- Producing inline images for content
- Any visual content creation

---

## Required Verification Steps

**Before subjective evaluation, perform these checks.** Do not skip. Do not assume images are clean. See [references/invocation.md](references/invocation.md) for signature/watermark, symmetry, and palette checks.

---

## Evaluation Criteria

See references for detailed criteria:
- **[Visual Clarity](references/visual-clarity.md)** — Immediate comprehension, concrete subjects, grounded imagery
- **[Common AI Image Patterns](references/ai-patterns.md)** — Symbolic abstraction, impossible lighting, uncanny artifacts
- **[Watercolor Technique Authenticity](references/watercolor.md)** — Physical constraints, edge quality, bloom patterns
- **[Style Consistency](references/invocation.md#style-consistency)** — Watercolor aesthetic checklist
- **[Output Templates](references/templates.md)** — Single image and article set evaluation formats

Cross-reference `/image` skill for full visual clarity guidelines.

---

## Important Notes

*(The required-checks, advisory, single-pass, and selectivity rules moved to § Directives above — ratified 2026-06-06.)*

- **View in context.** An image that looks off in isolation might work perfectly with the article.
- **Specificity matters.** "Looks AI-generated" is useless. "The lighting on the left contradicts the window placement on the right" is actionable.
- **Preserve what works.** Note strengths so regeneration prompts retain successful elements.

---

