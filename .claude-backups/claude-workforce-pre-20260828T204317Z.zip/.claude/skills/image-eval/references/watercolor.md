## Watercolor Technique Authenticity

Real watercolor has physical constraints. Flag images that violate these:

| Impossible Technique | Why It Can't Exist | What to Look For |
|---------------------|-------------------|------------------|
| **White painted over color** | Watercolor is transparent; white comes from unpainted paper | Bright white details appearing on top of darker washes |
| **Light over dark layering** | You can only go darker in watercolor, never lighter | Pale colors sitting visibly on top of dark areas |
| **Uniformly hard edges** | Water naturally bleeds; edges vary based on wetness | Every edge crisp and defined throughout |
| **Perfect smooth gradients** | Real gradients have blooms, granulation, pigment settling | Digitally smooth color transitions with no texture |
| **Opaque flat coverage** | Watercolor is inherently transparent | Large areas of solid, uniform color with no variation |
| **No paper texture visible** | Pigment settles into paper grain, especially in washes | Smooth surfaces with no tooth or texture |
| **Crisp fine details** | Pigment bleeds on wet paper; fine lines feather | Sharp text, thin lines, or precise small details |
| **Absent cauliflowering** | Wet-on-drying creates blooms; it's unavoidable | Large wash areas with perfectly uniform edges |
| **Impossible bloom placement** | Blooms happen at wet/drying boundaries | Watercolor effects in areas that would dry uniformly |
| **Consistent edge quality** | Real paintings have varied edges (wet vs. dry application) | Every edge in the image has identical softness |
| **Symmetric organic effects** | Water doesn't create bilateral symmetry | Perfectly mirrored blooms, drips, or wash patterns |
| **Colors mixing impossibly** | Some pigments granulate, separate, or don't mix cleanly | Colors blending in ways that defy pigment physics |

### Quick Authenticity Test

Ask: "Could a skilled watercolorist actually paint this?"

If achieving a specific effect would require:
- Painting light over dark
- Preventing all bleeding on wet paper
- Creating perfectly uniform washes
- Adding opaque white highlights

...then the image betrays its digital origin.
