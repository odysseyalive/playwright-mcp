## Required Checks Output Formats

### Signature/Watermark Check

```
Signature check: [found/none]
- Location: [corner/edge if found]
```

### Symmetry Assessment

```
Symmetry check:
- [Image name]: [symmetric/asymmetric] — [brief note]
```

### Palette Identification (For Article Sets)

```
Palette identification:
- Hero: [palette name or 2-3 dominant colors]
- Inline 1: [palette name or 2-3 dominant colors]
- Inline 2: [palette name or 2-3 dominant colors]
- Variation verdict: [sufficient/insufficient]
```
