## Visual Clarity

| Criterion | What to Flag |
|-----------|--------------|
| **Immediate comprehension** | Viewer needs to ask "what is this?" |
| **Concrete vs. abstract** | Symbolic shapes, glowing orbs, floating geometry |
| **Grounded in article's world** | Visual domain doesn't match the content |
| **One concept per image** | Multiple metaphors layered |
| **Caption test** | Caption requires explanation of what image represents |
