## Article-Level Palette Variation

### The Problem: AI Defaults to Sameness

AI image generators tend to lock onto one palette and repeat it. "Blue + orange" three times. "Warm earth tones" three times. This is an AI tell. A human artist naturally varies palette choices based on what each individual image needs.

### The Rule: Different Palettes, Same Style

The images should share the watercolor technique and aesthetic, but **use different palette variants**. The cohesion comes from the medium, not the colors.

| Scenario | Verdict |
|----------|---------|
| All three images: blue + orange | **Flag** — AI monotony |
| All three images: same two dominant colors, different ratios | **Flag** — still monotony |
| Hero: Cool Industrial / Inline 1: Warm Earth / Inline 2: Verdant | **Good** — real variety |
| Hero: Night/Moody / Inline 1: Saturated Pop / Inline 2: Cool Industrial | **Good** — distinct moods |
| Two share a palette, one differs | **Acceptable** — if intentional |

### Why Variety is More Human

A human illustrator choosing images for an article asks: "What palette fits *this* scene?" They don't ask: "How do I repeat the hero's colors?"

- A dashboard scene might call for Cool Industrial
- A citation network might call for Warm Earth (illuminated documents = warm sienna)
- A server architecture might call for Night/Moody or Cool Industrial

Let each image breathe. Match palette to subject, not palette to palette.

### The Test

View all three images as thumbnails. If they look like the same color scheme, flag it. You should see distinctly different color impressions.
