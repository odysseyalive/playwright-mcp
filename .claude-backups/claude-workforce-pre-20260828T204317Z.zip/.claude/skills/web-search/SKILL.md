---
name: web-search
description: "Search the web, then verify and cite the results. Native WebSearch for discovery + playwright-mcp web_fetch for a stealth-rendered double-check (readable text, CSL-JSON citations, page-health). Use for any web search/lookup where you want verified, cited sources rather than raw result snippets. Usage: /web-search <query>"
allowed-tools: WebSearch, mcp__playwright-mcp__web_fetch, Read, Task
lane: coding
minimum-effort-level: high
---

# Web Search

The steered path for web searching in this project. It **overtakes ad-hoc search**:
discovery runs on Claude's native server-side `WebSearch` (no exposure of the
user's IP — it never touches the scraping/CAPTCHA/IP-reputation problem), and the
playwright-mcp `web_fetch` tool double-checks the top results — stealth-rendering
each page for readable text, CSL-JSON author/date/CMS citations, and page-health.

This replaced the removed scraping `web_search` MCP tool — see ledger
`DEC-2026-06-08-native-websearch-webfetch-doublecheck`. The MCP server cannot call
native `WebSearch`, so this orchestration lives here, in-session, where both the
native tool and `web_fetch` are reachable.

## Usage

```
/web-search <query>
```

Optionally: `/web-search <query> --verify N` (fetch top N, default 5),
`--research` (links mode + source-appraisal flag), `--quick` (discovery only, no
double-check — fast, snippet-level).

## When to use

- Any "search the web / look this up / find sources on X" request where you want
  **verified, cited** sources rather than raw engine snippets.
- NOT for full cited papers — defer to the `research-paper` skill for those
  (thesis, gap-fill, adversarial citation verification, 1300–1500 words).
- NOT a scraper: never scrape Google/Bing/DuckDuckGo and never use engine APIs.
  Discovery is **exclusively** native `WebSearch`; all fetching goes through
  `web_fetch` (native `WebFetch` stays denied).

## Workflow

### 1. Discover (native WebSearch)

Call the native **`WebSearch`** tool with the query. Take its ranked results
(title + URL + snippet). This is the only discovery source — do not scrape.

- `--quick` → stop here: return the native results as-is (fast, snippet-level).
  Use only when the user explicitly wants speed over verification.

### 2. Double-check (web_fetch)

For the top **N** results (default 5), call **`mcp__playwright-mcp__web_fetch`**
(`{ url }`; add `links: true` and `quality: 'research'` under `--research`).
For each, read the returned `fetchStatus`:

| fetchStatus | action |
|---|---|
| `ok` | keep — attach `citation` (CSL-JSON) + a short extract from `text` |
| `paywall` / `login-wall` | keep, but **flag** the access barrier (content unverified) |
| `404` / `parked` / `blocked` | **demote**; backfill from the next native result |

`web_fetch` returns `{ url, fetchStatus, contentType, cms, text, citation, links?,
references? }`. Citations come from `web_fetch` — never hand-fabricate
author/date; if `citation.dateConfidence` is `low`, say so.

Pace the fetches (they hit real sites); the tool already enforces a stealth delay.

### 3. Rank + return

Order best→worst by relevance to the query, breaking ties toward `fetchStatus: ok`
+ higher-confidence citations. For each kept result present: title, URL,
one-line why-relevant, the citation (author/date/publisher), and a short extract.
Flag every demoted/paywalled source explicitly so the user knows what was and
wasn't verified. Never present an unfetched or `blocked` source as confirmed.

### 4. Follow-ups

Anything beyond a verified search list (a synthesized cited paper, deeper
multi-level research) → route to the `research-paper` skill via `/route`; do not
freelance a research report here.

## Grounding

- Ledger `DEC-2026-06-08-native-websearch-webfetch-doublecheck` — why discovery is
  native and the double-check is `web_fetch`.
- `web_fetch` contract: `src/tools/web-fetch.ts` (options + return shape +
  `fetchStatus` enum); extraction internals in `src/extract.ts`.
- For full cited papers: the `research-paper` skill.
