# Awareness Ledger — Capture Triggers

Conversation signals that suggest a record should be created, plus the
routing boundary between the ledger and Claude Code's auto memory.

---

## Incident Triggers

- Rollback or revert language: "roll back," "revert," "undo," "broke," "regression"
- Error investigation: "root cause," "why did this," "what went wrong"
- Post-fix reflection: "that was caused by," "the fix was," "lesson learned"

## Decision Triggers

- Choice justification: "I chose X because," "we should use X instead of Y"
- Trade-off discussion: "the trade-off is," "downside of this approach"
- Architecture language: "going forward," "from now on," "the pattern should be"

## Pattern Triggers

- Repeated observation: "this keeps happening," "every time we," "I've noticed"
- Rule discovery: "turns out," "the trick is," "what works is"
- Exception identification: "except when," "doesn't apply to," "unless"

## Flow Triggers

- Step-by-step debugging: "first it does X, then Y, then Z"
- User behavior description: "when the user does X," "the flow is"
- Environment-specific: "only happens when," "requires X to be running"

## Memory Triggers — Route to Auto Memory, Not the Ledger

Some signals look capture-worthy but belong in Claude Code's auto memory
(per-user-per-machine ergonomics), not the ledger. When you detect one of
these, suggest a memory entry and bail out of ledger capture:

- **Writing tics / preferences:** "I always use…," "don't write it like…," "my voice is…"
- **Notation / formatting rules:** percent sign vs. spelled-out, capitalization, abbreviation choices
- **Humor calibration:** when a joke lands or misses; tone preferences
- **Tool aliases / invocation habits:** shortcut commands, env var defaults, shell aliases, "when I say X I mean Y"
- **Transient session state:** where we were mid-task, what to resume, open tabs

**Ownership boundary:** auto memory owns per-user-per-machine ergonomics; the
ledger owns project-shareable records (INC, DEC, PAT, FLW) that travel with the
repo. When a fact straddles both, the ledger record is canonical and the memory
entry references the ledger ID instead of re-narrating the facts.

**Bail-out rule:** if the fact would not survive a teammate opening the repo on
a fresh machine — and the project would not suffer from its absence — it belongs
in auto memory. Route the user there instead of opening a ledger record.

**Capture is always user-confirmed.** Agents suggest, user decides. Directives
are sacred — never auto-record.
