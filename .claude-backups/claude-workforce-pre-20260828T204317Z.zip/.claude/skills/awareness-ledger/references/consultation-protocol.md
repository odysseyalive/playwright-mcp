# Awareness Ledger — Consultation Protocol

How agents query the ledger: triage rules, proportional agent spawning,
synthesis rules, and the briefing format.

---

## Triage Rules

1. Read `ledger/index.md` first — always. The index is small; this step is free.
2. Match the current change context (file paths, function names, components,
   domain tags) against the index's By Tag section.
3. No matches → report "No Records" (briefing format below) and stop. An empty
   or non-matching ledger has zero consultation overhead.
4. Matches found → spawn agents per the proportional table below.

## Proportional Overhead Rules

| Match Scope | Agents Spawned | Rationale |
|-------------|----------------|-----------|
| No records match | None | Zero overhead until records exist |
| Only incidents/flows match | Regression Hunter only | Single relevant perspective |
| Only decisions/patterns match | Skeptic only | Single relevant perspective |
| Risk/failure language detected | Premortem Analyst only | Targeted premortem |
| Multiple record types match | All three agents (full panel) | Cross-referencing needed |

## Synthesis Rules

- **Agreement = HIGH confidence.** When two or more agents flag the same record
  or risk, present it as a Warning.
- **Disagreement = the signal.** When agents disagree, do not average them away —
  present each agent's finding side by side as a Consideration and investigate
  the disagreement.
- Records that are relevant but carry no warning go under Context.

## Consultation Briefing Format

```markdown
## Ledger Consultation

### Warnings (HIGH confidence — agents agree)

- **[Warning]** — [INC/DEC/PAT/FLW reference] — [one-line explanation]

### Considerations (agents disagree — investigate the disagreement)

- **[Topic]**
  - Regression Hunter: [finding]
  - Skeptic: [finding]
  - Premortem Analyst: [finding]

### Context (relevant records, no warnings)

- [ID] — [why it's relevant but not a warning]

### No Records

No ledger records match the current context. Proceeding without historical consultation.

### Capture Opportunity

The current conversation contains knowledge not yet in the ledger:
- **Suggested type:** [INC/DEC/PAT/FLW]
- **Suggested ID:** [auto-generated from context]
- **Source material:** [quote from conversation]

Confirm to record, or skip.
```
