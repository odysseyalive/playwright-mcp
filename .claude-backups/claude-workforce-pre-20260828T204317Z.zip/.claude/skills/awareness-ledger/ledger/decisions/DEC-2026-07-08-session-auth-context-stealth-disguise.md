# DEC-2026-07-08-session-auth-context-stealth-disguise

**Status:** accepted
**Tags:** session-management, authentication, stealth-scraping, src/tools/session.ts, src/browser.ts, src/stealth.ts, session_login, session_status, bot-detection, debugging
**Related:** DEC-2026-06-07-authenticated-session-storagestate-artifact, DEC-2026-06-07-web-search-three-engine-stealth, DEC-2026-06-08-native-websearch-webfetch-doublecheck, DEC-2026-07-21-session-login-challenge-capture-mode

## Context

While tracing where session.ts's "the auth context is ISOLATED from the stealth
context — they never merge" rule comes from (it traces to
DEC-2026-06-07-authenticated-session-storagestate-artifact § Context isolation),
the user flagged a real defect: **"this package has stealth capabilities. That
breaks when this directive is followed."**

Inspection confirmed it. `src/tools/session.ts` created a **naked headless**
browser for both `session_login` capture and the `session_status` probe:

```ts
browser = await chromium.launch({ headless: !opts.headed });
const context = await browser.newContext({ ignoreHTTPSErrors: true });
```

No UA override (advertises the `HeadlessChrome` token), no
`--disable-blink-features=AutomationControlled`, no `navigator.webdriver`
erasure, no locale/timezone/viewport — while `src/browser.ts` had the full manual
disguise built and wired **only** to `web_fetch`. Whoever implemented session.ts
read the DEC's isolation rule as *"the auth context must not be stealthy,"* so a
`session_login` (especially the headless `credKeys` path) against a bot-protected
login page (Cloudflare/Turnstile/etc.) gets flagged and the capture fails; a
naked `session_status` probe can land on a challenge page and false-report a good
session as `stale`.

Also fixed the wording drift the trace started from: session.ts's header said
"stealth `web_search`/`web_fetch` context" — `web_search` was removed in
DEC-2026-06-08-native-websearch-webfetch-doublecheck; now reads "stealth
`web_fetch` context."

## Decision Drivers

- The original isolation rule conflates two separable things: **identity/cookie
  isolation** (what the DEC actually protects) and the **disguise technique**
  (anti-detection hardening any context is entitled to).
- The disguise primitives already existed in `src/browser.ts`; the auth flow —
  the one flow most likely to sit behind bot detection — was the only one denied
  them.
- Sharing UA/args/init-script is not sharing a session; a separate
  `BrowserContext` + separate profile + separate cookie jar is what keeps
  identities from merging.

## Options Considered

### Option A: Leave session.ts naked (strict literal reading of "never merge")

- Bad: authenticated login/probe against any bot-protected site fails or
  misreports; the package's own stealth capability is withheld from the flow that
  needs it most. This is the reported breakage. Rejected.

### Option B: Point session.ts at the shared web_fetch persistent context

- Bad: that genuinely merges identities — authed cookies would ride along with
  scraping, and the scraping profile's fingerprint/consent cookies would bleed
  into an authed capture. Violates the real intent of the isolation rule.
  Rejected.

### Option C: Extract the disguise *primitives*; share the technique, isolate the identity

- Good: new `src/stealth.ts` owns UA, launch args, `STEALTH_INIT`, and
  `stealthContextOptions`; both `browser.ts` (persistent scraping profile) and
  `session.ts` (ephemeral auth contexts) import them. Contexts, profiles, and
  cookie jars stay fully separate. Honors what "never merge" actually means and
  fixes the breakage. Chosen.

## Decision

Chosen option: **Option C.** Reinterpret (not overturn)
DEC-2026-06-07's isolation rule: **isolation is about IDENTITY (context /
profile / cookie jar), not about the disguise technique.** Every context that
must pass as a real person is entitled to the anti-detection hardening.

- **New `src/stealth.ts`** exports the shared primitives: `CHROME_MAJOR`,
  `STEALTH_UA`, `LOCALE`/`TIMEZONE`/`VIEWPORT`, `STEALTH_ARGS`, `STEALTH_INIT`,
  and `stealthContextOptions` (spreadable `BrowserContextOptions`).
- **`src/browser.ts`** imports them instead of defining its own copies (behaviour
  byte-identical: still `channel: 'chrome'`, persistent profile, seeded consent).
- **`src/tools/session.ts`** applies the disguise to both the `session_login`
  capture context and the `session_status` probe context — `args: STEALTH_ARGS`,
  `...stealthContextOptions`, `addInitScript(STEALTH_INIT)` — while keeping the
  **ephemeral** `chromium.launch()` + `newContext()` model (its own cookie jar,
  never the web_fetch profile). Auth stays headed-capable for 2FA/SSO.
- **Difference retained:** session.ts does NOT use `channel: 'chrome'` (avoids a
  hard dependency on system Chrome for auth); it runs bundled Chromium with the
  Chrome UA + init disguise. Acceptable — the escalation-only WebGL/canvas
  spoofing remains absent everywhere.
- **Wording drift fixed:** session.ts header "web_search/web_fetch" →
  "web_fetch".

## Consequences

- `session_login` / `session_status` now survive common bot detection on login
  pages; fewer false `stale` verdicts.
- One source of truth for the disguise (`src/stealth.ts`) — the `CHROME_MAJOR`
  bump note now lives there; browser.ts and session.ts can't drift apart.
- No new dependency, no new tool, no schema change. Build clean; deterministic
  gate **46/46 green** (incl. the session_login/status tests).
- The `CHROME_MAJOR` maintenance rule (bump in lockstep with the pinned
  playwright upgrade) moves to `src/stealth.ts`.

## Confirmation Criteria

- Right when: a `session_login` against a Cloudflare-protected login captures a
  usable storageState, and `session_status` reports `fresh` for a good session on
  a bot-protected app instead of a challenge-page `stale`.
- Reconsider if: a target fingerprints deeper than UA/webdriver/automation-flag
  (canvas/WebGL/TLS-JA3) — then the auth flow needs escalation-only spoofing or a
  headed capture, tracked separately; do NOT merge the web_fetch profile to get
  there.
