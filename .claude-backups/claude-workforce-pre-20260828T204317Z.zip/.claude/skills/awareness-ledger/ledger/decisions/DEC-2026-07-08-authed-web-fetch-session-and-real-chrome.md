# DEC-2026-07-08-authed-web-fetch-session-and-real-chrome

**Status:** accepted
**Tags:** session-management, authentication, stealth-scraping, src/tools/web-fetch.ts, src/tools/session.ts, src/stealth.ts, src/secrets.ts, src/extract.ts, web_fetch, session_login, bot-detection, datadome, paywall
**Related:** DEC-2026-07-08-session-auth-context-stealth-disguise, DEC-2026-06-07-authenticated-session-storagestate-artifact, DEC-2026-07-21-session-login-challenge-capture-mode, DEC-2026-07-28-mcp-spec-2026-07-28-adoption-scope

## Context

DEC-2026-07-08-session-auth-context-stealth-disguise gave the auth *capture* and
*probe* contexts the shared disguise, so bot-protected **logins** stopped failing.
It left two gaps for actually **reading** paywalled content through the MCP,
surfaced while migrating the `/invest` News Gather (Financial Times + New York
Times) off a standalone raw-Playwright reader (`odyssey-alive/scripts/read-paywalled.js`)
onto playwright-mcp per user directive ("FT and NYT access absolutely must use
the playwright-mcp"):

1. **`web_fetch` had no authenticated read path.** It only rendered in the shared
   anonymous scraping profile (`getStealthContext()`), which carries no session —
   so a captured `session_login` storageState could not be used to read.
2. **The prior DEC's "session.ts does NOT use `channel:'chrome'`" broke on
   DataDome.** FT (Cloudflare-class) captured and read fine on bundled Chromium.
   NYT runs **DataDome**: the bundled-Chromium fingerprint drew a
   `geo.captcha-delivery.com` challenge on the *read*, and the capture-vs-read
   fingerprint mismatch invalidated the `datadome` clearance cookie. This is
   exactly the prior DEC's *"Reconsider if: a target fingerprints deeper than
   UA/webdriver/automation-flag ... tracked separately"* clause.

## Decision Drivers

- FT/NYT reads must run **through playwright-mcp**, not a parallel raw-Playwright
  reader (single browser stack; shared disguise; user directive).
- An authenticated read must **preserve identity isolation** — loading a session's
  storageState must never contaminate the shared anonymous scraping profile.
- DataDome ties clearance to the browser fingerprint, so **capture and read must
  present the same real-Chrome fingerprint**.

## Options Considered

### Option A: Drive authed reads through the wrapped `browser_*` tools + storageState
- Bad: no clean readable-text/citation extraction (that lives in `web_fetch`);
  per-article manual driving; awkward for a batch News Gather. Rejected.

### Option B: Load the session into the shared persistent `web_fetch` profile
- Bad: genuinely merges identities — authed cookies ride along with anonymous
  scraping and the scraping fingerprint bleeds into authed reads. Violates the
  isolation rule (same reason Option B was rejected in the prior DEC). Rejected.

### Option C: Opt-in `session` param on `web_fetch` → ephemeral seeded context; real Chrome everywhere
- Good: `web_fetch({ session })` spins an **ephemeral** context (own cookie jar)
  seeded with the named storageState + the shared disguise; identity stays
  isolated. Promote all auth/read launches to real Chrome so capture and read
  share one fingerprint DataDome accepts. Chosen.

## Decision

Chosen option: **Option C.** Extend — do not overturn — the isolation model: an
authenticated read gets its OWN ephemeral context, so auth and the shared
scraping profile still never merge; only the disguise (and now the Chrome
channel) is shared.

- **`web_fetch` gains an opt-in `session` param** (`src/tools/web-fetch.ts`). When
  set, it renders in an ephemeral `chromium` context seeded with that session's
  storageState + `stealthContextOptions` + `STEALTH_INIT`, then closes it.
  Anonymous fetches are byte-identical to before. **Local-only:** the `session`
  path is refused under remote egress mode (a captured session is never loaded on
  the prompt-injectable remote surface).
- **New `STEALTH_LAUNCH` in `src/stealth.ts`** = `{ channel: 'chrome', args:
  STEALTH_ARGS }`. `session_login`, `session_status`, and the `web_fetch` authed
  read all launch **real installed Chrome**. This **AMENDS** the prior DEC's
  "session.ts does NOT use `channel:'chrome'`" — DataDome (and PerimeterX-class
  walls) fingerprint bundled Chromium and re-challenge a session captured under a
  different engine. Chrome 149 stable is an installed host requirement already
  relied on by `browser.ts`. Identity isolation is untouched (still ephemeral
  contexts, separate cookie jars).
- **`src/secrets.ts` exports `sessionFilePath(name)`** as the single owner of the
  session-name→path mapping; `session.ts` was inlined onto it (removing its
  private duplicate of the safe-name rule).
- **`classifyHealth` (`src/extract.ts`) no longer mislabels a full authed read as
  `paywall`.** Subscription DOMs (NYT, News Corp) embed regwall/paywall markup
  regardless of entitlement, so `PAYWALL_TELL` fired even on a complete read. Now
  a substantial body (≥1500 chars) with paywall markup classifies `ok`; only a
  missing/truncated body with the markup is `paywall`.
- **`/invest` SKILL.md rewired** (consuming project): News Gather premium reads
  now use `session_status`/`session_login` + `web_fetch(session:"ft"|"nyt")`;
  `read-paywalled.js` is retired from that path. `read-paywalled.js` still serves
  Foreign Policy / Trends Journal for `/research` and `/steganographer` (out of
  scope here).

## Consequences

- **FT + NYT read end-to-end through the MCP, verified live:** FT full article +
  citation; the NYT IMF article — which returned a `geo.captcha-delivery.com`
  DataDome captcha on bundled Chromium — returned full text + citation on real
  Chrome with a logged-in (`NYT-S`) session.
- The real-Chrome dependency now extends to the **auth** flow (was `web_fetch`
  only). A host without Google Chrome can no longer capture/read authed content —
  acceptable; Chrome is already a documented requirement.
- storageState isolation intact: authed reads never touch the shared scraping
  profile; the `session` param is refused on the remote instance.
- One new tool **parameter** (`web_fetch.session`), no new tool, no session-tool
  schema change. Typecheck + build clean.

## Confirmation Criteria

- **Right when:** `web_fetch(session:"ft")` and `web_fetch(session:"nyt")` return
  full paywalled article text + a high-confidence citation, and NYT no longer
  lands on `geo.captcha-delivery.com`.
- **Reconsider if:** DataDome escalates past real-Chrome-headless (needs a headed
  read, a persistent per-session profile, or TLS/JA3-level work) — do that
  without merging the shared scraping profile. Also revisit the 1500-char
  `substantial` threshold if a genuinely truncated read slips through as `ok`.
