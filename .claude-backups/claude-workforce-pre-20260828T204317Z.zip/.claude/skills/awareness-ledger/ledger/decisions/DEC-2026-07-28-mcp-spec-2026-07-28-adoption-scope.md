# DEC-2026-07-28-mcp-spec-2026-07-28-adoption-scope

**Status:** accepted
**Tags:** mcp-spec, protocol-version, oauth, rfc-9207, security, remote-transport, session-management, sdk-v2, upstream-pinning, src/auth.ts, src/upstream.ts, src/index.ts, extend
**Related:** DEC-2026-06-26-remote-streamable-http-transport-claude-ai, DEC-2026-06-07-mcp-instructions-discoverability, DEC-2026-06-07-authenticated-session-storagestate-artifact, DEC-2026-07-08-authed-web-fetch-session-and-real-chrome, DEC-2026-07-21-session-login-challenge-capture-mode, DEC-2026-06-07-playwright-sourcing-and-install

## Context

MCP spec release **2026-07-28** (the fifth) landed today. Announced on the Claude
side at `claude.com/blog/bringing-mcp-2026-07-28-to-claude` and upstream at
`blog.modelcontextprotocol.io/posts/2026-07-28`. Headline changes: a **stateless
protocol core** (no `initialize`/`initialized` handshake, no `Mcp-Session-Id`),
a **versioned extensions framework** (Tasks, MCP Apps, Enterprise Managed
Authorization), **MRTR** replacing server-initiated elicitation/sampling/roots,
**cacheable list responses**, **authorization hardening**, and formal
deprecations (Roots, Sampling, Logging, legacy HTTP+SSE).

The user asked which core concepts would benefit this project if implemented
here, **without causing regression in existing capabilities** — `web_fetch`,
`browser_*`, `session_*`, `suite_*`, the remote Streamable-HTTP connector +
`REMOTE_DENYLIST`, and the generated `instructions` capability map.

**BLOCKING FINDING (verified, not inferred).** `@playwright/mcp` does not depend
on the MCP SDK — it **bundles** it inside `playwright-core`:

```js
// node_modules/@playwright/mcp/index.js
const { tools } = require('playwright-core/lib/coreBundle');
module.exports = { createConnection: tools.createConnection };
```

and `index.d.ts` types `createConnection()` as returning a **v1** `Server` from
`@modelcontextprotocol/sdk/server/index.js`. Meanwhile SDK v2 shipped as a
**split** — `@modelcontextprotocol/server@2.0.0` + `@modelcontextprotocol/client@2.0.0`
— while the v1 line this repo uses (`@modelcontextprotocol/sdk`, latest `1.30.0`)
still reports `LATEST_PROTOCOL_VERSION = '2025-11-25'` (confirmed by unpacking
1.30.0 and reading `dist/esm/types.js`).

Therefore **the inward half of the proxy composition is welded to SDK v1** until
Microsoft rebuilds `@playwright/mcp` on v2. Any protocol-level 2026-07-28
adoption today means running two SDKs simultaneously and hand-writing a v1↔v2
bridge inside `createOutwardServer` (`src/index.ts:142`).

## Decision Drivers

- **No regression** is the explicit constraint — this is a working, gated server
  (`npm run gate`), not a greenfield build.
- The SDK v1 ceiling above makes most protocol-level items non-viable today
  regardless of merit.
- This deployment is **one instance, one chromium, one user**. Horizontal scale,
  serverless, and edge — the stateless core's entire payoff — are worth nothing
  here, and serverless is *actively impossible* for a server whose value is a
  persistent browser process.
- Forward-compat **breakage** risk outranks feature value: an item where doing
  nothing degrades something that works today is more urgent than any addition.
- The `instructions` capability map is load-bearing. Per CLAUDE.md § Gotchas it
  is the **only always-visible discovery surface** once tool schemas are
  deferred (DEC-2026-06-07-mcp-instructions-discoverability).

## Options Considered

### Option A: Migrate to the stateless core / SDK v2 now

- Good, because it is where the protocol is going, and the remote transport
  would shed its session map.
- Bad, because the upstream half cannot follow — it needs a v1↔v2 bridge.
- Bad, because it buys scale properties this deployment will never use.
- Bad, because under v2 capabilities move to an optional `server/discover` RPC;
  if `instructions` delivery changes shape, the three-layer discovery strategy
  silently collapses to two and **no existing test would catch it**.

### Option B: Adopt nothing; revisit when upstream moves

- Good, because zero risk.
- Bad, because it ignores an authorization change that can **break the live
  connector** with no code change on our side (see RFC 9207 below).

### Option C: Adopt only the protocol-independent items; reject or defer the rest

- Good, because both adopted items are additive and need no SDK migration.
- Good, because it closes the one real forward-compat break.
- Bad, because it leaves Tasks-shaped ergonomics on the table for now.

## Decision

Chosen option: **Option C**, because exactly two of the release's concepts
deliver value here without touching the protocol, and one of them is a live
break risk rather than an enhancement.

### ADOPT (2 items, both protocol-independent)

**1. RFC 9207 issuer identification (SEP-2468).** This server is its own
authorization server (proxy-mode `mcpAuthRouter`, `src/auth.ts:306`) precisely
because GitHub has no DCR. The spec now has clients **validate `iss` on the
authorization response before redeeming a code**. SDK 1.30.0's authorize handler
does **not** emit `iss` (verified against `handlers/authorize.js`). If claude.ai
enables validation, the connector breaks — forward-compat maintenance, not a
feature. Add `iss` (value `issuerUrl.href`, matching the metadata `issuer`
**exactly** — note the trailing slash `URL.href` produces) to both
authorization-response redirects in `gitHubCallback`: the success redirect and
the `access_denied` error redirect. Advertise
`authorization_response_iss_parameter_supported: true` in AS metadata by mounting
an augmented `mcpAuthMetadataRouter` **ahead of** `mcpAuthRouter` (first mount
wins in express; `OAuthMetadataSchema` is `z.looseObject`, so the extra field
passes validation).

> **KNOWN GAP, accepted:** SDK-internal *post-redirect* errors inside
> `authorizationHandler` (its "Phase 2" validation failures) still won't carry
> `iss` — not patchable without forking the SDK. Our provider-owned responses
> are compliant; the SDK's early-error redirects are not.

**2. Explicit handles over hidden transport state.** The spec authors' own
guidance, quoted verbatim from the release post:

> "Dropping the protocol-level session doesn't force your application to be
> stateless. If your server needs to carry state across calls, mint an explicit
> handle from a tool and have the model pass it back as an argument. We found
> this works better than session state hidden in the transport — the model can
> see the handle and thread it between tools."

`session_login` → named storageState artifact → `web_fetch({url, session})`
**already is** that pattern — independent validation of a design shipped in
DEC-2026-06-07-authenticated-session-storagestate-artifact. **The exception:**
`session_login` / `session_solve_challenge` / `session_attach` also rebind the
shared upstream browser (`bindSession`, `src/upstream.ts:100`), so every
subsequent `browser_*` call is **silently authenticated** — exactly the hidden
cross-call state the spec is moving away from, and invisible to the model making
the call. Keep the convenience (it was deliberate and it works), but make the
binding **visible** by surfacing `boundSession()` in `browser_*` results.
Additive; no change to call semantics.

### REJECT for now (revisit trigger: `@playwright/mcp` ships on SDK v2)

- **Stateless core / no-handshake** — SDK v1 ceiling; zero benefit at this
  scale; serverless impossible with a persistent browser; puts the
  `instructions` map at risk.
- **`Mcp-Method` / `Mcp-Name` routing headers** — v2-gated. Genuinely attractive
  as defense in depth: nginx could reject `browser_*` at the edge instead of
  relying solely on `REMOTE_DENYLIST`. Same revisit trigger.
- **Cacheable list responses (`ttlMs` / `cacheScope`)** — v2-gated and pointless
  here; `tools/list` re-queries upstream **deliberately**, because binding a
  session rebuilds the upstream browser underneath it.
- **MCP Apps (inline UI)** — v2 extension, and it would apply only to the remote
  surface, which is the prompt-injectable, denylisted one. A UI rendering path
  there widens attack surface against the deliberate narrow-it-down posture of
  DEC-2026-06-26.
- **Enterprise-managed auth (EMA)** — single-user deployment locked to one
  `GITHUB_ALLOWED_LOGIN`. Not applicable.
- **Connector observability dashboard** — Claude-side feature for
  directory-published connectors; this one is private. Nothing to implement.

### DEFERRED / investigate

- **Tasks extension** — v2-gated, but its two canonical use cases already exist
  here: long-running work (`suite_audit` runs a whole Playwright suite) and
  human-in-the-loop (`session_login` headed and `session_solve_challenge` both
  block on a human). The *shape* — durable handle + poll — is implementable as
  plain tools today with no protocol dependency. Parked pending a call on
  whether blocking actually hurts in practice.
- **MCP tunnels (research preview)** — would let claude.ai reach a
  private-network instance with no public endpoint, obsoleting most of the
  remote hardening burden's reason to exist (nginx + TLS + OAuth +
  `src/egress.ts` SSRF backstop + egress firewall, `docs/REMOTE-CONNECTOR.md` §6).
  **Must be additive only** — replacing the hardened public path would be the
  highest-regression-risk move available.

### FREE / no-op confirmed

The 2026-07-28 deprecations (Roots, Sampling, Logging, legacy HTTP+SSE transport)
affect nothing here: `src/remote.ts` uses `StreamableHTTPServerTransport` and none
of the deprecated primitives are used anywhere in `src/`.

> **"do #1 and #2"**

*— Captured 2026-07-28, source: user, selecting from the reviewed concept list*

## Consequences

- The live connector stops being at risk from claude.ai turning on `iss`
  validation — the only item here where inaction was the regression.
- `browser_*` results gain a binding banner when a session is bound. This is a
  **content change to existing tool results**; assertions that use `includes()`
  stay green, but any future exact-match assertion on `browser_*` output would
  not.
- Partial RFC 9207 compliance is now a known, documented state rather than an
  unknown one (SDK-internal early-error redirects remain non-compliant).
- The repo stays on protocol `2025-11-25` by choice, with a written trigger for
  reconsidering — not by drift.
- Separately noted, unrelated to the spec: upstream `@playwright/mcp` is now
  **0.0.78** on `playwright@1.62.0-alpha-1783623505000`, vs this repo's pinned
  0.0.75 / 1.61.0-alpha-1778188671000. The lockstep-pinning rule of
  DEC-2026-06-07-playwright-sourcing-and-install still holds; that is a routine
  bump, tracked but not taken here.

## Confirmation Criteria

- **Right if:** the claude.ai connector keeps working through the client's
  adoption of RFC 9207 validation, and the visible binding banner prevents at
  least one "which identity am I acting as?" confusion during authed debugging.
- **Reconsider the rejections when:** `@playwright/mcp` publishes a release built
  on `@modelcontextprotocol/server@2.x`. At that point the v1 ceiling lifts and
  the stateless core, routing headers, Tasks, and cacheable lists all become
  reachable without a dual-SDK bridge — re-run this evaluation.
- **Reconsider Tasks sooner if:** `suite_audit` or headed `session_login` starts
  hitting client-side call timeouts in practice.
- **Watch:** whether the `instructions` capability map survives as a first-class
  concept in SDK v2's `server/discover` model. If it does not, the discovery
  strategy of DEC-2026-06-07-mcp-instructions-discoverability needs rework
  *before* any v2 migration, not during it.

## Process Note

`/build-mcp extend` declares agent input **mandatory** for non-obvious
architectural placement. Session policy in this environment forbids spawning
agents unless the user asks; the placement analysis was therefore done directly
against the source (`src/index.ts`, `src/auth.ts`, `src/upstream.ts`,
`src/remote.ts`, and the installed `@playwright/mcp` / SDK trees). The user was
told the gate was suppressed and did not request the second opinion.
