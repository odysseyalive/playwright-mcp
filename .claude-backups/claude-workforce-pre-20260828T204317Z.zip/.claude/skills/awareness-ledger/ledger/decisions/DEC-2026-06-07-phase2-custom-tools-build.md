# DEC-2026-06-07-phase2-custom-tools-build

**Status:** accepted
**Tags:** phase2, web_fetch, web_search, deep_research, session, src/tools, src/extract.ts, src/score.ts, src/budget.ts, testing, pdf, secrets, in-process-layering
**Related:** [DEC-2026-06-07-web-stack-layering-and-research-agents, DEC-2026-06-07-web-search-three-engine-stealth, DEC-2026-06-07-authenticated-session-storagestate-artifact, DEC-2026-06-07-build-mcp-lifecycle-orchestrator, DEC-2026-06-07-mcp-instructions-discoverability]

## Context

Phase 2 builds the five custom tools on top of the wrapped `@playwright/mcp`
toolset: `web_fetch` (bottom), `web_search` (middle), `deep_research` (top),
plus the `session_login`/`session_status` helpers. The method specs fix the
architecture (module ownership, return shapes); this DEC records the
implementation-level calls made while turning those specs into compiled,
tested code.

## Decision Drivers

- The shared fetch/search **Budget** must be honest across layers (a
  `deep_research` run shares one budget with every `web_search`/`web_fetch` it
  drives).
- The **test gate must be 100% deterministic** (build-mcp T-tiers) — a live
  engine can never turn a build red.
- No dependency that collides with the exact-pinned `playwright`, and no native
  build step.
- No duplicated logic (code-evaluator reflex).

## Options Considered

### Layering: in-process calls vs MCP round-trips

- **In-process** — `deep_research` imports `runSearch()`/`fetchUrl()` and calls
  them directly; `web_search` imports `fetchUrl()`. Good: one shared `Budget`
  object threads through, citations flow up for free, no serialization. Bad:
  tighter coupling between tool modules (acceptable — they are one package).
- **MCP round-trip** — upper tools call lower tools as MCP clients. Bad: budget
  can't be shared without a side channel; hidden fetches blow caps; pointless
  serialization in one process.

### Determinism: pure functions + injected deps vs live integration tests

- **Pure + injected** — engine SERP parsers and `extract.ts` are pure over an
  HTML string; `deep_research` takes injected `DeepDeps` (search/fetch stubs).
  Good: every T1 tier runs with zero browser/network. Bad: live behavior is
  covered only by the (non-gating) T2 tier.
- **Live integration** — drive the real browser in tests. Bad: flaky, network-
  dependent, violates the deterministic-gate rule.

### PDF text: pdfjs-dist vs pdf-parse vs pdf2json

- **pdfjs-dist** — Mozilla, pure-JS, no native build, same lineage as
  readability/jsdom. Bad: heavier, legacy build import path.
- **pdf-parse** — simplest API but has an import-time test-file quirk.
- **pdf2json** — lower-level, more wiring.

## Decision

Chosen: **in-process layering**, **pure-functions + injected-deps testing**,
**pdfjs-dist** for PDF text, a shared **`src/secrets.ts`** (dotenv parser +
config/sessions paths, de-duplicated out of `index.ts`), and **budget spend in
the leaf calls** (`fetchUrl` spends a fetch, `runSearch` spends a search) with
`deep_research`'s `fetchInto` pre-checking `canFetch()` before descending.

> **"DEFAULT TO pure parse/extract functions and inject the lower layers, so the
> whole T1 gate runs with no browser and no network; keep the budget honest by
> calling the lower tools in-process, not over MCP."**

*— Captured 2026-06-07, source: Phase 2 build session*

## Consequences

- 28 tools live (23 wrapped `browser_*` + `web_fetch`, `web_search`,
  `deep_research`, `session_login`, `session_status`).
- 34 deterministic T1 tests green across the four tool layers; T0 boot gate green
  (28 tools listed, instructions capability map carries the REPLACES-NATIVE
  steering line once `web_search`/`web_fetch` exist).
- `closeBrowser` wired to SIGTERM/SIGINT; dead `newStealthPage` removed (both
  web tools use `getStealthContext().newPage()`).
- The stealth `web_*` context (`src/browser.ts`) stays isolated from the
  `session.ts` auth context (separate `chromium.launch()`), per the session spec.
- Coupling between tool modules is intentional and one-directional (up the
  stack); the layering contract is enforced by who-imports-whom.

## Confirmation Criteria

- A `deep_research` run never exceeds ≤15 fetch / ≤8 search (asserted in T1).
- No citation is ever emitted without a fetched source in the evidence set
  (credibility invariant, asserted in T1).
- If T2 fixture-capture shows selector drift, only the affected `engines/*.ts`
  parser changes — the parity harness is the regression check. Reconsider the
  in-process coupling only if the tools ever need to run in separate processes.
