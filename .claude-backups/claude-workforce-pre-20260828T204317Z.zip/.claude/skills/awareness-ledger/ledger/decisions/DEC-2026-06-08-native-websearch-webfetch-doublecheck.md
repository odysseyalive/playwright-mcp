# DEC-2026-06-08-native-websearch-webfetch-doublecheck

**Status:** accepted
**Tags:** web-search, web-stack, web_fetch, deep_research, override, permissions, stealth-scraping, src/tools/web-search.ts, src/engines, src/tools/deep-research.ts, research-paper, Phase-2
**Related:** DEC-2026-06-07-web-search-three-engine-stealth, DEC-2026-06-07-web-stack-layering-and-research-agents, DEC-2026-06-07-global-override-websearch-webfetch-chrome, DEC-2026-06-07-phase2-custom-tools-build, DEC-2026-07-21-session-login-challenge-capture-mode

## Context

The scraping `web_search` MCP tool (three-engine stealth: Google + Bing +
DuckDuckGo) was fully blocked at runtime from the user's residential
Charter/Spectrum IP (Tillamook, OR). Live diagnosis on 2026-06-08 found all three
engines bot-gating simultaneously: Google `302 → /sorry` CAPTCHA, DuckDuckGo
`403` on both `html.` and `lite.` endpoints, Bing `200` "One last step — solve the
challenge" interstitial (which the code mislabeled `empty`).

Review of the SearXNG source (`~/lab/searxng`) confirmed the engines block by **IP
reputation with sliding-window cooldowns**, independent of request hygiene: even
SearXNG (correct POST recipes, vqd discipline, consent cookies, GSA UA) ships a
per-engine suspend/cooldown mechanism precisely because correct requests still hit
IP walls. Two layers were in play — per-request fingerprint (fixable: DDG GET→POST,
a hardcoded `America/New_York` timezone on a Pacific IP self-flagging every
request) and behavioral/IP-reputation (not fixable by headers; the residential IP
was burned by a retry burst, including our own diagnostics).

Key architectural fact: **Claude Code's native `WebSearch` runs server-side on
Anthropic infrastructure** — it never touches the user's IP, so it has none of the
scraping/CAPTCHA/cooldown problems. `web_fetch` (single-page stealth render / PDF /
CSL-JSON citations) does NOT share the SERP-scraping problem (fetching one ordinary
page ≠ hammering a search engine) and is the genuinely-superior capability.

## Decision Drivers

- Scraping consumer search engines from a residential IP is an unwinnable
  bot-detection + IP-reputation arms race; even perfect request shaping can't beat
  IP reputation (SearXNG-confirmed).
- Native `WebSearch` sidesteps the entire problem (server-side, no user-IP burn).
- `web_fetch` + `browser_*` + `session_*` are the real value and have no equivalent
  scraping fragility — worth keeping.
- An MCP server **cannot call the host's native `WebSearch`** — so any
  "native-search + our-double-check" wrapper must live session-side, not as a
  server tool.
- User wants the double-check (render/cite/verify) layered on top of native search,
  not removed.

## Options Considered

### Option A: Harden the scrapers (port SearXNG recipes natively + breaker/backoff + Mojeek)

- Good, because it keeps everything self-contained in Playwright (the user's stated
  preference) and recovers engines on a clean IP.
- Bad, because it does not beat IP reputation — Google especially still walls a
  residential IP at automated volume; it is perpetual maintenance against an
  adversarial, drifting target.

### Option B: Proxy to a self-hosted SearXNG instance (krull-searxng)

- Good, because SearXNG aggregates many engines and returns JSON.
- Bad, because it adds an infra dependency (container up + host-port exposed), and a
  SearXNG instance on the **same** burned residential IP gets blocked too.

### Option C: Remove `web_search`/`deep_research`; native `WebSearch` for discovery + `web_fetch` double-check, orchestrated by a steered session-side skill (LEAN CUT)

- Good, because discovery moves to server-side native search (no IP burn, no arms
  race); keeps `web_fetch`/`browser_*`/`session_*`; reuses our double-check methods
  (confirm-fetch + `extract.ts` citations) fed by native results; no API keys, no
  proxy/infra.
- Good, because it deletes the most fragile code (engines, cross-engine consensus).
- Bad, because it reverses Project Goal #3 and the three-layer stack; the
  search-with-verification UX becomes a skill + steering, not a single MCP tool
  (an MCP server can't reach native `WebSearch`).

## Decision

Chosen option: **Option C (lean cut, steered)**, because it ends the arms race at
its root rather than fighting it, keeps the genuinely-superior parts of the project,
and still delivers the user's "search + our double-check" goal — just at the
session/orchestration layer, the only place both native `WebSearch` and our
`web_fetch` are reachable.

> **"somehow overtake the stock web search option, use claude's native web search
> option, then layer our double checks using web fetch using our current methods …
> yes, proceed — steered version, lean cut"**

*— Captured 2026-06-08, source: user (fmeetze) conversation*

## Consequences

- **Removed:** `src/tools/web-search.ts`, `src/engines/*`, `src/tools/deep-research.ts`,
  cross-engine consensus machinery in `score.ts`; `web_search`/`deep_research` drop
  out of `tools.ts`, the `instructions` capability map (`src/index.ts`
  `buildInstructions`), and the smoke/T0 assertions.
- **Kept:** `web_fetch`, all `browser_*` debug tools, `session_login`/`session_status`,
  `extract.ts` (citations/CMS), `browser.ts` (web_fetch shares the stealth context).
- **Settings flip:** drop `"WebSearch"` from `~/.claude/settings.json` `permissions.deny`;
  KEEP `"WebFetch"` and `"mcp__claude-in-chrome"` denied. Amends
  DEC-2026-06-07-global-override-websearch-webfetch-chrome (WebSearch no longer
  overridden; the other two levers stand).
- **Session-side:** new steered `web-search` skill (native `WebSearch` → `web_fetch`
  top-N → ranked + cited + dead/blocked flagged); `research-paper` re-homed to drive
  native `WebSearch` + `web_fetch` instead of the removed `deep_research` tool.
- **Supersedes** DEC-2026-06-07-web-search-three-engine-stealth (scraping web_search)
  and collapses the three-layer stack in
  DEC-2026-06-07-web-stack-layering-and-research-agents (web_fetch survives
  standalone; research re-homed).
- **Steering docs:** project CLAUDE.md charter inverted (Goal #3), global
  `~/.claude/CLAUDE.md` line changed to "search with native WebSearch, then
  verify/cite with web_fetch"; method-spec skills `/web-search-method` +
  `/deep-research-method` become stale (strip/repurpose) and `/route` index
  regenerated.

## Confirmation Criteria

Right if: web search "just works" again without burning the user's IP (native
results), and `web_fetch` continues to add render/citation/page-health value on top;
no recurrence of the three-engine simultaneous block. Reconsider if native
`WebSearch` becomes unavailable in the user's environment (then discovery has no
server-side path and the scraping question reopens), or if the steered skill proves
too easy to bypass and a forced `PostToolUse` hook is needed.
