# DEC-2026-07-21-session-login-challenge-capture-mode

**Status:** accepted
**Tags:** session-management, authentication, bot-detection, cloudflare, captcha, src/tools/session.ts, src/stealth.ts, session_login, session_status, attach-mode, debugging
**Related:** DEC-2026-07-08-authed-web-fetch-session-and-real-chrome, DEC-2026-07-08-session-auth-context-stealth-disguise, DEC-2026-06-07-authenticated-session-storagestate-artifact, DEC-2026-06-08-native-websearch-webfetch-doublecheck, DEC-2026-07-28-mcp-spec-2026-07-28-adoption-scope

## Context

`session_login` already had `attach:true` — spawn a plain real Chrome as a child
process (never `chromium.launch`, so no automation instrumentation is present
while the human works), let the person clear a Cloudflare/Turnstile wall **and
log in**, then `connectOverCDP` and read the authenticated storageState back out.

The user asked for the same machinery aimed at a different target: *"a feature
like session_login but instead of for logins, it makes the person solve the
captcha, then continues on just like session_login does."*

The gap was one predicate. `pollAttachedLogin` completed only when a page target
satisfied `leftLoginPage()` — a host change or a path change. **A CAPTCHA solve
ends on the same URL it started on**, so `session_login({attach:true})` against a
walled page with no login form sat until the 300s timeout even when the challenge
had visibly cleared. The `!/just a moment/i` title test was AND-ed onto the
navigation requirement rather than being an alternative to it, so it could never
carry a same-URL completion on its own.

## Decision Drivers

- `sessionAttach` already owns every hard part: plain-Chrome child spawn, DevTools
  port discovery, passive CDP harvest, domain-scoped export, orphan-reaping PID
  registry, mode-600 write. Whatever shape the feature took, it had to reuse that.
- The server already exposes **30 tools**, and CLAUDE.md § Gotchas warns that
  Claude Code registers only tool *names* and defers schemas at that count — so a
  new tool has a real, non-obvious discoverability cost.
- `session_login` is already in `REMOTE_DENYLIST` (`src/index.ts:100`). Remote
  posture should be inherited, not re-derived.
- The project's anti-duplication rule: a second copy of capture logic drifts from
  the first the moment upstream changes.

## Options Considered

### Option A: A new MCP tool (`session_solve` / `session_capture`)

- Good, because the name states the purpose and the schema can drop every
  login-only field (`credKeys`, `selectors`, `successSignal`).
- Bad, because it either duplicates `sessionAttach` wholesale or forces an
  extraction refactor for a single differing predicate.
- Bad, because it is a 31st tool against a documented deferred-schema threshold.
- Bad, because it needs its own `REMOTE_DENYLIST` entry — a step someone will
  forget, and forgetting it exposes a human-in-the-loop browser spawn remotely.

### Option B: A `challenge:true` mode on `session_login`

- Good, because the delta really is one predicate; everything else is shared by
  construction rather than by discipline.
- Good, because it inherits the remote denylist, the secrets discipline, the
  orphan reaping, and the artifact contract for free.
- Bad, because `loginUrl` is a poor name for "the walled page", and the tool
  description has to carry a second mode's worth of explanation.

### Option C: Extract a shared human-in-the-loop capture primitive

- Good, because it is the cleanest separation on paper.
- Bad, because it is speculative generality at two callers — the abstraction cost
  is paid immediately and the second consumer is the only one that will ever exist.

## Decision

**AMENDED same session (user-directed) — the final decision is Option D, below.**

Originally chosen: Option B, a `challenge:true` mode on `session_login`, on the
grounds that a separate tool would duplicate capture logic. The user corrected the
premise:

> **"let's devise a way to make this work without a drift risk. that's sort of
> why I asked you to create a separate entry for captcha's in the first place"**

*— Captured 2026-07-21, source: conversation*

That exposed a flaw in the original reasoning. The drift risk was never in the
capture *machinery* — it was in the **definition of "is a wall still up,"** which
at that point existed twice (an inline `/just a moment/i` in the login caller and
`CHALLENGE_TITLE` in the challenge predicate). Splitting into two tools would not
have created that duplication, and keeping one tool did not prevent it. The two
concerns are orthogonal, and the original decision conflated them.

### Option D (chosen): separate tool, shared engine, single wall predicate

- `wallUp(currentUrl, title)` is extracted as **the single authority** on whether a
  bot wall is present. Both modes compose it and differ only where they genuinely
  differ: `login → navigated away AND NOT wallUp()`, `challenge → still on target
  AND NOT wallUp()`.
- `session_solve_challenge` is a **thin front door** over the same `sessionAttach`
  engine, with a schema that carries only what the job needs (`name`, `url`,
  `profile`, `timeoutMs`) instead of documenting `credKeys`/`selectors`/
  `successSignal` as ignored. The `challenge` flag is removed from
  `session_login`'s public schema and survives only as an internal `LoginOptions`
  field.
- Added to `REMOTE_DENYLIST` in the same change, with `scripts/test-remote.mjs`
  extended to assert it is denied on both `tools/list` and `tools/call`.
- Drift is now prevented **structurally, not by discipline**: a test reads
  `src/tools/session.ts` and asserts exactly two wall-matching regex literals
  exist (`WALL_TITLE`, `WALL_PATH`). Verified to fail correctly — reintroducing the
  old inline check produced "found 3" and a red gate.

Side effect worth noting: unifying on `wallUp()` **fixed a latent bug in login
mode**, which previously recognised only "Just a moment", so a post-login page
titled `Attention Required! | Cloudflare` read as a completed login.

*Cost accepted:* tool #31 on a deferred-schema server (mitigated by a generated
`instructions` line, per DEC-2026-06-07-mcp-instructions-discoverability).

Implementation:

- `challengeCleared(currentUrl, targetUrl, title)` — the same-URL counterpart to
  `leftLoginPage()`. Deliberately conservative: a blank title is the challenge
  shell mid-load, a foreign host is another tab the human opened, and a dedicated
  challenge path (`/cdn-cgi/challenge-platform`, `/sorry`, …) is still a wall.
  A false negative costs a longer wait; a false positive saves a worthless artifact.
- `pollAttachedLogin` generalized into `pollAttached(port, isDone, timeout, message)`
  with two thin callers. **Login behavior is preserved byte-for-byte** — same
  predicate, same 2s stability window, same 1s poll, same timeout message.
- Detection stays **passive**: HTTP reads of `/json/list` only (which exposes just
  `type`/`url`/`title`), never a CDP attach mid-solve, because driving the page is
  precisely what makes a managed challenge loop.
- `CLEARANCE_COOKIES` + `clearanceSummary()` report `expiresAt` and warn when no
  clearance cookie was captured at all — a capture that "succeeded" but is empty.
- `LoginResult` gains `mode:'challenge'`, `expiresAt`, `warning`; `challenge`
  implies `attach` in `loginHandler`.
- Two pure-function T1 tests, matching the existing `leftLoginPage` test pattern.
  Gate green at 53/53.

## Consequences

- The capture half of the feature is real and tested. **The replay half is
  unverified** — see Confirmation Criteria. This record deliberately ships with
  that gap open rather than implying end-to-end coverage.
- `session_status` remains login-shaped and cannot see a challenge session die
  (below).
- Two tools now share one capture engine and one wall predicate. That sharing is
  load-bearing: if a future change gives either tool its own notion of a wall, the
  drift guard fails the build. **Extend `WALL_TITLE`/`WALL_PATH`; never add a
  second check.**
- The lesson that generalises past this feature: *a separate front door and a
  shared implementation are independent choices.* Duplication is prevented by
  naming one authority, not by refusing to split the interface.

## Confirmation Criteria

**The open question that decides whether this feature is real:** does a harvested
clearance survive replay? Attach-mode capture uses the plain real Chrome's
**native full UA** (e.g. `Chrome/149.0.7632.100`) while `web_fetch({session})`
replays through `STEALTH_UA` = `Chrome/${CHROME_MAJOR}.0.0.0` — `src/stealth.ts:88-89`
comments this asymmetry itself. `cf_clearance` binds to IP **and the exact UA
string**, so the clearance may be void the moment it is replayed. This is the same
failure class as DEC-2026-07-08-authed-web-fetch-session-and-real-chrome, where a
capture/read fingerprint mismatch voided a DataDome clearance on NYT.

Live verification was **declined, not skipped**: the user proposed testing against
Google image search, which was refused as conflicting with the global "Do NOT
scrape search engines" directive and DEC-2026-06-08 (residential IP-reputation
burn), and no alternative target was chosen.

- **Confirms the decision:** a capture→`web_fetch({session})` round trip against a
  real Cloudflare-walled target returns content rather than a fresh challenge.
- **Triggers reconsideration:** if replay re-challenges, the artifact must record
  the capture browser's native UA for verbatim replay — a change to the
  storageState contract, which would likely justify revisiting Option A.
- **Separately open:** `session_status` has no TTL model (it infers staleness from
  login-URL redirects plus an optional `loginIndicator`), so an expired
  short-lived clearance still reports `fresh`. A challenge-shaped freshness check
  is needed before this mode can be relied on unattended.
- **UX gap:** challenge mode defaults to `profile:'temp'` — a brand-new profile
  with zero accumulated trust, the hardest case for a hard wall. `profile:'system'`
  is usually the better choice and should be documented as such.
