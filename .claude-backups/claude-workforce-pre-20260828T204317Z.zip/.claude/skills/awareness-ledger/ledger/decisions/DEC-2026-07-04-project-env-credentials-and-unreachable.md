# DEC-2026-07-04-project-env-credentials-and-unreachable

**Status:** accepted
**Tags:** session-management, authentication, secrets, src/secrets.ts, src/tools/session.ts, src/tools/scaffold.ts, scripts/scaffold-e2e.mjs, session_login, session_status, session_scaffold_tests, project-env, credential-precedence, unreachable, e2e-scaffold, extend
**Related:** DEC-2026-06-07-authenticated-session-storagestate-artifact, DEC-2026-06-08-e2e-test-scaffold-storagestate

## Context

A review of the e2e kit surfaced two sharp edges, and the user described a habit
the kit didn't accommodate: (a) `session_status` reported every navigation/
launch failure as `stale`, so an app being down read as an expired session and
prompted pointless re-logins; (b) `session_scaffold_tests`' `force:true`
silently rewrites the whole template set, including a customized
`example.spec.ts`, with no warning anywhere; (c) the user's projects keep test
credentials in a per-project `.env`, but credential lookup only read the
user-scoped `secrets.env` (plus `process.env` by accident of environment
inheritance) — the consuming project's own `.env` was invisible.

## Decision Drivers

- An environmental failure must never be reported as a session verdict —
  mis-classified staleness triggers unnecessary (sometimes headed/2FA) recapture.
- `force` warnings belong on the tool surface (description + CLI help), where
  the caller decides.
- The project that owns the app owns its test credentials — the kit should meet
  the user's existing per-project `.env` habit instead of forcing a copy into
  the user-scoped `secrets.env`.
- Secrets discipline must hold: requested-keys-only, capture-time only, replay
  side never sees credentials.

## Options Considered

### Option A: keep `stale` as the catch-all; user-scoped secrets only

- Good, because zero surface change.
- Bad, because unreachable-as-stale actively misleads (re-login on a down app),
  and per-project credentials require duplicating secrets into the user scope.

### Option B: `unreachable` state + project-`.env`-first precedence (chosen)

- Good, because status states map one-to-one to remedies (fresh → proceed,
  stale → recapture, missing → capture, unreachable → fix reachability).
- Good, because the project `.env` is the more specific scope and matches how
  the user's projects already manage credentials.
- Bad, because project-wins inverts the previous "user secrets.env is the
  source of truth" posture — an accepted, deliberate reversal.

## Decision

Chosen option: **Option B**, in three parts:

1. **`session_status` gains `unreachable`** — returned when the probe itself
   cannot complete (goto/DNS/network failure, or browser/context launch
   failure). Environmental verdict, never a session one. Carve-out: a corrupt
   (unparseable) storageState artifact reports `stale`, because recapture IS the
   remedy there.
2. **Credential lookup precedence** for `session_login` (`getSecret` in
   `src/secrets.ts`): consuming project's `./.env` (or explicit `envFile` param
   — an explicitly named missing file throws) → user-scoped `secrets.env` →
   `process.env`. The **project file wins** when both define a key.
   Requested-keys-only and read-only, so unrelated project secrets never enter
   tool output; the generated e2e suite still consumes only the storageState
   artifact (capture side changed, replay side untouched).
3. **Force warning** — `session_scaffold_tests`' `force` description and the
   `scaffold-e2e.mjs` CLI help now warn that `force:true` rewrites the WHOLE
   template set, including customized files.

> **"well the .env would be in the project that is utilizing this mcp"** —
> the clarification that reframed project-`.env` support from an adjacent
> pattern into the natural credential source for this kit.

*— Captured 2026-07-04, source: conversation (user)*

## Consequences

- `session_status` consumers can distinguish "fix the app/network" from
  "recapture the session"; the tool description tells callers not to re-login
  on `unreachable`.
- Per-project credentials work with zero copying; user-scoped `secrets.env`
  remains the fallback and the cross-project default.
- Precedence inversion: a project `.env` can now shadow a user-scoped secret of
  the same key name — deliberate, but worth remembering when debugging "wrong
  credentials" reports.
- Implementation: `src/secrets.ts` (parseDotenv + `getSecret` opts),
  `src/tools/session.ts`, `src/tools/scaffold.ts`, `scripts/scaffold-e2e.mjs`;
  docs in `README.md` + `.env.example`; T1 fixtures in
  `scripts/test-session.mjs` / `test-scaffold.mjs` (+6 tests, gate 41/41
  green). `/session-method` spec updated the same day.
- Process note: code + tests landed 2026-07-04 **before** this DEC at the
  user's shipped-files-only directive (`.claude/` was temporarily off-limits);
  ledger + spec caught up in the same session once the user lifted it.

## Confirmation Criteria

Right if: no more re-login loops against down dev servers, and per-project
`.env` credentials "just work" in consuming projects. Reconsider if the
project-wins precedence causes a real shadowing incident (would argue for a
warning when both scopes define a requested key), or if callers need
launch-vs-navigation failures split out of `unreachable`.
