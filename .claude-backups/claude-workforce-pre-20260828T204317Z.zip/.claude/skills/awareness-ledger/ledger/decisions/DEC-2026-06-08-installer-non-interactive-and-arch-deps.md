# DEC-2026-06-08-installer-non-interactive-and-arch-deps

**Status:** accepted
**Tags:** install, installer, install.sh, override, permissions, settings.json, playwright, chromium, arch-linux, non-interactive, apt-detection
**Related:** DEC-2026-06-07-global-override-websearch-webfetch-chrome, DEC-2026-06-07-playwright-sourcing-and-install

## Context

A live `./install.sh` run on the user's Arch Linux box produced alarming-but-harmless
output: `playwright install --with-deps chromium` shelled out to `apt-get` (which Arch
lacks), triggered a `[sudo] password` prompt, failed with `apt-get: command not found`,
printed `Failed to install browsers` + `Error: ... exited with code: 127`, and emitted
several `BEWARE: your OS is not officially supported by Playwright` lines. The script's
existing `|| retry-without-deps` fallback recovered and the install actually succeeded —
but the output read like a failure.

Separately, the assistant reached for `./install.sh --yes` to re-run, and the user
objected: they should not have to think about a `--yes` flag. Investigation showed
re-runs were *already* prompt-free once configured (the deny-merge is a no-op when rules
are present; steering is skipped when its marker exists) — the `--yes`/`confirm()` prompt
only ever fired on a first-ever apply of the global-config edits.

## Decision Drivers

- The installer must read as succeeding on non-apt distros (Arch, Fedora) — no scary
  sudo prompt / `apt-get` error / exit-127 noise.
- The user does not want to reason about a `--yes` flag; re-runs must "just work."
- Transparency about edits to the user's global `~/.claude` config must be preserved.
- `--with-deps` is only meaningful where Playwright supports it (apt / Debian-Ubuntu).

## Options Considered

### Option A: Keep prompting on first run; only fix the Chromium noise

- Good, because it preserves the documented "prompt before touching ~/.claude — never
  silently" stance verbatim.
- Bad, because the user explicitly did not want to think about `--yes`, and the prompt is
  the thing they were reacting to.

### Option B: Auto-apply the override steps, but always print the diff of what changed

- Good, because the installer never prompts (no `--yes` to remember) yet still shows
  exactly what it wrote to global config; `--no-deny`/`--no-steer` remain opt-outs.
- Bad, because it reverses the "prompt before touching ~/.claude/settings.json" stance
  (consent-first → transparent-after).

### Option C: Remove prompts and the diff entirely (silent apply)

- Good, because it is the simplest.
- Bad, because it modifies the user's global config with no visible record — rejected.

## Decision

Chosen option: **Option B** (auto-apply, show diff) for the override steps; and for the
Chromium step, **drop `--with-deps` entirely** — a single `npx playwright install chromium`
on every platform — rather than the initial apt-detection middle-ground.

> Note: the Chromium decision evolved within the same day. The first pass apt-detected
> before using `--with-deps`; follow-up research (below) showed `--with-deps` should be
> dropped altogether, making the installer never touch a system package manager. This DEC
> records the final decision; the apt-detection intermediate is superseded by it.

Concretely:
- **Override steps auto-apply non-interactively** (both installers). The deny-merge and
  steering-directive steps apply without asking, printing the diff of any change before
  writing. In `install.sh`, `confirm()`/`ASSUME_YES` were removed; in `install.ps1`, the
  `Confirm` function was removed and the `-Yes`/`--yes` flag is now an accepted back-compat
  no-op. `--no-deny`/`--no-steer` (`-NoDeny`/`-NoSteer`) still opt out. (`install.ps1` had
  never received the non-interactive treatment until this change — it was still prompting.)
- **Chromium = browser binary only, no system-dep step.** `npx playwright install chromium`
  downloads the binary from Microsoft's CDN into the per-OS cache (`~/.cache/ms-playwright`,
  `~/Library/Caches/ms-playwright`, `%LOCALAPPDATA%\ms-playwright`) — no OS package manager,
  no sudo/admin, identical on macOS / Linux / Windows. The apt-only `--with-deps` flag and
  the apt-detection/`pacman`-hint branch are gone.
- **`pw_install()` BEWARE filter retained.** Even a plain `install chromium` prints
  `BEWARE: your OS is not officially supported…` while downloading the Ubuntu fallback build
  on Arch; the wrapper still filters those lines (real exit via `PIPESTATUS`).

### Research backing the drop (2026-06-08, native WebSearch + web_fetch)

- Browser binaries are inherently out-of-band native blobs; **no general-purpose npm package
  ships a cross-platform Chromium.** The only npm-registry-bundled Chromium, `@sparticuz/chromium`,
  is **Linux-x64 + headless-shell + AWS-Lambda-only** ("will not work on macOS or Windows";
  "designed to be run on a vanilla Lambda instance") — adopting it would *break* cross-platform
  and headed support, the opposite of the goal. (npmjs.com/package/@sparticuz/chromium)
- Linux system shared libs (`libnss3`, `libgbm1`, …) are native ELF objects resolved by the
  dynamic linker against the host glibc; **they cannot ship through npm** in any portable way.
  Playwright's own docs frame `install-deps`/`--with-deps` as a convenience "useful for CI
  environments" (i.e. bare boxes), not a desktop requirement. (playwright.dev/docs/browsers)
- **Headless is unaffected by dropping `--with-deps`.** Those libs are a runtime requirement of
  the Chromium *binary* regardless of headless vs headed — `--with-deps` never "enabled headless."
  On any machine that has the libs (every desktop, macOS, Windows) headless works; on a bare box
  missing them, *neither* mode would work, and `--with-deps` could only have helped on apt anyway.

> **"yes, make that change and sync install.ps1, but if we do this, will it still work as a headless browser as we intend to use it?"** — Yes; verified by the headless smoke test after the change.

*— Captured 2026-06-08, source: user directive + in-session research (conversation)*

## Consequences

- `./install.sh` / `.\install.ps1` with no flags are fully non-interactive and idempotent —
  never prompt, on first run or re-run. Verified quiet on the Arch box.
- The "prompt before touching ~/.claude/settings.json — never silently" stance from
  DEC-2026-06-07-global-override-websearch-webfetch-chrome is **superseded for both installers**:
  they apply-then-show-diff rather than prompting first. Transparency (the diff) is retained;
  consent-first is dropped per user choice.
- The Linux `--with-deps` step from DEC-2026-06-07-playwright-sourcing-and-install is **removed
  outright** (not merely gated). All three platforms now run the identical browser-only install
  and the installer never invokes a system package manager.
- **Lone gap:** a bare/headless Linux box (minimal container, server, WSL with no desktop) may
  lack Chromium's system libs and fail to *launch* — documented as a README note pointing at
  `npx playwright install-deps` or the official Playwright Docker image, never an installer-run
  package manager. Not a concern for the target audience (desktop macOS/Linux, Windows).
- **Headless verified:** T0 boot-gate smoke test passes after the change — server boots headless
  Chromium and round-trips a `data:` URL — on the Arch box with no `--with-deps` ever run.

## Confirmation Criteria

Right if: a fresh `./install.sh` / `.\install.ps1` on any target OS runs clean (no sudo/admin
prompt, no `apt-get`/127 error, no `BEWARE` lines, no `y/N` prompt) and the **headless** server
boots and navigates (T0 smoke green). Reconsider if: bare-Linux users hit launch failures from
missing libs often enough to warrant an opt-in `install-deps` path, or if silent global-config
edits ever surprise a user (re-introduce a prompt or add a `--dry-run`).
