# DEC-2026-06-07-docs-voice-port

**Status:** accepted
**Tags:** docs-voice, voice, writing-kernel, documentation, README, creative-lane, port, claude-enforcer, literal-zone, skill-design
**Related:** DEC-2026-06-07-build-mcp-lifecycle-orchestrator

## Context

The user wants a README (Linux/macOS + Windows PowerShell; two install options — single-project and user-scope) written in their own voice, and asked to carry over the writing skills from /home/francis/lab/claude-enforcer (the "writing kernel", edit, my-voice) and convert them for documentation use in playwright-mcp. An Explore agent inventoried claude-enforcer; a Plan agent designed the port. Both fed a ratification.

## Decision Drivers

- The "writing kernel" is NOT one skill — it's a 9-step load order across claude-enforcer's `voice` (6 user-specific reference files), `writing` (kernel.md + directives.md, spawns 2 agents), and `edit` (gateway + content-type-constraints), with `text-eval` (3-agent chain) as deep validation. That split serves a multi-entry content pipeline (`/focus`, `/newsletter`, `/present`) that does NOT exist in playwright-mcp.
- playwright-mcp is small; the near-term need is one README. Four interlocking skills would be the largest, most entangled subsystem in the repo for that need, with four drift surfaces.
- The voice content is USER-SPECIFIC (Francis's profile/vocabulary/characteristics) — it must be copied verbatim, never paraphrased ("sounds like me").
- Voice rules (no em-dashes, no rhetorical colons, "invite don't explain") would CORRUPT install commands if applied to code/flags/paths — and claude-enforcer's enforcement HOOKS do not port (no hooks distributed here).
- These are creative-lane skills (preferred claude-opus-4-6); the session was on the analytical brain.

## Options Considered

### Option A: Mirror the 4-skill claude-enforcer layout (voice / writing / edit / text-eval)

- Good, because faithful to origin; reusable voice foundation.
- Bad, because it imports the multi-entry-pipeline machinery (chained-mode, 9-step cross-skill load) that playwright-mcp will never use; four drift surfaces for a one-README need.

### Option B: One consolidated `docs-voice` skill

- Good, because the kernel is inlined as `references/`, one update surface, fits a small repo; preserves the load *order* without the four-skill packaging.
- Bad, because if heavy non-doc creative work arrives later, the voice payload isn't a shared foundation (revisit then).

### Option C: Don't create a skill (hand-write the README ad hoc)

- Rejected: loses the "sounds like me" enforcement on this and all future docs.

## Decision

Chosen option: **Option B — one consolidated `docs-voice` skill, lane: creative** (user-ratified via AskUserQuestion).

- **Verbatim voice payload** copied (via `cp`, byte-identical) into `docs-voice/references/`: profile, characteristics, vocabulary, sentence-structure, humanity-signals (the voice foundation) + kernel.md + directives.md (the protocol). Dropped from the docs path: satirical-wit (install docs aren't satire), calibration (anchor texts live in odyssey-alive, unavailable here), bisociation.
- **The literal-zone carve-out** (the load-bearing adaptation, in `references/content-type-constraints.md`): docs split into a PROSE zone (full voice) and a LITERAL zone (fenced code, commands, paths, flags, `key: value`, URLs) where **voice rules are SUSPENDED**. Without it, "no colons/dashes" would corrupt `key: value` and `--flags` — and there's no hook backstop here, so the carve-out + validator are the only guard.
- **Two ported directives are gold for docs:** Citation Verification → "verify every command before documenting it"; Anti-Fabrication → "never document an unconfirmed step/flag." README correctness becomes an enforced gate.
- **One validator** (`docs-voice-validator`, model-pinned claude-opus-4-6, unique persona "release-notes/install-guide editor who treats every command as a contract"): checks literal-zone integrity FIRST, then prose voice. The text-eval 3-agent chain was NOT ported (overkill for one README; claude-enforcer's own `edit` forbids the chain for revisions).
- **Enforcement is prompt-level** — claude-enforcer's no-em-dash/no-colon hooks are host-local and not ported.
- `docs-voice` is the FIRST creative-lane skill here, activating the configured-but-unused creative lane.

> **"I'd like to carry over the writing kernel, edit, my-voice or any of the other important skills used to generate README.md that sound like me. See the claude-enforcer project and see how you can pull those skills into this project and convert them for working with documentation here."**

*— Captured 2026-06-07, source: user, skills-workshop conversation*

## Consequences

- New skill `.claude/skills/docs-voice/` (SKILL.md + 7 verbatim references + content-type-constraints + 1 validator agent); added to the Skill→Lane table (creative) and the `/route` catalog.
- The README itself is the next step: draft via `docs-voice`, with its commands verified against the real install (route to `/build-mcp`) — and writing it is creative-lane work, so `docs-voice`'s preflight will advise the lane mismatch when the session is on the analytical brain.
- The README's two install options describe the Phase 3 installers (single-project vs user-scope), which don't exist yet — so the README either documents the intended installers (clearly marked) or waits until `/build-mcp build` produces them. The verify-before-document directive applies: don't document install commands not yet confirmed to run.
- Internal path references inside the verbatim files that pointed at claude-enforcer siblings (text-eval, etc.) are now self-contained within docs-voice's own references; the authored files (SKILL.md, validator, content-type-constraints) reference only local paths.

## Confirmation Criteria

- Right when: a README drafted through `docs-voice` reads like the user (passes the validator's voice check) AND every install command is byte-exact and verified (passes the literal-zone + verify-before-document checks).
- Reconsider if: non-documentation creative work arrives in playwright-mcp (split out a reusable `voice` foundation per Option A); or the single validator proves too thin for longer docs (consider porting more of text-eval).
