# DEC-2026-06-07-global-override-websearch-webfetch-chrome

**Status:** accepted
**Tags:** override, WebSearch, WebFetch, claude-in-chrome, permissions, settings.json, deny, user-scope, every-project, Phase-4, steering, escape-hatch
**Related:** DEC-2026-06-07-mcp-instructions-discoverability, DEC-2026-06-07-authenticated-session-storagestate-artifact, DEC-2026-06-07-playwright-sourcing-and-install, DEC-2026-06-08-installer-non-interactive-and-arch-deps

## Context

The user asked how, after installing this MCP, it AUTOMATICALLY takes over
WebSearch/WebFetch in every project (current and future), and how to make
Playwright always get used instead of the claude-in-chrome browser extension.
This consolidates CLAUDE.md's "Overriding native WebSearch/WebFetch" and "Default
browser for debugging — replacing the claude-in-chrome plugin" sections into a
durable record (CLAUDE.md is slated to slim once `src/` exists).

## Decision Drivers

- "Every project, including future ones" = the change must live at USER level, not
  per-project — the same lever as the user-scope MCP registration.
- A hard, deterministic guarantee is preferred over soft steering alone.
- claude-in-chrome is a browser extension registered as an MCP; this package cannot
  uninstall it — only make it unreachable.
- The extension's one unique capability (real logged-in Chrome session) needs a
  replacement, or the override strands authed work.

## Decision

The takeover is **three user-level levers, set once by the Phase 3/4 installer** —
all under `~/.claude/`, which is what makes them global to current and future
projects:

1. **User-scope MCP registration** (`claude mcp add --scope user`) — makes
   `web_search`, `web_fetch`, and the wrapped `browser_*` tools available in EVERY
   project. (Project scope would limit them to one project.)

2. **Hard block via `~/.claude/settings.json` `permissions.deny`** (the deterministic
   guarantee, not a nudge):
   ```json
   { "permissions": { "deny": ["WebSearch", "WebFetch", "mcp__claude-in-chrome"] } }
   ```
   - `WebSearch` / `WebFetch` — the model literally cannot call the built-ins, so
     the only same-purpose tools left are this MCP's `web_search`/`web_fetch`
     (whose descriptions say "Replaces the built-in …" and whose `instructions`
     capability map carries a REPLACES NATIVE TOOLS line — the discoverability DEC).
   - `mcp__claude-in-chrome` — **server name, NO tool suffix** → denies EVERY tool
     the extension exposes, so browser work has exactly one route: this MCP's
     `browser_*`. The extension can't be uninstalled (it's a real-Chrome
     extension); denying makes it unreachable.

3. **Steering via `~/.claude/CLAUDE.md`** — "use playwright-mcp's web_search/web_fetch
   for all web access; use playwright-mcp for ALL browser work; never use the
   claude-in-chrome extension tools." Soft layer that smooths the redirect; the deny
   rules are what guarantee it.

**The auth gap is covered**, not left open: claude-in-chrome's unique value (a real
logged-in session) is replaced by `session-method`'s storageState artifact
(`session_login`, headed for 2FA, then headless reuse). **Escape hatch:** if a site
defeats headless entirely (hardware 2FA / anti-bot), the user temporarily removes
the `mcp__claude-in-chrome` deny line for that session — the installer prints how.

**Installer rules (Phase 4):** MERGE these entries into the existing `deny` array,
never overwrite the file; PROMPT and show a diff before touching
`~/.claude/settings.json`. **Verify after install:** in a fresh project, a search
call resolves to `mcp__playwright-mcp__web_search` (not native WebSearch) and a page
open uses `browser_navigate` (not a claude-in-chrome tool).

> **"how do I make sure that after I install this MCP in claude, that it
> automatically takes over all web fetch and web search functionality in every
> project? And how do I introduce the chromium plugin-like capability, so that
> playwright always gets used instead of the chromium plugin?"**

*— Captured 2026-06-07, source: user, skills-workshop conversation*

## Consequences

- Phase 4 of `build-mcp`'s `build` mode applies these (prompt + diff + merge), and
  the README documents both the deny rules and the escape hatch.
- The deny is deterministic: with the built-ins blocked there is no native web path,
  and with `mcp__claude-in-chrome` blocked there is one browser path — so takeover
  does not depend on steering holding.
- Removing the override (to re-enable native tools or the extension) is a manual
  edit of `~/.claude/settings.json`; the installer documents reversal.

## Confirmation Criteria

- Right when: in a fresh project never configured before, web search/fetch route
  through `mcp__playwright-mcp__*` and browser work never reaches claude-in-chrome,
  with no per-project setup — and a 2FA site is reachable via a `session_login`
  storageState capture (or the documented escape hatch).
- Reconsider if: Claude Code changes how `permissions.deny` treats built-in tools or
  MCP server-level denials, or if denying the built-ins degrades the model's ability
  to find the replacement (then lean harder on steering + tool descriptions).
