# DEC-2026-06-26-remote-streamable-http-transport-claude-ai

**Status:** accepted (implementation pending — Phase: extend)
**Tags:** remote-transport, oauth, security, claude-ai-connector, streamable-http, transport, prompt-injection, src/index.ts, browser.ts
**Related:** [DEC-2026-06-08-native-websearch-webfetch-doublecheck], [DEC-2026-06-07-authenticated-session-storagestate-artifact], [DEC-2026-06-07-mcp-instructions-discoverability], [DEC-2026-06-07-global-override-websearch-webfetch-chrome], [DEC-2026-07-28-mcp-spec-2026-07-28-adoption-scope]

## Context

The server is stdio-only today (`StdioServerTransport` in `src/index.ts`, wrapping
`@playwright/mcp` headless via in-process proxy composition). The user wants to
expose it to **claude.ai as a remote custom connector** so claude.ai routes page
work through this server instead of its built-in fetch — the stated primary
motivation is **JS rendering + real page interaction**, which native WebFetch
can't do.

Verified against current Anthropic docs (support.claude.com "get started with
custom connectors", code.claude.com/docs/mcp, modelcontextprotocol.io spec):

- claude.ai connects to the server **from Anthropic's cloud IP ranges**, not the
  user's device — true across claude.ai, Desktop, Cowork, mobile. The server must
  be publicly reachable from those ranges.
- It requires **public HTTP — Streamable HTTP or SSE; stdio cannot connect**.
- The connector UI is **OAuth-driven**, but OAuth is `SHOULD`, not `MUST` — a
  server that never returns 401 connects unauthenticated. claude.ai uses
  **Dynamic Client Registration (DCR)** to register itself.
- The installed `@modelcontextprotocol/sdk@^1.29` already ships
  `server/streamableHttp.js` (`StreamableHTTPServerTransport`) **and** a full
  OAuth toolkit under `server/auth/` (`mcpAuthRouter`, `ProxyOAuthServerProvider`,
  `requireBearerAuth`, a DCR `register` handler, the `OAuthServerProvider`
  interface). Verified by reading `node_modules/.../dist/esm/server/`.

This reverses the IP-exposure posture of
[DEC-2026-06-08-native-websearch-webfetch-doublecheck] (which deliberately avoided
driving a browser on anyone's behalf but the user's) — accepted knowingly, and
mitigated by hosting on a VPS (datacenter egress) plus the hardening below.

## Decision Drivers

- User wants JS rendering + interactive page control reachable from claude.ai.
- "Single env entry = the MCP server URL" turns the remote transport on.
- stdio path for Claude Code must stay byte-for-byte unchanged.
- Full-toolset internet exposure is **credentialed-RCE-adjacent**: the driving LLM
  ingests untrusted page content on every navigate/fetch and is prompt-injectable;
  auth does not fix post-session injection (two independent design agents agreed).
- Minimal-but-real auth that claude.ai's UI accepts.
- Minimal new dependencies (exact-pinned ethos).

## Options Considered

### Transport — Option A: dual transport, conditional (CHOSEN)
- Good: stdio stays today's behavior; remote comes up only when configured.
- Good: `StreamableHTTPServerTransport` is already in the pinned SDK; host on
  `node:http` ⇒ no new dep for the transport.
- Bad: one `Server` binds one transport (SDK contract), so the inline outward
  server must be refactored into a `createOutwardServer(upstream, instructions)`
  factory; needs a stateful session map keyed by `Mcp-Session-Id`.

### Remote scope — Option A: full 27-tool surface
- Bad: exposes `browser_run_code_unsafe`, `session_login`, secrets to a
  prompt-injectable cloud LLM. **Rejected.**
### Remote scope — Option B: interactive + page JS, hardened (CHOSEN)
- Good: delivers the JS + interaction the user actually wants.
- Good: removes the RCE-grade runtime tool and the credential-touching tools.

### Auth — Option A: hand-rolled standalone OAuth AS
- Bad: large security surface owned forever; breaks single-env goal. **Rejected.**
### Auth — Option B: unauthenticated + secret URL + Anthropic-IP allowlist
- Good: matches one-URL goal, zero OAuth code.
- Bad: IP allowlist only proves "some claude.ai tenant"; secret URL is a weak,
  unrotatable bearer — judged too thin for an interactive JS-running surface.
  **Rejected as the floor** (retained as a documented fallback).
### Auth — Option C: proxy-mode OAuth via SDK, GitHub upstream (CHOSEN)
- Good: real, revocable, audited auth; uses the SDK auth toolkit.
- Bad: GitHub lacks DCR ⇒ server acts as its own AS and delegates login to
  GitHub; adds `express` (the SDK auth router is express-based).

## Decision

1. **Transport** — Add `StreamableHTTPServerTransport` on `node:http` **alongside**
   stdio. Refactor the inline outward server into a
   `createOutwardServer(upstream, instructions)` factory; stateful session map
   keyed by `Mcp-Session-Id`; **all** HTTP sessions + local stdio share the
   **single** upstream `@playwright/mcp` chromium. stdio unchanged.
2. **Gate** — Remote transport comes up only when `PLAYWRIGHT_MCP_PUBLIC_URL` is
   set; absent ⇒ stdio-only default. Bind `127.0.0.1:8765`
   (`PLAYWRIGHT_MCP_PORT` optional override); nginx proxies. (OAuth adds GitHub
   client id/secret + the allowlisted identity, so config is no longer literally
   one var, but the public URL remains the on-switch.)
3. **Host** — jstack VPS behind nginx + certbot TLS; firewall/nginx allowlisted to
   Anthropic's published IP ranges (auto-refreshed); server bound to localhost.
4. **Remote scope** — Expose `web_fetch` + full interactive browsing +
   `browser_evaluate` (page JS). **Denylist** on the remote surface, filtered from
   **both** `ListTools` and `CallTool` (hiding alone is insufficient):
   `browser_run_code_unsafe`, `session_login`, `session_status`,
   `session_scaffold_tests`, `browser_file_upload`. A `REMOTE_MODE` flag in
   `src/index.ts` drives the filter. Remote instance deploys **secrets-free** (no
   `secrets.env`, no sessions dir) with an **egress allowlist** blocking
   `169.254.169.254` (cloud metadata), `127.0.0.0/8`, RFC1918 — mandatory because
   `browser_navigate` alone enables SSRF regardless of eval.
5. **Auth** — Proxy-mode OAuth via the SDK auth toolkit, upstream = **GitHub**.
   Because GitHub lacks DCR, the server acts as its own authorization server
   (`mcpAuthRouter` + an `OAuthServerProvider` implementation), delegates login to
   GitHub, issues its own tokens, and **locks authorization to the user's own
   GitHub account/email**. `express` added as a remote-mode-scoped dependency.

> **"most of the reason I'm choosing this plugin over claude's native web fetch is
> so that it can run javascript and actually interact with the page."**

*— Captured 2026-06-26, source: user (design conversation)*

## Consequences

- New module(s): the gated HTTP host + session map + OAuth wiring (likely
  `src/remote.ts` / `src/auth.ts`) and the `REMOTE_MODE` tool filter; `src/index.ts`
  refactored to the server factory. `express` added to `package.json`.
- The single shared chromium means concurrent claude.ai sessions interleave page
  state — acceptable for a single-user connector; documented.
- Deployment artifacts: an nginx TLS vhost + Anthropic-IP allowlist (auto-refresh),
  a secrets-free jstack service unit, a GitHub OAuth app.
- The egress allowlist + secrets-free deploy + tool denylist — **not** the auth
  model — are what keep this from being a credentialed-RCE endpoint; they ship
  first.

## Confirmation Criteria

- Right if: stdio behavior is provably unchanged when `PLAYWRIGHT_MCP_PUBLIC_URL`
  is unset; claude.ai can add the connector, complete the GitHub OAuth flow, and
  call `web_fetch` + interactive/eval tools; denylisted tools are absent from
  `ListTools` **and** rejected by `CallTool`; egress to metadata/localhost/RFC1918
  is blocked.
- Reconsider if: claude.ai's UI rejects the GitHub-fronted (non-DCR) auth flow in
  testing (fall back to a managed DCR-native IdP or Option B); or if single-shared-
  browser interleaving proves unworkable (move to a per-session context pool).
