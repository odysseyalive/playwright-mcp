# DEC-2026-06-07-readme-last-step-bare-bones

**Status:** accepted
**Tags:** README, documentation, docs-voice, build-mcp, timing, bare-bones, claude-enforcer-format, install-section
**Related:** DEC-2026-06-07-docs-voice-port, DEC-2026-06-07-build-mcp-lifecycle-orchestrator, DEC-2026-06-07-playwright-sourcing-and-install

## Context

After standing up `docs-voice`, the user specified WHEN and HOW the README should
be written: not now — at the last step of the build — and bare-bones, easy for
anyone to understand and use, modeled on the format of
`~/lab/claude-enforcer/README.md`.

## Decision

- **Timing — built LAST.** The README is the final step of the build, after every
  phase (incl. the Phase 3 installers) is built and the T0–T3 test gate is green.
  This makes every documented command real and verified (the verify-before-document
  directive `docs-voice` enforces); the README is never drafted ahead of the
  installers it documents. Captured as build-mcp `build` mode step 6.
- **Scope — bare-bones.** Shortest useful README: one-or-two-sentence "what it is +
  why" → Install → short "use it" → License. No philosophy essays, no long
  narrative sections, images optional.
- **Format model — `~/lab/claude-enforcer/README.md`** (mirror its FORMAT, not its
  length — that README runs long with essays/philosophy; ours stays minimal):
  - Install section states requirements up front (Node ≥18, ~170 MB one-time
    Chromium download, Linux system-libs/sudo caveat — per the Playwright sourcing
    DEC), then platform-splits with bold labels: `**Linux / macOS**` → a ```bash
    block, `**Windows PowerShell**` → a ```powershell block. Never describe one
    platform and leave the other to inference.
  - Code presentation: fenced blocks with language tags; Claude-Code slash-commands
    in bare fenced blocks; one command/idea per block; every block copy-pasteable.
  - The two install options (single-project / all-projects user-scope) are clearly
    separated, each with its per-platform block; never interleaved.
  - Lead with what it gets the reader, not a feature list (kernel § 1).

> **"I'd like the readme to be completed at the last step of the build. the readme
> needs to be bare bones, easy for anyone to understand and use. See the README.md
> in the ~/lab/claude-enforcer project to understand format, how code is presented,
> etc."**

*— Captured 2026-06-07, source: user, skills-workshop conversation*

## Consequences

- The README format rules are recorded in `docs-voice`'s
  `references/content-type-constraints.md` § `readme` (the actionable home, read
  when drafting).
- `build-mcp` `build` mode carries the README as its terminal step 6 (read when
  building), routing to `/docs-voice`.
- These survive until "the last step of the build" — possibly many sessions away —
  because they live where each will be read, plus this ledger record.

## Confirmation Criteria

- Right when: at build's end, a short README is produced via `docs-voice` whose
  install section mirrors the claude-enforcer format (requirements up front +
  per-platform bash/powershell blocks + the two separated install options) and
  whose every command is verified — and a newcomer can install and use the MCP
  from it alone.
- Reconsider if: the project grows enough that bare-bones leaves users stuck (then
  split deeper material into a COMMANDS.md the way claude-enforcer does, keeping the
  README itself minimal).
