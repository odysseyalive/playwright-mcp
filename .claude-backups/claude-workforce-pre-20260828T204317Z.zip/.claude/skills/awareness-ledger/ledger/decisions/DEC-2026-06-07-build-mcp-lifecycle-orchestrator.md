# DEC-2026-06-07-build-mcp-lifecycle-orchestrator

**Status:** accepted
**Tags:** build-mcp, lifecycle-orchestrator, testing, node-test, parity-harness, fixtures, code-evaluator, orchestrator-no-drift, skill-design
**Related:** DEC-2026-06-07-web-stack-layering-and-research-agents, DEC-2026-06-07-authenticated-session-storagestate-artifact

## Context

After specifying the web stack + session tools, the user asked to "convert what we
have so far to a build skill with different functions" that can build the project,
add features, debug issues, and test features as they roll out. The project is
docs-only (no `src/` yet); the existing skills are method specs + code-evaluator +
awareness-ledger. A design agent panel (two read-only Plan agents — one on function
decomposition, one on testing strategy) supplied independent input per the
mandatory-agents directive; they converged.

## Decision Drivers

- The harness already enforces single-ownership and is documentation-dense — a
  build skill that embedded "how to build web_search" or its own quality checklist
  would become a fifth source of truth that drifts.
- The user wants four lifecycle capabilities: build / add-feature / debug / test.
- "Test features as they roll out" needs a repeatable, trustworthy gate; live
  search engines and 2FA are inherently flaky and must never gate a build.
- code-evaluator already owns code quality; the method specs own per-tool "how."

## Options Considered

### Option A: 4 modes (build / extend / debug / test)

- Good, because each mode has genuinely distinct entry conditions and reference
  material; `extend`'s design+DEC+spec preamble is real work `build` doesn't do.
- Cost: `build` and `extend` share a soft boundary (both produce code).

### Option B: 3 modes (build [+design preamble] / debug / test)

- Good, because leaner surface.
- Bad, because it overloads `build` with two distinct front-ends.

### Subject-matter decomposition (per-tool modes)

- Rejected: would grow per-tool sections that drift from the specs.

## Decision

Chosen option: **a new `build-mcp` skill, 4 modes (build / extend / debug /
test), pure orchestrator** (user-ratified via AskUserQuestion; name and 4-mode
structure both confirmed). Mode boundaries are drawn on **lifecycle verbs**, never
subject matter, so the skill never grows a per-tool section. It routes/consults
and never restates: method specs (how to implement each tool), `code-evaluator`
(quality), `skill-builder` (skill/agent authoring, e.g. Phase 2b `research-paper`),
`awareness-ledger` (DECs).

- **build** — advance CLAUDE.md Phase 1→5; read each method spec before writing the
  matching `src/tools/X.ts`; `code-evaluator review` after every change; `test` gate.
- **extend** — design + record a DEC + update/author the spec, then implement.
- **debug** — interactive runtime investigation (wrapped `browser_*` + the session
  auth workflow); read-only on code, proposes fixes back to build/extend.
- **test** — a **deterministic-gate tiered harness** on Node's built-in `node:test`
  (zero new deps): **T0** boot/smoke (grown from `scripts/smoke.mjs`; asserts the
  instructions map + tool list), **T1** per-tool acceptance vs local fixtures
  (recorded SERP HTML, fixture HTML/PDF, fake-login app, stubbed layers), **T2**
  live-fragile **capture-and-warn, never a gate** (the parity harness reframed as
  fixture capture), **T3** regression replay. The gate is 100% deterministic — a
  live engine can never turn a build red. Every tool/feature lands **with its T1
  fixture in the same step it's built**; T0 assertions are extended per tool.

Testing complements code-evaluator (quality axis) on a distinct behavioral axis:
run `code-evaluator review` first, then the behavioral tier.

> **"convert what we have so far to a build skill with different functions. In
> that skill we'd also need to add testing measures."**
> **"whatever makes the smartest sense for building a skill that can build this
> project, add new features if asked and debug issues as well as test features as
> they roll out"**

*— Captured 2026-06-07, source: user, skills-workshop conversation*

## Consequences

- New skill `.claude/skills/build-mcp/SKILL.md` (coding lane, MODEL-LANE-GATE
  embedded); added to the Skill→Lane table and the `/route` catalog (modes
  build/extend/debug/test).
- `build-mcp` is the first executable *workflow* skill here (the others are specs);
  it is the entry point for actually materializing Phase 1+ — including pruning
  CLAUDE.md's inline seed code once `src/` exists (workshop item #3).
- Finishing step: run `/skill-builder route embed` to add the standard
  `CODE-EVAL-EMBED` (code-touching) and `ROUTE-EMBED` (freeform-follow-up) managed
  blocks — build-mcp qualifies for both; its workflow already bakes in the
  consult-code-evaluator and route-follow-ups discipline explicitly.

## Confirmation Criteria

- Right when: `build-mcp build` carries the project from docs-only through a phase
  with the T0/T1 gate green and no per-tool knowledge duplicated from the specs;
  `test` catches a regression while live-engine flakiness never reds the gate.
- Reconsider if: the `build`/`extend` boundary proves to add no value in practice
  (collapse to 3 modes), or the orchestrator starts accreting spec content (drift —
  refactor the duplicated content back out to the owning skill).
