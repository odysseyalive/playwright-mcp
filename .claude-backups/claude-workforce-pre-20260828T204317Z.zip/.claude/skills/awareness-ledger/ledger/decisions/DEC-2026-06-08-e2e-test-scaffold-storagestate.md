# DEC-2026-06-08-e2e-test-scaffold-storagestate

**Status:** accepted
**Tags:** e2e-scaffold, templates/e2e, scripts/scaffold-e2e.mjs, session-management, storageState, setup-project, dependencies, playwright-config, src/index.ts, buildInstructions, src/tools/session.ts, secrets, mcp-discoverability, distribution, CI, extend
**Related:** DEC-2026-06-07-authenticated-session-storagestate-artifact, DEC-2026-06-07-mcp-instructions-discoverability, DEC-2026-06-07-phase2-custom-tools-build, DEC-2026-07-04-project-env-credentials-and-unreachable

## Context

The session-method spec describes two consumers of the mode-600 `storageState`
artifact `session_login` captures: (1) interactive debugging via the wrapped
`browser_*` tools and (2) **generated Playwright test suites** ("Consumer 2") that
reuse the captured login through Playwright's canonical **setup-project +
`projects[].dependencies`** pattern. Consumer 2 was specified but never
materialized — there was no concrete, reusable scaffold. A user asked for one,
explicitly: "as long as it's easily distributable and discoverable." This is an
`extend` (a feature not in the documented Phase 1–5 plan).

The conceptual trigger: the user correctly observed that "convert a `.spec.ts` to
playwright-mcp" has no mechanical meaning — a `.spec.ts` is code a runner
executes; the MCP tools are model-driven. The right framing is the two-layer
model: the **agent** drives `browser_*` to *discover* a flow; the known-good flow
is *frozen* as a deterministic `.spec.ts` that a runner executes, reusing a login
the MCP captured once (including headed 2FA the runner cannot do).

## Decision Drivers

- **Distributable** — ships with the package, works after `install.sh`, no
  per-project hand-wiring (user hard requirement).
- **Discoverable** — findable by both the human and the model-in-another-project
  without prior knowledge (user hard requirement).
- Secrets discipline is non-negotiable: storageState files are live-token secrets
  (mode 600, gitignored, never echoed, never committed).
- The MCP owns capture, including **headed** 2FA/SSO that `npx playwright test`
  in CI structurally cannot perform.
- No drift: a template config in a consuming project cannot `import` this repo's
  `src/` — any shared logic is a deliberate, tested duplication.

## Options Considered

### Option A: tracked `templates/e2e/` + Node generator (`scripts/scaffold-e2e.mjs`)

- Good — scaffolding is a build-time filesystem copy+substitute; matches the
  existing `scripts/*.mjs` convention; independently testable in the `node --test`
  gate; ships in the package.
- Bad — the model in another project can't see a template dir or npm script; needs
  an explicit discoverability hook.

### Option B: new MCP tool `session_scaffold_tests`

- Good — maximally discoverable to the model (shows up in the tool list).
- Bad — category error: scaffolding is not a browser-runtime action; adds tool #27
  to a server already at 26 with documented deferred-schema concerns; an MCP tool
  writing `.spec.ts` into an arbitrary `outDir` is a sharper-edged capability on an
  always-loaded user-scope server.

### Option C: docs-only README snippet

- Good — zero new code.
- Bad — fails "no per-project hand-wiring"; copy-paste IS the hand-wiring ruled out.

### Setup-project sub-fork: re-login (classic) vs freshness guard

- Re-login — Bad: cannot do headed 2FA in CI; drags credentials into generated
  test code (violates the spec's "credentials … never the generated code").
- Freshness guard — Good: credential-free; mirrors `session_status`; points back
  to `session_login` for (re)capture.

## Decision

Chosen: **Option A + discoverability hooks; reject B and C-as-sole-mechanism;
setup-project is a freshness GUARD, not a re-login.**

- Ship a tracked `templates/e2e/` (`playwright.config.ts`, `tests/auth.setup.ts`,
  `tests/example.spec.ts`, `README.md`) + dependency-free
  `scripts/scaffold-e2e.mjs` (`npm run scaffold:e2e -- --session <name> --out
  <dir>`) that copies + substitutes a `__SESSION_NAME__` placeholder, refuses to
  overwrite without `--force`, and writes **no** session data into the target.
- Discoverability via the project's existing three layers: (1) a generated line in
  `buildInstructions()` (`src/index.ts`) emitting the **resolved absolute** scaffold
  command — computed from `import.meta.url`, robust because the server is
  registered from the cloned repo dir, not a global npm install (so `npx
  @francis/playwright-mcp` would not resolve); (2) a pointer appended to the
  `session_login` tool description; (3) a README section.
- `tests/auth.setup.ts` is a freshness guard: existence + JSON-parse + non-empty
  cookies + age warning, throwing an actionable message naming `session_login`
  (headed for 2FA) and `session_status`. The true freshness probe stays
  `session_status`.
- The generated `playwright.config.ts` resolves `use.storageState` at
  config-eval time via the **same** `PLAYWRIGHT_MCP_SESSIONS` /
  `XDG_CONFIG_HOME` / `APPDATA` precedence as `src/secrets.ts` `sessionsDir()`
  (never a baked absolute home path), plus a `STORAGE_STATE` direct-path env
  escape hatch for CI to inject the gitignored secret out-of-band.

> **"as long as it's easily distributable and discoverable"**

*— Captured 2026-06-08, source: user (build-mcp extend session). Two independent
design agents converged on A1 + guard + env-resolved path.*

## Amendment — 2026-06-08 (same day): MCP tool added (`session_scaffold_tests`)

The "reject Option B (a new MCP tool)" call above was **partially reversed the
same day, at the user's direction.** On review the user pointed out that the MCP
is the universal, discoverable surface, and a generator reachable only by
`cd`-ing into the cloned repo undercuts the very "discoverable by the invoking
project" goal the scaffold exists to serve — the absolute shell command emitted
into `buildInstructions()` was the tell that the capability wanted to be a tool.

**Resolution: do both, sharing one core.** The generator moved to
`src/scaffold.ts`; a new `session_scaffold_tests({ session, outDir, force })` tool
(`src/tools/scaffold.ts`, registered in `src/tools.ts`) and the
`scripts/scaffold-e2e.mjs` CLI both call it. `buildInstructions()` now points at
the tool (not a shell path); the `session_login` description names the tool.

Everything else from the original decision **stands unchanged**: the
one-implementation discipline (now enforced by the shared `src/scaffold.ts`), the
freshness-guard `auth.setup.ts` (not a re-login), the portable `storageState`
resolution + `STORAGE_STATE` CI hatch, and the no-session-data-leak guarantee.
Only the "no MCP tool" stance is lifted. Costs accepted: tool #27 on a
deferred-schema server, and a file-writing tool capability — bounded (fixed
template, explicit `outDir`, the result reports exactly what it wrote).

> **"the MCP is the universal discoverable surface … okay, let's do it."**

*— Captured 2026-06-08, source: user (build-mcp extend follow-up).*

## Consequences

- A second source of the sessions-path precedence now lives in the generated
  config (can't import `secrets.ts`). Mitigated by cross-reference comments in
  both files and a scaffold test asserting the env-precedence tokens are present.
- Primary risk guarded: **storageState token leakage** — the generator copies no
  session file; the template declares storageState a mode-600 secret, never
  committed; CI supplies it as a masked secret via `STORAGE_STATE`.
- T1 coverage: `scripts/test-scaffold.mjs` (deterministic — generate into a temp
  dir, assert files + placeholder substitution + no secret leaked + env-precedence
  tokens). T0 instructions assertion may extend to the scaffold line.

## Confirmation Criteria

Right if: after `install.sh`, a user (or the model, prompted by the instructions
line) can scaffold a runnable suite into any project with one command, capture a
session once via `session_login`, and `npx playwright test` reuses it
deterministically — with no credentials or session tokens ever entering the
consuming project's repo. Reconsider if `@playwright/mcp` ever ships an
equivalent, or if the path-precedence duplication drifts (the test should catch
it first).
