# DEC-2026-06-07-authenticated-session-storagestate-artifact

**Status:** accepted
**Tags:** session-management, authentication, storageState, session_login, session_status, src/tools/session.ts, session-method, debugging, test-suite-auth, secrets, Phase-2
**Related:** DEC-2026-06-07-web-stack-layering-and-research-agents, DEC-2026-06-08-e2e-test-scaffold-storagestate, DEC-2026-07-04-project-env-credentials-and-unreachable, DEC-2026-07-08-session-auth-context-stealth-disguise, DEC-2026-07-21-session-login-challenge-capture-mode, DEC-2026-07-28-mcp-spec-2026-07-28-adoption-scope

## Context

The workshop turned to using playwright-mcp as a debugging tool for local and
remote sites (goal #4), and to test suites whose Playwright scripts include
logins that must hold "until the end of the test cycle." Question: how should an
MCP like this manage authenticated sessions?

## Decision Drivers

- An MCP server's process lifetime is tied to the Claude session, **not** to a
  test run (`npx playwright test`, often in CI runs outside the MCP). It cannot
  reliably "hold" a live session through a test cycle.
- Two distinct needs were being conflated: interactive debugging (session must
  survive many tool calls / restarts) and test-suite authoring (the generated
  scripts own their own auth lifecycle).
- 2FA / SSO / hardware keys defeat headless login — a human-in-the-loop capture
  is sometimes unavoidable.
- Session tokens are secrets; a logged-out session causes confusing test
  failures, not obvious ones.
- The project already has a persistent profile plan and `secrets.env`.

## Options Considered

### Option A: Hold a live session in the MCP server through the test cycle

- Bad, because the server's lifetime ≠ the test run's; CI runs outside the MCP;
  a long-lived process dependency is fragile. Rejected.

### Option B: storageState as a portable auth artifact; MCP produces it, debugging + tests consume it

- Good, because it decouples authentication from the test run (CI-friendly),
  uses Playwright's canonical primitive, and serves both use cases from one
  artifact. The MCP authenticates once and hands off.
- Good, because thin helpers (`session_login`, `session_status`) cover the two
  awkward-through-raw-browser_* flows (headed 2FA capture, freshness probe) while
  leaning on upstream `@playwright/mcp` storage-state + user-data-dir config for
  the rest.
- Cost: session files are secrets needing 600/gitignore discipline; storageState
  expires and needs a freshness check.

### Option C: Persistent userDataDir only

- Good for long-lived interactive debugging.
- Bad as the sole mechanism: locks the profile dir (one server at a time), not
  portable to generated tests/CI. Kept as a complement, not the spine.

## Decision

Chosen option: **Option B — the storageState-artifact model, with two thin helper
tools and a documented generated-test pattern.** Persistent `userDataDir`
(Option C) is retained as a complement for long-lived interactive debugging.

- **Two thin tools** (`src/tools/session.ts`): `session_login({name, loginUrl,
  successSignal, headed?, credKeys?})` captures an authed session (headless from
  `secrets.env`, or **headed** for 2FA/SSO) and writes a mode-600 storageState
  file to `~/.config/playwright-mcp/sessions/<name>.json`; `session_status`
  validates freshness (probe an authed route → fresh/stale/missing).
- **Two consumers:** interactive debugging loads the artifact into the wrapped
  `@playwright/mcp` browser (or uses a persistent profile); generated test scripts
  use Playwright's setup-project + `dependencies` + `use: { storageState }`
  pattern, so the session holds for the whole cycle structurally.
- **The MCP never babysits a live session through a test cycle** — it emits a
  portable artifact and hands off.
- **Context isolation:** the auth/debugging context is separate from the stealth
  `web_search`/`web_fetch` context (`src/browser.ts`) — no cross-contamination.
  *(Reinterpreted 2026-07-08, DEC-2026-07-08-session-auth-context-stealth-disguise:
  isolation means IDENTITY — separate context/profile/cookie jar — NOT that the
  auth context must be un-disguised. The anti-detection technique is now shared
  via `src/stealth.ts`; the original naked-headless implementation was a defect
  that failed bot-protected logins.)*
- **Secrets discipline:** creds in `secrets.env`; storageState files are secrets
  (600, gitignored, never echoed); generated scripts reference the path/env,
  never embed creds or tokens.
- **Own spec skill:** `/session-method` (coding lane, gated, catalogued).

> **"Some of that can include logins where the session must be in place until the
> end of the test cycle. What is the best way to manage that through an MCP like
> this?"**

*— Captured 2026-06-07, source: user, skills-workshop conversation*

## Consequences

- New custom tools `session_login` / `session_status` (Phase 2), spec'd in
  `/session-method`; CLAUDE.md updated (Architecture custom-tools, repo layout
  `src/tools/session.ts`, a method pointer, goal #4 cover).
- Covers the "authenticated sessions" gap previously flagged under CLAUDE.md
  § Default browser for debugging (layer 3) — headed login once, persist.
- Adds a sessions directory to secret-path handling / `.gitignore` and installer.
- Verify exact `@playwright/mcp` 0.0.75 storage-state / user-data-dir flag names
  before building (do not assume).

## Confirmation Criteria

- Right when: a single `session_login` capture lets both an interactive debugging
  session and a generated `npx playwright test` run operate authenticated, with
  `session_status` catching expiry before confusing failures occur.
- Reconsider if: a target's auth can't be captured into a reusable storageState
  (server-bound/rotating tokens, per-request nonces) — then that site needs a
  live-login step in its own test setup, and the MCP's role narrows to debugging
  only.
