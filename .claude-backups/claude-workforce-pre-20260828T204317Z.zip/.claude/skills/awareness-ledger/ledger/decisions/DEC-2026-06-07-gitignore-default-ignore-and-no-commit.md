# DEC-2026-06-07-gitignore-default-ignore-and-no-commit

**Status:** accepted (AMENDED 2026-07-28 — commit now allowed, push still forbidden)
**Tags:** gitignore, git-hygiene, commit-policy, push-policy, .claude, CLAUDE.md, temp-files, build-mcp, scaffolding-vs-package, no-commit
**Related:** DEC-2026-06-07-build-mcp-lifecycle-orchestrator, DEC-2026-06-07-readme-last-step-bare-bones

## Context

The user set a git-hygiene rule for this repo: the `.claude` directory, `CLAUDE.md`,
and any temporary files created during the build must be in `.gitignore`, kept
current through the build; only files intended to commit stay tracked; and the user
is always the one who commits.

## Decision

- **Default-ignore policy.** `.gitignore` ignores by default: `.claude/`, `CLAUDE.md`,
  secrets (`.env`, `*.secret`), dependencies/build output (`node_modules/`, `dist/`),
  and temporary/working files (`*.log`, `*.tmp`, `tmp/`, `scratch/`, `screenshots/`,
  `.cache/`). Only files **intended to commit** are tracked — un-ignored
  deliberately: `src/`, `package.json`, `tsconfig.json`, `install.sh`, `install.ps1`,
  `README.md`, `.gitignore`, `.env.example`.
- **Rationale for ignoring `.claude/` + `CLAUDE.md`:** they are the **build
  scaffolding** (the skills/meta-tooling and the build plan used to CONSTRUCT the MCP
  package), not the shipped package itself. The committed repo is the distributable
  MCP; the scaffolding stays local.
- **Kept current through the build.** As the build creates new temp artifacts,
  `.gitignore` is updated to cover them (a standing item in build-mcp's orchestrator
  discipline). New non-scaffolding source files that ARE meant to ship get committed
  (not ignored).
- **No-commit rule (hard, standing).** The assistant NEVER runs `git commit` or
  `git push` — the user is always the one who commits. The assistant may stage/inspect
  only when explicitly asked, but committing is the user's act, full stop.
  **→ SUPERSEDED 2026-07-28 — see § Amendment. Committing is now allowed; pushing is not.**
- **Applied now:** `.gitignore` created at repo root (preventive — the repo isn't
  git-initialized yet; `git init` is Phase 1). CLAUDE.md Bootstrap `.gitignore` block
  updated to match + § Git hygiene rule. build-mcp orchestrator discipline carries
  the rule. A `feedback` memory records the no-commit rule for cross-session
  persistence.

> **"I'd like to make sure the .claude directory, CLAUDE.md and any temporary files
> that get created in this repo are in .gitignore, and .gitignore is kept up with
> during the build process. I only want files that we intend to commit to the repo
> to not be part of .gitignore. Also, I will always be the one to commit."**

*— Captured 2026-06-07, source: user, skills-workshop conversation*

## Amendment — 2026-07-28: commit allowed, push still forbidden

The no-commit half of this decision is relaxed at the user's direction. The
default-ignore policy above is **unchanged** and still governs what is trackable.

- **The assistant MAY run `git commit`** when the user asks for a commit.
- **The assistant still NEVER runs `git push`.** Publishing to a remote remains
  the user's act, full stop. Nothing about this amendment authorizes a push, and
  "commit and push" is a request to commit, then hand back.
- Unchanged: the assistant does not commit *unprompted*. "Allowed" means allowed
  when asked, not automatic at the end of a task.
- Unchanged: `.claude/` and `CLAUDE.md` stay gitignored, so ledger entries and the
  build plan never enter a commit — a decision recorded here is developer-local by
  design, and the commit that implements it will not carry it.

> **"okay let's commit this to main"** … **"please update that directive to allow
> commit only"**

*— Captured 2026-07-28, source: user, MCP-2026-07-28 adoption conversation*

Rationale, in the user's framing: the friction of hand-running a commit outweighed
the safety the blanket rule bought, and the genuinely irreversible step is the
push, not the commit — a local commit is recoverable (`git reset`), a push to a
shared remote is not.

## Consequences

- The committed repo will contain only the distributable package; the skills and the
  build plan are developer-local.
- Note: since `CLAUDE.md` is itself gitignored, the committed repo has no build plan —
  this is intended (the package ships, the plan doesn't). It also softens workshop
  item #3 (inline-seed-code drift) for the *committed* tree, though the source-of-truth
  question between CLAUDE.md and `src/` still stands locally.
- ~~Any future automation must respect the no-commit rule — surface a ready-to-run
  commit command for the user rather than committing.~~ **(amended 2026-07-28)**
  Automation may commit when asked; it must still surface a ready-to-run `git push`
  rather than running one.

## Confirmation Criteria

- Right when: after `git init` + `git add -A`, `git status` shows only the
  intended-to-commit files staged (no `.claude/`, no `CLAUDE.md`, no temp artifacts).
  The "assistant has never run a commit" clause was retired 2026-07-28; the live
  criterion is now that the assistant has never run a **push**.
- Reconsider if: the user later decides the skills/CLAUDE.md SHOULD be versioned in
  this repo (then un-ignore them deliberately) — the default-ignore stance is the
  current rule, not a permanent law.
