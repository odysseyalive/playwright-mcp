# DEC-2026-06-07-web-stack-layering-and-research-agents

**Status:** accepted
**Tags:** web-stack, layering, web-fetch, web-search, deep-research, src/extract.ts, src/score.ts, agents, research-paper, citations, Phase-2
**Related:** DEC-2026-06-07-web-search-three-engine-stealth, DEC-2026-06-07-mcp-instructions-discoverability

## Context

After designing the three-engine `web_search`, the workshop turned to
`deep_research` and to how the three custom tools relate. The original specs had
each tool re-implementing scoring, scholarly boost, fetching, and citation
extraction, and `deep_research` was a standalone gatherer returning bare raw
material. The user wanted: (a) `deep_research` to stand on the new `web_search`
rather than reinvent it, (b) Scholar + citations + CMS handled once, (c) a new
layer that develops a thesis and writes a verified 1300–1500-word cited paper
filling knowledge gaps with extra research, and (d) agents used across all three
tools.

## Decision Drivers

- Eliminate duplication across the three tools.
- An MCP server is deterministic TypeScript with **no LLM** — it cannot reason,
  develop a thesis, or write a paper.
- The project's immutable directives: agents mandatory for non-obvious judgment;
  unique personas; a deployed team carries a read-only research-assistant;
  research runs on the coding model.
- Keep `web_search`/`web_fetch` fast as drop-in WebSearch/WebFetch replacements.
- Avoid shadowing the bundled global `deep-research` skill in `/route`.

## Options Considered

### Option A: Three peer tools, each self-contained

- Good, because simple mental model.
- Bad, because massive duplication (scoring, scholarly list, fetch, citations ×3)
  and `deep_research` can't reach `web_search`'s citations without re-fetching.

### Option B: Three-layer stack over shared modules + session-side agent paper layer

- Good, because each layer owns one thing and reuses the layers below; citations
  extracted once (in `web_fetch`); the paper layer's reasoning lives where an LLM
  actually exists (the session), driven by agents.
- Bad, because more moving parts (shared modules, agent team) and the paper is not
  available to non-Claude-Code MCP clients.

### Option C: Bake an LLM into the MCP server for the paper

- Good, because self-contained — any MCP client gets a finished paper.
- Bad, because needs an API key, costs extra tokens outside the session, and
  duplicates what the session model does for free. Rejected.

## Decision

Chosen option: **Option B — a three-layer stack (`web_fetch` ← `web_search` ←
`deep_research`) over shared `src/` modules, with the research-paper reasoning as
a session-side agent team (Home A).**

- **Shared modules:** `browser.ts` (stealth context), `engines/*.ts` (per-engine
  scrapers), `extract.ts` (readability + CSL-JSON citations + CMS + links/refs —
  **web_fetch owns it for the whole stack**), `score.ts` (source-type + scholarly
  boost + consensus — shared web_search/deep_research), `cache.ts`, `budget.ts`.
- **web_fetch** (bottom): stealth render HTML **and PDF**, page-health, CSL-JSON
  citations, CMS, optional link/reference harvest; `quality: fast|research`
  (source-appraiser agent).
- **web_search** (middle): 3 engines + opt-in Scholar; independent-corroboration
  consensus; `mode: links|confirm`, `quality: fast|research`
  (relevance-adjudicator agent); citations inherited from web_fetch.
- **deep_research** (top): mechanical recursive gather engine — drives web_search
  in **links-mode** (so it owns every fetch + the global budget) + web_fetch;
  lead harvest; cross-level dedup; **evidence clustering**; **until-dry** gap-loop
  termination; raw-material output. **No synthesis in the tool.**
- **research-paper skill** (session-side, Home A; named distinctly to avoid the
  global `deep-research` collision): agent team — thesis-builder, gap-analyst,
  adversarial citation-verifier, mandatory research-assistant (unique personas) —
  runs gather → thesis (may declare contested) → gap-fill (until-dry) → draft
  1300–1500 words → verify every citation → finalize. **Hard rule: no citation
  without a fetched source.** Output: paper + CSL-JSON references + research trace.
- **Agent threshold:** agents fire for non-obvious judgment only — `fast` standalone
  calls stay mechanical; agents are **mandatory inside deep_research**.

> **"can we do both? … What if the research developed a thesis from the
> discoverables, and based additional research off of filling out a … 1300 to
> 1500 word paper complete with verified CMS citations?"**
> **"for both web search, deep research and web fetch, we should be making use of
> agents."**

*— Captured 2026-06-07, source: user, skills-workshop conversation*

## Consequences

- Three method specs rewritten: `/web-fetch-method` (new bottom layer),
  `/web-search-method` (citations now from web_fetch; Scholar; corroboration
  guard; quality param), `/deep-research-method` (mechanical tool + agent paper
  orchestration). CLAUDE.md Architecture, repo layout, method pointers, Phase 2 +
  new Phase 2b updated.
- Adopted improvements: shared modules, PDF extraction, independent-corroboration
  guard, adversarial citation verification, thesis honesty, until-dry gap loop,
  CSL-JSON citations, structured `AMBIGUOUS`-not-guess verdicts, research trace.
  Flagged optional: paywall/archive fallback, recency weighting.
- Phase 2b (research-paper skill + 4 AGENT.md files) is a build step; personas run
  through the skill-builder Persona Assignment Gate; research-assistant included by
  construction.
- All reasoning runs in the session via agents — never in the MCP server.

## Confirmation Criteria

- Right when: `deep_research` returns clustered, citation-bearing raw material with
  no duplicated scoring/citation code, and `research-paper` produces a 1300–1500-
  word paper whose every citation passes adversarial verification and maps to a
  fetched source.
- Reconsider if: the shared-module boundary leaks (a layer re-extracts citations
  or re-implements scoring); or non-Claude-Code MCP clients need the finished
  paper (revisit Option C); or the agent team proves too heavy for routine use
  (make the paper layer opt-in only).
