# DEC-2026-06-07-playwright-sourcing-and-install

**Status:** accepted
**Tags:** playwright, chromium, install, installer, PLAYWRIGHT_BROWSERS_PATH, browser-binary, offline, cross-platform, version-pegging, Phase-3, README-requirements
**Related:** DEC-2026-06-07-build-mcp-lifecycle-orchestrator, DEC-2026-06-07-docs-voice-port, DEC-2026-06-08-installer-non-interactive-and-arch-deps, DEC-2026-07-28-mcp-spec-2026-07-28-adoption-scope

## Context

Before drafting the README and building the Phase 3 installers, the user asked
where Playwright comes from, whether it installs with few/no requirements,
whether it can be pegged to this repository at Claude-Code registration time,
whether it can stay offline until an MCP call needs it, and how this works across
Linux / macOS / Windows PowerShell.

## Decision Drivers

- Playwright is two separable things: the `playwright` npm package (small) and the
  Chromium browser binary (~170 MB, downloaded separately, not in the package).
- The repo already pins `playwright` to the EXACT version `@playwright/mcp@0.0.75`
  bundles (dedupes to one copy / one Chromium revision).
- Goal: "one install, every project" at user scope — a single browser download
  should serve all current and future projects.
- Privacy/locality: the browser engine should be local and idle until used.
- Cross-platform: Linux, macOS, Windows PowerShell must all work; Linux needs
  Chromium system libraries the others don't.

## Decision

Chosen approach (answers the user's four questions, locked for the Phase 3
installer and the README requirements section):

1. **Sourcing — two pieces, two sources.** The `playwright` npm package comes from
   the npm registry via `npm install` (already a direct + transitive dependency;
   deduped via the exact pin). The Chromium binary comes from Playwright's CDN via
   `npx playwright install chromium`, run by the installer — not a separate user
   action, not installed "through the MCP" at runtime.

2. **Requirements — few, with one Linux asterisk.** macOS/Windows: Node ≥18 + npm
   + a one-time ~170 MB download. Linux: the same **plus Chromium system libs**, so
   the installer uses `npx playwright install --with-deps chromium` on Linux
   (uses `sudo apt-get`; the one step that may need elevation). The
   `playwright install chromium` command itself is identical across all three OSes;
   only Linux adds `--with-deps`.

3. **Pegged to this repository — yes, two senses.**
   - **Version-pegged (primary):** the exact `playwright` pin makes the Chromium
     revision deterministic (this repo's expected revision, never drifting
     "latest"). `claude mcp add … -- node <abs>/dist/index.js` registers the server
     pointed at THIS repo's `dist` + `node_modules`, so every project using it
     (even at user scope) runs this repo's exact pinned Playwright. Registration is
     pegged to this repo by construction.
   - **Location (per option):** the binary lands in the **shared per-user cache** by
     default (`~/.cache/ms-playwright` Linux, `~/Library/Caches/ms-playwright`
     macOS, `%LOCALAPPDATA%\ms-playwright` Windows). **Recommendation:** keep the
     shared cache for the **user-scope install** (one download serves all projects);
     **optionally repo-peg** for an isolated **single-project install** via
     `PLAYWRIGHT_BROWSERS_PATH` (`=0` → inside `node_modules`, or a repo dir).
     Whatever value is used must match between install time and the registered
     server's runtime env.

4. **Offline — yes at runtime; download is NOT lazy.** After the one-time install
   download, Chromium is a local binary: nothing runs in the background, nothing
   phones home; the server **launches it on demand** per browser/`web_*` call and
   tears it down. Only the sites being searched/fetched generate network traffic —
   the engine is fully local and idle until used. The DOWNLOAD stays at install
   time (deferring it would hang/time-out the first browser call and require network
   at call time). Optional `--no-browser` installer flag may skip the download and
   let the server fetch on first use with a clear one-time delay, but the default is
   download-at-install.

> **"Is it something that can be easily installed through the mcp with few or no
> requirements? Can the install be pegged to this repository when the installation
> into claude code happens? Can playwright be something that is offline until it's
> needed in an mcp call? … whether the user has a Linux, MacOS or is using
> Powershell in Windows."**

*— Captured 2026-06-07, source: user, skills-workshop conversation*

## Consequences

- **Phase 3 installer (per OS):** check Node ≥18 → `npm ci`/`install` → build →
  `npx playwright install chromium` (Linux: `--with-deps`) → `claude mcp add
  --scope project|user …`. `install.sh` for Linux/macOS, `install.ps1` for Windows.
- **README requirements (verify-before-document):** must state Node ≥18, the
  ~170 MB one-time download, and the Linux system-libs/sudo caveat — honestly, not
  glossed.
- **Two install options differ on browser location too:** user-scope → shared cache
  (dedup); single-project → optional repo-peg.
- Supersedes nothing; refines CLAUDE.md's existing `npx playwright install chromium`
  step with the cross-platform + pegging + offline specifics.

## Confirmation Criteria

- Right when: a fresh install on each of Linux/macOS/Windows leaves a working
  version-pinned Chromium that the registered server launches on demand, fully
  offline against local binaries, with the only network being the target sites.
- Reconsider if: Playwright changes its browser-distribution model (bundled vs
  download), or the shared-cache revision collides with another project's pinned
  Playwright (then repo-peg via `PLAYWRIGHT_BROWSERS_PATH` becomes the default).
