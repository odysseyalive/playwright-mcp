# DEC-2026-06-07-web-search-three-engine-stealth

**Status:** superseded-by DEC-2026-06-08-native-websearch-webfetch-doublecheck
**Tags:** web-search, src/tools/web-search.ts, src/browser.ts, web-search-method, stealth-scraping, source-type-ranking, consensus-authority, citations, Phase-2
**Related:** DEC-2026-06-07-mcp-instructions-discoverability, DEC-2026-06-08-native-websearch-webfetch-doublecheck

> **Superseded 2026-06-08:** scraping consumer search engines from the user's
> residential IP proved an unwinnable bot-detection / IP-reputation arms race
> (all three engines blocked simultaneously; SearXNG source confirmed IP-level
> blocking regardless of request hygiene). Replaced by native server-side
> WebSearch for discovery + web_fetch double-check — see
> DEC-2026-06-08-native-websearch-webfetch-doublecheck.

## Context

The `web_search` tool (Phase 2) needs to replace Claude Code's native WebSearch.
The original plan was a single headless Google scrape with a DuckDuckGo HTML
fallback. The user redesigned it in the 2026-06-07 skills-workshop into a
multi-engine, anti-bot, citation-producing search that returns a ranked,
confirmed source set rather than raw links.

## Decision Drivers

- **Resilience:** Google intermittently CAPTCHAs headless contexts even when well
  disguised; a single-engine design is fragile.
- **Quality over engine order:** engine SERP rank is contaminated (SEO, freshness,
  commercial intent, personalization) and is not "best answer to this query."
- **No APIs:** the user explicitly wants scraping through a disguised headless
  browser, not engine APIs.
- **Citable output:** results must come back with real source URLs and
  author/date/CMS citation data, not just titles+snippets.
- **Don't become deep_research:** keep the tool bounded to a single level.
- **Protect the exact `playwright` pin** that must match `@playwright/mcp`'s
  bundled version.

## Options Considered

### Option A: Single Google scrape + DDG fallback (original plan)

- Good, because simplest; DDG markup is stable.
- Bad, because Google's flakiness takes the whole tool down; no cross-engine
  corroboration; trusts engine order; no citation layer.

### Option B: Three independent engines, stealth, re-rank, confirm-fetch, cite

- Good, because fail-soft across Google + Bing + DuckDuckGo (return whatever
  succeeded); cross-engine consensus is a strong relevance/authority signal;
  our own re-ranking beats engine order; the confirm-fetch validates relevance
  and page health before returning; citation extraction makes results usable.
- Bad, because heavier (3 scrapes + ~6 fetches, ~10–30s) and more selectors to
  maintain.

### Option C: Use engine APIs

- Good, because stable, structured.
- Bad, because explicitly rejected by the user (wants API-free scraping);
  keys/quotas/cost; defeats the "headless browser as a person" goal.

## Decision

Chosen option: **Option B — three-engine stealth scrape with our-own re-ranking,
a confirm-fetch arbiter, and citation extraction.**

Flow: same query → Google + Bing + DuckDuckGo (parallel, fail-soft) → read each
engine's full first page (~30 candidates) → re-rank each by OUR signals (title
query-term coverage, snippet substance, source-type, scholarly boost; engine
position only a weak tiebreaker) → best 2 per engine → dedup by canonical URL
recording cross-engine consensus → score (relevance spine + source-type modifier
+ consensus) → confirm-fetch the 6 (the arbiter: relevance, page health,
freshness) → final rank 1–6. Hold ~2 reserve candidates, backfill only on hard
failures (404/blocked), keep paywalls, cap ~8 fetches / ~90s.

**Stealth:** manual layer first (`--disable-blink-features=AutomationControlled`,
real UA with `HeadlessChrome` stripped, `addInitScript` zeroing
`navigator.webdriver`, realistic locale/timezone/viewport, persistent profile at
`~/.cache/playwright-mcp/profile`, per-engine consent pre-seed, jittered pacing).
No `playwright-extra`/stealth plugin (wraps Playwright, collides with the exact
pin); WebGL/canvas spoofing is escalation-only. A headed-vs-headless parity
harness builds/validates selectors; a per-engine block detector drops a blocked
engine without failing the tool. The custom tools run in their OWN stealth
Chromium context (`src/browser.ts`), separate from the wrapped `@playwright/mcp`
browser, shared with `web_fetch`.

**Source weighting (folded in this session):** weight by *what a source is*, not a
curated brand list — a source-TYPE classifier (primary/academic/reference/
journalism/blog/commercial/content-farm) modulated by query intent, plus
query-specific consensus authority (same domain surfaced by multiple engines for
this query). The only static list is the scholarly/primary boost shared with
`deep_research`. Guardrails: boosts stay small (never override clear relevance)
and are surfaced in each result's `relevance.why`.

**Citations:** extract during confirm-fetch in priority order JSON-LD schema.org →
OpenGraph/article meta → Dublin Core → microformats/byline; `dateConfidence`
flag because dates are flaky; best-effort CMS detection. Return structured fields
plus one `suggested` formatted string.

> **"I'd like the searches not to use the API of each of these services, I'd like
> the system to debug the proper way of bringing these up through playwright by
> fooling each of these services into thinking the playwright headless browser is
> a real person."**
> **"the best targets for each of the three searches isn't the order they show up
> in the actual search."**
> **"weighting by what a source is and whether the engines agree on it for this
> query; no to a curated list of blessed names."**

*— Captured 2026-06-07, source: user, skills-workshop conversation*

## Consequences

- `web_search` and `web_fetch` must be built together (shared browser lifecycle;
  the confirm-fetch reuses the `web_fetch` routine).
- New `src/browser.ts` owns a stealth-configured persistent Chromium context,
  distinct from the wrapped server's browser.
- More selector maintenance (three engines); mitigated by the parity harness and
  per-engine isolation.
- Heavier latency than native WebSearch; an optional `mode: "links" | "confirm"`
  (default `confirm`) preserves a cheap path.
- Borders `deep_research`; the boundary is **recursion** — `web_search` is exactly
  one level (search → confirm → rank), no lead-following.
- Spec lives in `/web-search-method`; CLAUDE.md updated (Architecture web_search
  bullet, method pointer, search-engine-fragility + bot-detection gotchas).
- The earlier CLAUDE.md "don't escalate to stealth without need" guidance is
  reversed — the need is now explicit.

## Confirmation Criteria

- Right when: in practice the tool returns corroborated, on-topic, citable sources
  even when one engine (usually Google) is blocked, and the requesting AI cites
  them with author/date.
- Reconsider if: stealth maintenance becomes a constant fire (engines hard-block
  the disguised context) — then weigh API fallback (Option C) per-engine, or
  WebGL-tier escalation; or if the confirm-fetch latency proves too heavy for the
  default path — then flip the default to `links` mode.
