# DEC-2026-06-07-image-skills-port

**Status:** accepted
**Tags:** image, image-eval, nanobanana, gemini, illustrations, creative-lane, port, claude-enforcer, external-dependency, watercolor
**Related:** DEC-2026-06-07-docs-voice-port, DEC-2026-06-07-readme-last-step-bare-bones, DEC-2026-06-07-gitignore-default-ignore-and-no-commit

## Context

The user asked to pull the nanobanana image-generation routines from
/home/francis/lab/claude-enforcer into playwright-mcp for possible doc
illustrations. An Explore agent inventoried them.

## Decision

Chosen option: **port both `image` + `image-eval`, faithful (watercolor house-style
kept)** (user-ratified via AskUserQuestion).

- **`image`** (generation): watercolor base-style template + 5-palette system +
  aspect-ratio reference + 4 enforcement gates + `image-validator` agent + a
  `chain-image-eval` hook (host-local, dormant until wired). Generates via the
  `nanobanana-mcp` MCP server (`mcp__nanobanana-mcp__gemini_generate_image` /
  `gemini_edit_image`).
- **`image-eval`** (evaluation): the `watercolor-evaluator` agent assesses generated
  images for AI tells + watercolor authenticity in an isolated context.
- Copied verbatim via `cp -r`. Two minimal adaptations: added `lane: creative` to
  both frontmatter; fixed the `image` description's project context (was "for
  Odyssey Alive") to this project's documentation. Watercolor style + palettes +
  gates + agents kept verbatim per the user's "keep watercolor" choice.
- Agents are already model-pinned `claude-opus-4-6` (correct for the creative lane);
  personas (image archivist; watercolor instructor with a forger's eye) are unique
  within playwright-mcp. Both skills already carry the MODEL-LANE-GATE.

**Hard external dependency (must be satisfied to actually generate):** the
`nanobanana-mcp` server (separate project at ~/lab/nanobanana-mcp) registered +
`GOOGLE_AI_API_KEY` (Gemini). Both are already present in the user's environment
(`mcp__nanobanana-mcp__*` tools are available this session). Without them the skills
load but cannot produce an image.

**Scope note (honest):** image generation is orthogonal to playwright-mcp's
mission (browse/search/fetch); the only use case here is optional doc illustrations
(the README is bare-bones, images optional). Porting is cheap because `.claude/` is
gitignored (local scaffolding, not committed), and the dependency is already met —
so the capability is ready in the user's established watercolor aesthetic when
wanted, at low cost.

> **"could we pull in the nanobana image generation routines from the
> ~/lab/claude-enforcer project too? we might want some illustrations."**

*— Captured 2026-06-07, source: user, skills-workshop conversation*

## Consequences

- Two more creative-lane skills (joining docs-voice); added to the Skill→Lane table
  and the `/route` catalog.
- Save paths in `image/references/saving.md` reference Odyssey-Alive conventions
  (`assets/images/focus/…`) — kept verbatim (faithful); they are per-invocation
  examples and would be set to a playwright-mcp-appropriate path when actually used.
- The `chain-image-eval` hook is dormant until wired host-locally (hooks aren't
  auto-active); generation still auto-chains to `/image-eval` via the skill workflow.
- The nanobanana-mcp dependency is documented in the skill description and this DEC
  so it's not a surprise at first use.

## Confirmation Criteria

- Right when: with `nanobanana-mcp` + a Gemini key present, `/image` produces a
  watercolor illustration that `/image-eval` clears, usable in the project's docs.
- Reconsider if: image generation never gets used here (then strip both to keep the
  skill set focused), or the watercolor house-style proves wrong for this project's
  docs (loosen to the style-flexible variant).
