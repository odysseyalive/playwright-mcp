# DEC-2026-06-07-mcp-instructions-discoverability

**Status:** accepted
**Tags:** mcp-discoverability, instructions-field, src/index.ts, buildInstructions, tool-descriptions, deferred-tool-schemas, scripts/smoke.mjs, CLAUDE.md-steering
**Related:** DEC-2026-07-28-mcp-spec-2026-07-28-adoption-scope

## Context

When playwright-mcp is registered in a project, all of its capabilities (~25
wrapped `browser_*` tools plus the Phase 2 custom tools `web_search`,
`web_fetch`, `deep_research`) must be easily discoverable by the model. The
original build plan relied on tool descriptions alone — but Claude Code defers
large tool sets, registering only tool *names* until the model runs ToolSearch,
so descriptions are not a reliable discovery surface at this server's size.

## Decision Drivers

- Claude Code's deferred-tool-schema behavior: with ~28 tools, descriptions and
  schemas may not be loaded into context at all until explicitly searched.
- The MCP `instructions` initialization field is injected into the system prompt
  as "MCP Server Instructions" and stays visible even when every tool is
  deferred (observed live in the 2026-06-07 workshop session).
- A hand-maintained capability list would drift from the actual toolset as
  upstream `@playwright/mcp` adds/renames tools.
- Host honoring of `instructions` is real today but not contractual.

## Options Considered

### Option A: Tool descriptions alone (status quo of the original plan)

- Good, because zero extra code — upstream descriptions are inherited free.
- Bad, because defeated by deferred tool schemas: at ~28 tools the model may
  see names only, so "all the options" are NOT discoverable.

### Option B: Generated `instructions` capability map + three-layer discovery

- Good, because the `instructions` field is the only always-visible surface,
  even when schemas are deferred.
- Good, because generating it from the live toolset at startup
  (`buildInstructions()` in `src/index.ts`) makes drift impossible.
- Good, because layered redundancy (descriptions + instructions + CLAUDE.md
  steering) survives any single host-behavior change.
- Bad, because it adds a small startup step and an unverified code delta to the
  previously compile-verified Phase 1 snippet.

### Option C: A dedicated `help`/`server_info` tool

- Good, because queryable on demand.
- Bad, because pull-based: the model must already know to call it — it does not
  make capabilities discoverable, only describable.

## Decision

Chosen option: **Option B — generated `instructions` capability map, three
discovery layers shipping together**, because the instructions field is the only
surface guaranteed visible under deferred-tool behavior, and live generation
eliminates the drift hazard of a hand-maintained list.

1. The outward-facing `Server` passes `instructions` rendered at startup by
   `buildInstructions()` from the LIVE toolset — categorized (replaces-native
   steering, browse/debug workflow, debugging, full tool list), never
   hand-maintained, kept under ~40 lines.
2. Tool descriptions stay crisp; custom tools explicitly say they replace
   native WebSearch/WebFetch.
3. The `~/.claude/CLAUDE.md` steering directive uses the same vocabulary as the
   instructions map (steering says *when*, layers 1–2 say *what*).

> **"If we register this as an MCP in a project, I want all the options this mcp can do be easily discoverable by ai."**

*— Captured 2026-06-07, source: user, skills-workshop conversation*

## Consequences

- Phase 1 acceptance criteria extended: `scripts/smoke.mjs` asserts a non-empty
  instructions map via `client.getInstructions()` (Phase 1: `browser_navigate`
  present; Phase 2 extends to `web_search`/`web_fetch` — the REPLACES NATIVE
  TOOLS line only renders once those tools exist).
- The discoverability code delta postdates the 2026-06-07 compile verification
  of the Phase 1 snippet and is not yet compile-verified (noted in CLAUDE.md
  § Status).
- Plan amendments recorded in CLAUDE.md: Architecture item 3, Bootstrap step 4
  Verify, Build Phases Phase 2, and Gotchas (deferred tool schemas).

## Confirmation Criteria

- Right when: in a fresh session in another project, the model reaches for
  `mcp__playwright-mcp__web_search` / browser tools unprompted, with the
  capability map visible under "MCP Server Instructions".
- Reconsider if: Claude Code stops surfacing MCP `instructions` in the system
  prompt, or the instructions map exceeds ~40 lines / gets truncated — then the
  weight shifts to the CLAUDE.md steering layer and possibly a registered skill.
